# PetCare — Manual Testing Checklist

Click through this in a **real browser** to confirm everything works. It takes about **15–20 minutes**.
Do the sections **in order**, because some steps use bookings made in earlier ones.

**Before you start**
1. In the `petcare` folder, reset to fresh sample data:
   ```powershell
   cmd /c "mysql -u root -p < database\schema.sql"
   cmd /c "mysql -u root -p petcare < database\seed.sql"
   ```
2. Start the server with `npm run dev`. The terminal should show **`MySQL connected — 12 services in database`**.
3. Open **http://localhost:3000**.

Tick each box as it passes. If one fails, write what you saw in the **Issues** table at the bottom.

| Role | Username | Password |
|---|---|---|
| Pet Owner | `owner1` / `owner2` / `owner3` | `owner123` |
| Veterinarian | `vet1` / `vet2` | `vet123` |
| Groomer | `groomer1` / `groomer2` | `groomer123` |
| Day Walker | `walker1` / `walker2` | `walker123` |

---

## 1. Landing page
- [ ] 12 service cards appear, each with a **photo that matches the service**, a caption and a ₹ price
- [ ] The filter chips (All / Vet / Groomer / Walker) show the right services
- [ ] The **Demo logins** card is right under the hero, with all 4 roles shown
- [ ] The **System Architecture** button in the header opens the architecture page
- [ ] The **Login / Sign up** button in the header opens the login page
- [ ] **Book a service** opens the login page

## 2. Login and sign up
- [ ] Clicking the **Pet Owner** demo card fills in role, username and password
- [ ] Logging in as `owner1` opens the **owner dashboard**
- [ ] **Log out**, then log in as `vet1`, `groomer1` and `walker1` in turn. Each opens its **own dashboard** (vet, groomer, walker)
- [ ] Logging in as `owner1` with **Veterinarian** selected shows: *"This account is not registered as vet"*
- [ ] A wrong password shows: *"Invalid username or password"*
- [ ] Sign up with **mismatched passwords**: an error appears under *Confirm password*
- [ ] Sign up with username **`owner1`**: *"Username already taken"*
- [ ] On sign up, choosing **Veterinarian** shows qualification, experience **and license number**. Choosing **Groomer** hides the license number
- [ ] Sign up a new **owner** account. It logs you in and opens the owner dashboard

## 3. My Pets (log in as `owner1`)
- [ ] Bruno and Mithi are listed
- [ ] **Add** a pet. It appears in the list
- [ ] **Edit** it (change the weight, say). The change saves
- [ ] **Delete** it. You're asked to confirm first, then it's removed

## 4. Booking rules (as `owner1` → Book Appointment)
- [ ] The date picker **won't allow yesterday** or any earlier date
- [ ] Choosing **today** greys out every hour that has passed, labelled *"Time has passed"*
- [ ] **Hair Trimming → Kavya Iyer → the day after tomorrow:** **10:00 shows "This slot is not available"** (owner3 already booked it)
- [ ] Switching the provider to **Imran Shaikh** for the same day makes **10:00 available**
- [ ] Make a real booking: **Routine Health Checkup → Dr. Sneha Patil → tomorrow → any free slot**. A "Booked" confirmation appears
- [ ] Go back to that provider, date and time. The slot now shows **"This slot is not available"**
- [ ] The new booking appears under **My Appointments → Upcoming**

## 5. The booking reaches the provider
- [ ] Log out and log in as **`vet1`**
- [ ] The booking from section 4 (Bruno, owner Aarav Mehta, tomorrow) is on **Dr. Sneha Patil's dashboard**
- [ ] It shows the **owner's contact details**, the **pet's details** and the owner's note
- [ ] The overview cards (today / upcoming / completed / rating) show sensible numbers

## 6. Shared pet records
- [ ] As **`vet1`**, open that booking and **add a record** (for example *Medical: "Ear check: mild wax"*)
- [ ] Log in as **`owner1`** and open the same appointment. **The vet's record is there**, with who created it
- [ ] **Edit** the record as `owner1` and save
- [ ] Log back in as **`vet1`**. The edit shows, with **last edited by Aarav Mehta**
- [ ] Log in as **`owner2`**. Bruno's records **aren't visible** anywhere

## 7. Reschedule and cancel (as `owner1`)
- [ ] Open the new appointment → **Reschedule**. Its own slot is labelled **"Current slot"**
- [ ] Trying to pick a **past date** in the reschedule picker isn't allowed
- [ ] Move it to another day and time. The status becomes **Rescheduled**, and the history shows old → new
- [ ] As `vet1`, the appointment shows the **new** date and time
- [ ] As `owner1`, **Cancel** the appointment. The status becomes **Cancelled**
- [ ] In Book Appointment, that slot with Dr. Sneha Patil is **free again**
- [ ] A cancelled appointment **can't be rescheduled**

## 8. Completing and reviewing
- [ ] Log in as **`owner3`** and open the past **Daycare** appointment (Simba, Rahul Deshmukh)
- [ ] Give it a **4-star review** with a comment. It saves and shows on the appointment
- [ ] Try to review it **again**. It's refused, or the option is gone
- [ ] An **upcoming** appointment has **no review option**
- [ ] Log in as **`walker1`** → **My Reviews**. The new review and the updated average are there
- [ ] As a provider, **Mark completed** is available only for appointments whose time has started

## 9. Provider profile (as `vet1` → My Profile)
- [ ] Change the **working hours to end at 15:00** and save
- [ ] As **`owner1`**, book with Dr. Sneha Patil. The slots from 15:00 onwards show **"Outside working hours"**
- [ ] Change the hours back to **18:00**

## 10. System Architecture page (`/architecture.html`)
- [ ] All **8 tables** are listed, with columns, data types, keys and **row counts**
- [ ] The **ER diagram** and the **3 triggers** are shown
- [ ] The **workflow diagram** is shown
- [ ] The users section has **4 tabs** (Owners, Vets, Groomers, Walkers) with full details
- [ ] Passwords show only as **`•••••• (bcrypt)`**, never a real password or hash

## 11. Sessions and errors
- [ ] Log out, then open **http://localhost:3000/owner.html** directly. You're sent to the login page
- [ ] Logged in as `owner1`, open **/vet.html**. You're not allowed in and are sent to the login page
- [ ] Success and error messages appear as small **pop-up notifications** (not browser alert boxes)

## 12. Phone layout
- [ ] Press **F12 → the phone icon** (or narrow the window to about 375 px)
- [ ] The landing page shows **1 card per row**, the header shows icons only, and **nothing scrolls sideways**
- [ ] The owner dashboard and the booking flow are still usable
- [ ] The provider dashboard is still usable

---

## After testing
Reset the data so your test bookings don't show in a demo:
```powershell
cmd /c "mysql -u root -p < database\schema.sql"
cmd /c "mysql -u root -p petcare < database\seed.sql"
```

## Issues found
| Section / step | What you did | What you expected | What happened |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

**Tested by:** ____________________  **Date:** ____________  **Result:** ☐ All passed  ☐ Issues found
