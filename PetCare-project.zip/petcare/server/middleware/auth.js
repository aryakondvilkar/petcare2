// Session-based auth guards.
// req.session.user = { user_id, full_name, username, role }

const ROLE_HOME = {
  owner: '/owner.html',
  vet: '/vet.html',
  groomer: '/groomer.html',
  walker: '/walker.html'
};
const PROVIDER_ROLES = ['vet', 'groomer', 'walker'];

function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: 'Please log in first' });
  next();
}

// usage: router.get('/x', requireRole('owner'), handler)
//        router.get('/y', requireRole(...PROVIDER_ROLES), handler)
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.session.user) return res.status(401).json({ error: 'Please log in first' });
    if (!roles.includes(req.session.user.role)) {
      return res.status(403).json({ error: 'You do not have access to this' });
    }
    next();
  };
}

module.exports = { requireLogin, requireRole, ROLE_HOME, PROVIDER_ROLES };
