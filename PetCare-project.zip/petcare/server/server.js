require('dotenv').config();
const path = require('path');
const express = require('express');
const session = require('express-session');
const { checkConnection } = require('./config/db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'petcare-dev-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 8 }  // 8 hours
}));

// ---------- API ----------
app.use('/api/auth',         require('./routes/auth.routes'));
app.use('/api/services',     require('./routes/services.routes'));
app.use('/api/providers',    require('./routes/providers.routes'));
app.use('/api/pets',         require('./routes/pets.routes'));
app.use('/api/appointments', require('./routes/appointments.routes'));
app.use('/api/records',      require('./routes/records.routes'));
app.use('/api/reviews',      require('./routes/reviews.routes'));
app.use('/api/architecture', require('./routes/architecture.routes'));

app.use('/api', (req, res) => res.status(404).json({ error: 'API route not found' }));

// ---------- Frontend ----------
app.use(express.static(path.join(__dirname, '..', 'public')));

// ---------- Error handler ----------
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server' });
});

app.listen(PORT, async () => {
  console.log(`PetCare running at http://localhost:${PORT}`);
  try {
    const n = await checkConnection();
    console.log(`MySQL connected — ${n} services in database`);
  } catch (err) {
    console.error('MySQL connection FAILED:', err.message);
    console.error('Check DB_* values in .env and that schema.sql + seed.sql were imported.');
  }
});
