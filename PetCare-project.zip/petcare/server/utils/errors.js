// Turns MySQL errors into clean { error } responses.
// Use in routes:   catch (err) { sendDbError(res, err); }

function mapDbError(err) {
  const msg = err.sqlMessage || err.message || '';

  // duplicate key
  if (err.errno === 1062) {
    // match on the key name only — the message also contains the duplicate value itself
    const key = (msg.match(/for key '([^']+)'/) || [])[1] || msg;
    if (key.includes('uq_provider_slot')) return [409, 'This slot is not available'];
    if (key.includes('uq_pet_slot'))      return [409, 'Your pet already has an appointment at this time'];
    if (key.includes('username'))         return [409, 'Username already taken'];
    if (key.includes('email'))            return [409, 'Email already registered'];
    if (key.includes('appointment_id'))   return [409, 'This appointment has already been reviewed'];
    return [409, 'Duplicate entry'];
  }
  // trigger SIGNAL SQLSTATE '45000' — message is already user-friendly
  if (err.errno === 1644) return [400, msg];
  // CHECK constraint failed (MySQL 3819, MariaDB 4025)
  if (err.errno === 3819 || err.errno === 4025) return [400, 'Invalid value: ' + msg];
  // FK failures
  if (err.errno === 1452) return [400, 'Referenced record does not exist'];
  if (err.errno === 1451) return [409, 'This record is in use and cannot be deleted'];

  return [500, 'Something went wrong on the server'];
}

function sendDbError(res, err) {
  const [status, message] = mapDbError(err);
  if (status === 500) console.error(err);
  res.status(status).json({ error: message });
}

module.exports = { mapDbError, sendDbError };
