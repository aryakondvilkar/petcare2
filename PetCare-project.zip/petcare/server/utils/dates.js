// Date/slot helpers. "Now" is the server's local time (same clock MySQL's NOW() uses).

// Hourly slot start times, 09:00 – 17:00 (rule B7)
const SLOT_HOURS = [9, 10, 11, 12, 13, 14, 15, 16, 17];

const pad = (n) => String(n).padStart(2, '0');

function todayStr(now = new Date()) {
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}

// 'YYYY-MM-DD' that is a real calendar date
function isValidDate(str) {
  if (typeof str !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(str)) return false;
  const [y, m, d] = str.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
}

// 'HH:00' or 'HH:00:00' -> hour number if it's a valid slot, else null
function parseSlot(str) {
  const m = typeof str === 'string' && str.match(/^(\d{2}):00(:00)?$/);
  if (!m) return null;
  const hour = Number(m[1]);
  return SLOT_HOURS.includes(hour) ? hour : null;
}

// true if the slot's start time is now or earlier (same test as the trigger: TIMESTAMP(date, time) <= NOW())
function slotHasPassed(date, hour, now = new Date()) {
  const today = todayStr(now);
  if (date < today) return true;
  if (date > today) return false;
  return hour <= now.getHours();
}

const slotLabel = (hour) => `${pad(hour)}:00`;

// 'HH:MM:SS' -> hour as a number (for work_start / work_end)
const timeToHour = (t) => Number(String(t).slice(0, 2)) + Number(String(t).slice(3, 5)) / 60;

module.exports = { SLOT_HOURS, todayStr, isValidDate, parseSlot, slotHasPassed, slotLabel, timeToHour };
