// Ownership checks shared by the appointment, record and availability routes.
const { pool } = require('../config/db');

// raw appointment row, or null
async function loadAppointment(id) {
  const [rows] = await pool.execute('SELECT * FROM appointments WHERE appointment_id = ?', [id]);
  return rows[0] || null;
}

// the owner or the provider on the appointment
function isParty(user, appt) {
  return !!appt && (appt.owner_id === user.user_id || appt.provider_id === user.user_id);
}

// appointment the user is on, or null (404 either way, so other people's ids aren't revealed)
async function loadAppointmentFor(user, id) {
  const appt = await loadAppointment(id);
  return isParty(user, appt) ? appt : null;
}

// Rule B11 for a pet's records:
//   owner      -> their own pet
//   provider   -> a record linked to one of their appointments, or a general record (no appointment)
//                 for a pet they have an appointment with
async function petOwnerId(petId) {
  const [rows] = await pool.execute('SELECT owner_id FROM pets WHERE pet_id = ?', [petId]);
  return rows.length ? rows[0].owner_id : null;
}

async function providerHasPet(providerId, petId) {
  const [rows] = await pool.execute(
    'SELECT 1 FROM appointments WHERE provider_id = ? AND pet_id = ? LIMIT 1', [providerId, petId]);
  return rows.length > 0;
}

// can `user` read/edit a record on `petId` linked to `appt` (appointment row or null)?
async function canUseRecord(user, petId, appt) {
  if (user.role === 'owner') return (await petOwnerId(petId)) === user.user_id;
  if (appt) return appt.provider_id === user.user_id;
  return providerHasPet(user.user_id, petId);
}

// pet_records with author/editor names and the linked appointment's service and date
async function selectRecords(where, params) {
  const [rows] = await pool.execute(
    `SELECT r.record_id, r.pet_id, pt.name AS pet_name, r.appointment_id, r.record_type, r.title, r.details,
            r.created_by, cu.full_name AS created_by_name, cu.role AS created_by_role,
            r.last_edited_by, eu.full_name AS last_edited_by_name, eu.role AS last_edited_by_role,
            r.created_at, r.updated_at,
            a.appt_date, s.name AS service_name, a.provider_id
       FROM pet_records r
       JOIN pets pt       ON pt.pet_id = r.pet_id
       JOIN users cu      ON cu.user_id = r.created_by
       LEFT JOIN users eu ON eu.user_id = r.last_edited_by
       LEFT JOIN appointments a ON a.appointment_id = r.appointment_id
       LEFT JOIN services s     ON s.service_id = a.service_id
      WHERE ${where}
      ORDER BY r.updated_at DESC, r.record_id DESC`,
    params
  );
  return rows;
}

module.exports = { loadAppointment, isParty, loadAppointmentFor, petOwnerId, providerHasPet, canUseRecord, selectRecords };
