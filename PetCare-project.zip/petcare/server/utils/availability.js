// Slot availability, shared by GET /api/providers/:id/availability and POST /api/appointments
// so the list the owner sees and the server's re-check apply exactly the same rules.
const { pool } = require('../config/db');
const { PROVIDER_ROLES } = require('../middleware/auth');
const { SLOT_HOURS, slotHasPassed, slotLabel, timeToHour } = require('./dates');

const REASON_BOOKED = 'This slot is not available';
const REASON_PASSED = 'Time has passed';
const REASON_HOURS = 'Outside working hours';
const REASON_PET = 'Your pet already has an appointment at this time';
const REASON_CURRENT = 'Current slot';

// provider with working hours, or null if the id isn't a provider
async function getProvider(providerId) {
  const [rows] = await pool.execute(
    `SELECT u.user_id, u.full_name, u.role, p.work_start, p.work_end
       FROM users u JOIN provider_profiles p ON p.provider_id = u.user_id
      WHERE u.user_id = ?`,
    [providerId]
  );
  const p = rows[0];
  return p && PROVIDER_ROLES.includes(p.role) ? p : null;
}

// [{ time:'09:00', available:true } | { time, available:false, reason }]
// options:
//   petId          also mark slots where that pet is already booked with anyone (rule B4)
//   appointmentId  the appointment being rescheduled: its own slot shows 'Current slot'
//                  instead of 'This slot is not available', and it never clashes with itself
async function getSlots(provider, date, { petId = null, appointmentId = null } = {}) {
  const [taken] = await pool.execute(
    `SELECT appointment_id, HOUR(start_time) AS h FROM appointments
      WHERE provider_id = ? AND appt_date = ? AND status <> 'Cancelled'`,
    [provider.user_id, date]
  );
  const providerBusy = new Set();
  let currentHour = null;
  for (const r of taken) {
    if (appointmentId && r.appointment_id === Number(appointmentId)) currentHour = r.h;
    else providerBusy.add(r.h);
  }

  let petBusy = new Set();
  if (petId) {
    const [rows] = await pool.execute(
      `SELECT HOUR(start_time) AS h FROM appointments
        WHERE pet_id = ? AND appt_date = ? AND status <> 'Cancelled' AND appointment_id <> ?`,
      [petId, date, Number(appointmentId) || 0]
    );
    petBusy = new Set(rows.map((r) => r.h));
  }

  const start = timeToHour(provider.work_start);
  const end = timeToHour(provider.work_end);
  const now = new Date();

  return SLOT_HOURS.map((h) => {
    const time = slotLabel(h);
    if (h === currentHour)           return { time, available: false, reason: REASON_CURRENT, current: true };
    if (slotHasPassed(date, h, now)) return { time, available: false, reason: REASON_PASSED };
    if (h < start || h + 1 > end)    return { time, available: false, reason: REASON_HOURS };
    if (providerBusy.has(h))         return { time, available: false, reason: REASON_BOOKED };
    if (petBusy.has(h))              return { time, available: false, reason: REASON_PET };
    return { time, available: true };
  });
}

module.exports = { getProvider, getSlots, REASON_BOOKED, REASON_PASSED, REASON_CURRENT };
