// MySQL connection pool — import { pool } wherever you need the database.
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'petcare',
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true,   // DATE/TIME come back as 'YYYY-MM-DD' / 'HH:MM:SS' strings
  timezone: 'local'
});

async function checkConnection() {
  const [rows] = await pool.query('SELECT COUNT(*) AS n FROM services');
  return rows[0].n;
}

module.exports = { pool, checkConnection };
