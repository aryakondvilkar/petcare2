const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');
const { requireLogin, ROLE_HOME, PROVIDER_ROLES } = require('../middleware/auth');
const { sendDbError } = require('../utils/errors');

const ROLES = Object.keys(ROLE_HOME);

// Built-in demo accounts — shown on the landing page (SPEC R1.1)
const DEMO_LOGINS = [
  { role: 'owner',   label: 'Pet Owner',    username: 'owner1',   password: 'owner123' },
  { role: 'vet',     label: 'Veterinarian', username: 'vet1',     password: 'vet123' },
  { role: 'groomer', label: 'Groomer',      username: 'groomer1', password: 'groomer123' },
  { role: 'walker',  label: 'Day Walker',   username: 'walker1',  password: 'walker123' }
];

// New session id on every login/signup, so a session id set before login
// can't be reused afterwards (session fixation).
function startSession(req, user) {
  return new Promise((resolve, reject) => {
    req.session.regenerate((err) => {
      if (err) return reject(err);
      req.session.user = user;
      resolve();
    });
  });
}

// GET /api/auth/demo-logins   [done]
router.get('/demo-logins', (req, res) => res.json(DEMO_LOGINS));

// POST /api/auth/login   [done]
// body: { username, password, role }
router.post('/login', async (req, res) => {
  const { username, password, role } = req.body || {};
  if (!username || !password || !role) {
    return res.status(400).json({ error: 'Username, password and role are required' });
  }
  if (!ROLES.includes(role)) return res.status(400).json({ error: 'Invalid role' });

  try {
    const [rows] = await pool.execute(
      'SELECT user_id, full_name, username, password_hash, role FROM users WHERE username = ?',
      [username]
    );
    const u = rows[0];
    if (!u || !(await bcrypt.compare(password, u.password_hash))) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }
    if (u.role !== role) {
      return res.status(403).json({ error: `This account is not registered as ${role}` });
    }
    const user = { user_id: u.user_id, full_name: u.full_name, username: u.username, role: u.role };
    await startSession(req, user);
    res.json({ user, redirect: ROLE_HOME[u.role] });
  } catch (err) {
    sendDbError(res, err);
  }
});

// POST /api/auth/signup   [done]
// body: { full_name, username, email, phone, address, password, role,
//         qualification?, license_no?, experience_years? }
// Creates the user (and provider_profiles row for providers) in one transaction,
// then logs them in.
router.post('/signup', async (req, res) => {
  const b = req.body || {};
  const str = (v) => (typeof v === 'string' ? v.trim() : '');
  const full_name = str(b.full_name);
  const username = str(b.username);
  const email = str(b.email).toLowerCase();
  const phone = str(b.phone).replace(/[\s-]/g, '');
  const address = str(b.address) || null;
  const role = str(b.role);
  const password = typeof b.password === 'string' ? b.password : '';
  const isProvider = PROVIDER_ROLES.includes(role);

  if (!ROLES.includes(role)) return res.status(400).json({ error: 'Please choose a valid role' });
  if (full_name.length < 2 || full_name.length > 100) {
    return res.status(400).json({ error: 'Full name must be 2–100 characters' });
  }
  if (!/^[A-Za-z0-9_.]{3,50}$/.test(username)) {
    return res.status(400).json({ error: 'Username must be 3–50 letters, numbers, dots or underscores' });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 120) {
    return res.status(400).json({ error: 'Please enter a valid email address' });
  }
  if (!/^\+?\d{10,14}$/.test(phone)) {
    return res.status(400).json({ error: 'Phone must be 10–14 digits' });
  }
  if (address && address.length > 255) return res.status(400).json({ error: 'Address is too long' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });

  let qualification = null, license_no = null, experience_years = 0;
  if (isProvider) {
    qualification = str(b.qualification);
    if (!qualification || qualification.length > 120) {
      return res.status(400).json({ error: 'Qualification is required (max 120 characters)' });
    }
    experience_years = Number(b.experience_years ?? 0);
    if (!Number.isInteger(experience_years) || experience_years < 0 || experience_years > 60) {
      return res.status(400).json({ error: 'Experience must be a whole number of years from 0 to 60' });
    }
    if (role === 'vet') {
      license_no = str(b.license_no);
      if (!license_no || license_no.length > 40) {
        return res.status(400).json({ error: 'A license number is required for vets (max 40 characters)' });
      }
    }
  }

  let conn;
  let committed = false;
  try {
    const password_hash = await bcrypt.hash(password, 10);
    conn = await pool.getConnection();
    await conn.beginTransaction();
    const [result] = await conn.execute(
      `INSERT INTO users (full_name, username, password_hash, role, email, phone, address)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [full_name, username, password_hash, role, email, phone, address]
    );
    if (isProvider) {
      await conn.execute(
        `INSERT INTO provider_profiles (provider_id, qualification, license_no, experience_years)
         VALUES (?, ?, ?, ?)`,
        [result.insertId, qualification, license_no, experience_years]
      );
    }
    await conn.commit();
    committed = true;

    const user = { user_id: result.insertId, full_name, username, role };
    await startSession(req, user);
    res.status(201).json({ user, redirect: ROLE_HOME[role] });
  } catch (err) {
    if (conn && !committed) await conn.rollback().catch(() => {});
    sendDbError(res, err);
  } finally {
    if (conn) conn.release();
  }
});

// POST /api/auth/logout   [done]
router.post('/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

// GET /api/auth/me   [done]
router.get('/me', requireLogin, (req, res) => res.json({ user: req.session.user }));

module.exports = router;
