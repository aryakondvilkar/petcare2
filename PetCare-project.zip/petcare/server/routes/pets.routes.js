const router = require('express').Router();
const { pool } = require('../config/db');
const { requireRole } = require('../middleware/auth');
const { sendDbError } = require('../utils/errors');
const { isValidDate, todayStr } = require('../utils/dates');

// All pet routes: owner only, and only their own pets.   [done — Phase 2]
// GET    /api/pets          -> owner's pets
// POST   /api/pets          body: { name, species, breed, gender, dob, weight_kg, notes }
// PUT    /api/pets/:id      (check pets.owner_id = session user)
// DELETE /api/pets/:id      (check ownership; cascades to appointments/records)
router.use(requireRole('owner'));

const SPECIES = ['Dog', 'Cat', 'Rabbit', 'Bird', 'Other'];
const GENDERS = ['Male', 'Female'];
const PET_COLUMNS = 'pet_id, name, species, breed, gender, dob, weight_kg, notes, created_at';

// Returns [error, cleanPet]
function validatePet(b = {}) {
  const str = (v) => (typeof v === 'string' ? v.trim() : '');
  const pet = {
    name: str(b.name),
    species: str(b.species),
    breed: str(b.breed) || null,
    gender: str(b.gender),
    dob: str(b.dob) || null,
    weight_kg: b.weight_kg === '' || b.weight_kg == null ? null : Number(b.weight_kg),
    notes: str(b.notes) || null
  };
  if (!pet.name || pet.name.length > 50) return ['Pet name is required (max 50 characters)'];
  if (!SPECIES.includes(pet.species)) return ['Species must be one of: ' + SPECIES.join(', ')];
  if (!GENDERS.includes(pet.gender)) return ['Gender must be Male or Female'];
  if (pet.breed && pet.breed.length > 60) return ['Breed is too long (max 60 characters)'];
  if (pet.dob) {
    if (!isValidDate(pet.dob)) return ['Date of birth must be a valid date'];
    if (pet.dob > todayStr()) return ['Date of birth cannot be in the future'];
  }
  if (pet.weight_kg !== null && (!Number.isFinite(pet.weight_kg) || pet.weight_kg <= 0 || pet.weight_kg >= 1000)) {
    return ['Weight must be a number of kg greater than 0'];
  }
  if (pet.notes && pet.notes.length > 255) return ['Notes are too long (max 255 characters)'];
  return [null, pet];
}

async function getOwnedPet(petId, ownerId) {
  const [rows] = await pool.execute(
    `SELECT ${PET_COLUMNS} FROM pets WHERE pet_id = ? AND owner_id = ?`, [petId, ownerId]);
  return rows[0] || null;
}

// GET /api/pets
router.get('/', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT ${PET_COLUMNS} FROM pets WHERE owner_id = ? ORDER BY name`, [req.session.user.user_id]);
    res.json(rows);
  } catch (err) {
    sendDbError(res, err);
  }
});

// POST /api/pets
router.post('/', async (req, res) => {
  const [error, pet] = validatePet(req.body);
  if (error) return res.status(400).json({ error });
  try {
    const [result] = await pool.execute(
      `INSERT INTO pets (owner_id, name, species, breed, gender, dob, weight_kg, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [req.session.user.user_id, pet.name, pet.species, pet.breed, pet.gender, pet.dob, pet.weight_kg, pet.notes]
    );
    res.status(201).json(await getOwnedPet(result.insertId, req.session.user.user_id));
  } catch (err) {
    sendDbError(res, err);
  }
});

// PUT /api/pets/:id
router.put('/:id', async (req, res) => {
  const [error, pet] = validatePet(req.body);
  if (error) return res.status(400).json({ error });
  try {
    const [result] = await pool.execute(
      `UPDATE pets SET name = ?, species = ?, breed = ?, gender = ?, dob = ?, weight_kg = ?, notes = ?
        WHERE pet_id = ? AND owner_id = ?`,
      [pet.name, pet.species, pet.breed, pet.gender, pet.dob, pet.weight_kg, pet.notes,
       req.params.id, req.session.user.user_id]
    );
    // 404 for someone else's pet too, so ids of other owners' pets aren't revealed
    if (!result.affectedRows) return res.status(404).json({ error: 'Pet not found' });
    res.json(await getOwnedPet(req.params.id, req.session.user.user_id));
  } catch (err) {
    sendDbError(res, err);
  }
});

// DELETE /api/pets/:id   (appointments and records for the pet are removed by ON DELETE CASCADE)
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await pool.execute(
      'DELETE FROM pets WHERE pet_id = ? AND owner_id = ?', [req.params.id, req.session.user.user_id]);
    if (!result.affectedRows) return res.status(404).json({ error: 'Pet not found' });
    res.json({ ok: true });
  } catch (err) {
    sendDbError(res, err);
  }
});

module.exports = router;
