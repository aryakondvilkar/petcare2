const router = require('express').Router();
const { pool } = require('../config/db');
const { sendDbError } = require('../utils/errors');

// GET /api/services   [done] — the 12 landing-page cards
router.get('/', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT service_id, name, caption, description, image_url, provider_role, duration_min, price
         FROM services WHERE is_active = TRUE ORDER BY service_id`
    );
    res.json(rows);
  } catch (err) {
    sendDbError(res, err);
  }
});

// GET /api/services/:id/providers   [done]
// providers whose role matches the service's provider_role, with rating
router.get('/:id/providers', async (req, res) => {
  try {
    const [svc] = await pool.execute('SELECT provider_role FROM services WHERE service_id = ?', [req.params.id]);
    if (!svc.length) return res.status(404).json({ error: 'Service not found' });
    const [rows] = await pool.execute(
      `SELECT user_id, full_name, role, qualification, experience_years, bio,
              work_start, work_end, avg_rating, review_count
         FROM v_provider_directory WHERE role = ? ORDER BY full_name`,
      [svc[0].provider_role]
    );
    res.json(rows);
  } catch (err) {
    sendDbError(res, err);
  }
});

module.exports = router;
