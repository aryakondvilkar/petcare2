const router = require('express').Router();
const { pool } = require('../config/db');
const { requireRole } = require('../middleware/auth');
const { sendDbError } = require('../utils/errors');

// POST /api/reviews   [done — Phase 3]
// owner only. body: { appointment_id, rating (1-5), comment }
// - look up the appointment, check owner_id = me, take provider_id from it
// - trigger enforces status = 'Completed'; UNIQUE(appointment_id) enforces one review
router.post('/', requireRole('owner'), async (req, res) => {
  const b = req.body || {};
  const rating = Number(b.rating);
  const comment = typeof b.comment === 'string' ? b.comment.trim() : '';
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
    return res.status(400).json({ error: 'Rating must be a whole number from 1 to 5' });
  }
  if (comment.length > 500) return res.status(400).json({ error: 'Comment is too long (max 500 characters)' });

  try {
    const [rows] = await pool.execute(
      'SELECT appointment_id, owner_id, provider_id, status FROM appointments WHERE appointment_id = ?',
      [b.appointment_id]
    );
    const appt = rows[0];
    if (!appt || appt.owner_id !== req.session.user.user_id) {
      return res.status(404).json({ error: 'Appointment not found' });
    }
    if (appt.status !== 'Completed') {
      return res.status(400).json({ error: 'Only completed appointments can be reviewed' });
    }
    // a second review hits UNIQUE(appointment_id) -> 409 'This appointment has already been reviewed'
    const [result] = await pool.execute(
      `INSERT INTO reviews (appointment_id, owner_id, provider_id, rating, comment) VALUES (?, ?, ?, ?, ?)`,
      [appt.appointment_id, appt.owner_id, appt.provider_id, rating, comment || null]
    );
    const [created] = await pool.execute(
      'SELECT review_id, appointment_id, rating, comment, created_at FROM reviews WHERE review_id = ?', [result.insertId]);
    res.status(201).json(created[0]);
  } catch (err) {
    sendDbError(res, err);
  }
});

router.all('*', requireRole('owner'), (req, res) => res.status(404).json({ error: 'API route not found' }));

module.exports = router;
