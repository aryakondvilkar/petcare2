const router = require('express').Router();
const { pool } = require('../config/db');
const { requireLogin, requireRole, PROVIDER_ROLES } = require('../middleware/auth');
const { sendDbError } = require('../utils/errors');

const { isValidDate, todayStr } = require('../utils/dates');
const { getProvider, getSlots } = require('../utils/availability');
const { loadAppointmentFor } = require('../utils/access');

// ---------- /me routes (declared ABOVE '/:id/...') ----------

const PROFILE_SELECT = `
  SELECT u.user_id, u.full_name, u.username, u.role, u.email, u.phone, u.address, u.city, u.created_at,
         p.qualification, p.license_no, p.experience_years, p.bio, p.work_start, p.work_end
    FROM users u JOIN provider_profiles p ON p.provider_id = u.user_id
   WHERE u.user_id = ?`;

// GET /api/providers/me/profile   [done — Phase 4]
router.get('/me/profile', requireRole(...PROVIDER_ROLES), async (req, res) => {
  try {
    const [rows] = await pool.execute(PROFILE_SELECT, [req.session.user.user_id]);
    if (!rows.length) return res.status(404).json({ error: 'Profile not found' });
    res.json(rows[0]);
  } catch (err) {
    sendDbError(res, err);
  }
});

// PUT /api/providers/me/profile   [done — Phase 4]
// body: { qualification, license_no, experience_years, bio, work_start, work_end, phone, address }
router.put('/me/profile', requireRole(...PROVIDER_ROLES), async (req, res) => {
  const user = req.session.user;
  const b = req.body || {};
  const str = (v) => (typeof v === 'string' ? v.trim() : '');
  const qualification = str(b.qualification);
  const license_no = str(b.license_no) || null;
  const bio = str(b.bio) || null;
  const phone = str(b.phone).replace(/[\s-]/g, '');
  const address = str(b.address) || null;
  const experience = Number(b.experience_years);
  const hourOf = (t) => { const m = str(t).match(/^(\d{2}):00(:00)?$/); return m ? Number(m[1]) : null; };
  const startH = hourOf(b.work_start);
  const endH = hourOf(b.work_end);

  if (!qualification || qualification.length > 120) return res.status(400).json({ error: 'Qualification is required (max 120 characters)' });
  if (user.role === 'vet' && !license_no) return res.status(400).json({ error: 'A license number is required for vets' });
  if (license_no && license_no.length > 40) return res.status(400).json({ error: 'License number is too long (max 40 characters)' });
  if (!Number.isInteger(experience) || experience < 0 || experience > 60) {
    return res.status(400).json({ error: 'Experience must be a whole number of years from 0 to 60' });
  }
  if (bio && bio.length > 500) return res.status(400).json({ error: 'Bio is too long (max 500 characters)' });
  if (!/^\+?\d{10,14}$/.test(phone)) return res.status(400).json({ error: 'Phone must be 10–14 digits' });
  if (address && address.length > 255) return res.status(400).json({ error: 'Address is too long' });
  if (startH === null || endH === null || startH < 6 || endH > 22) {
    return res.status(400).json({ error: 'Working hours must be whole hours between 06:00 and 22:00' });
  }
  if (endH <= startH) return res.status(400).json({ error: 'Work end must be after work start' });

  let conn;
  try {
    conn = await pool.getConnection();
    await conn.beginTransaction();
    await conn.execute('UPDATE users SET phone = ?, address = ? WHERE user_id = ?', [phone, address, user.user_id]);
    await conn.execute(
      `UPDATE provider_profiles SET qualification = ?, license_no = ?, experience_years = ?, bio = ?,
              work_start = ?, work_end = ? WHERE provider_id = ?`,
      [qualification, license_no, experience, bio, `${String(startH).padStart(2, '0')}:00:00`,
       `${String(endH).padStart(2, '0')}:00:00`, user.user_id]
    );
    await conn.commit();
    const [rows] = await pool.execute(PROFILE_SELECT, [user.user_id]);
    res.json(rows[0]);
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    sendDbError(res, err);
  } finally {
    if (conn) conn.release();
  }
});

// GET /api/providers/me/reviews   [done — Phase 4]  -> { average, count, reviews: [...] }
router.get('/me/reviews', requireRole(...PROVIDER_ROLES), async (req, res) => {
  try {
    const [reviews] = await pool.execute(
      `SELECT r.review_id, r.appointment_id, r.rating, r.comment, r.created_at,
              o.full_name AS owner_name, pt.name AS pet_name, pt.species, s.name AS service_name, a.appt_date
         FROM reviews r
         JOIN appointments a ON a.appointment_id = r.appointment_id
         JOIN users o        ON o.user_id = r.owner_id
         JOIN pets pt        ON pt.pet_id = a.pet_id
         JOIN services s     ON s.service_id = a.service_id
        WHERE r.provider_id = ?
        ORDER BY r.created_at DESC, r.review_id DESC`,
      [req.session.user.user_id]
    );
    const count = reviews.length;
    const average = count ? Math.round((reviews.reduce((t, r) => t + r.rating, 0) / count) * 10) / 10 : null;
    res.json({ average, count, reviews });
  } catch (err) {
    sendDbError(res, err);
  }
});

// ---------- /:id routes ----------

// GET /api/providers/:id/availability?date=YYYY-MM-DD[&pet_id=][&appointment_id=]   [done — Phase 2]
// appointment_id (rescheduling): that appointment's own slot comes back as 'Current slot'.
// Returns one entry per hourly slot 09:00..17:00:
//   { time: '09:00', available: true }
//   { time: '10:00', available: false, reason: 'This slot is not available' }  // booked (status <> 'Cancelled')
//   { time: '11:00', available: false, reason: 'Time has passed' }             // today and hour already gone
// Also 'Outside working hours' (provider_profiles.work_start/work_end) and, when an owner passes
// pet_id, 'Your pet already has an appointment at this time'.
router.get('/:id/availability', requireLogin, async (req, res) => {
  const { date } = req.query;
  if (!isValidDate(date)) return res.status(400).json({ error: 'date must be a valid YYYY-MM-DD date' });
  if (date < todayStr()) return res.status(400).json({ error: 'Cannot book a date that has already passed' });
  try {
    const provider = await getProvider(req.params.id);
    if (!provider) return res.status(404).json({ error: 'Provider not found' });

    let petId = null;
    let appointmentId = null;
    if (req.query.appointment_id) {
      // rescheduling: only for someone on that appointment with this provider
      const appt = await loadAppointmentFor(req.session.user, req.query.appointment_id);
      if (!appt || appt.provider_id !== provider.user_id) {
        return res.status(404).json({ error: 'Appointment not found' });
      }
      appointmentId = appt.appointment_id;
      petId = appt.pet_id;
    } else if (req.query.pet_id && req.session.user.role === 'owner') {
      // only use pet_id for the owner's own pet
      const [pets] = await pool.execute('SELECT pet_id FROM pets WHERE pet_id = ? AND owner_id = ?',
        [req.query.pet_id, req.session.user.user_id]);
      if (pets.length) petId = pets[0].pet_id;
    }
    res.json(await getSlots(provider, date, { petId, appointmentId }));
  } catch (err) {
    sendDbError(res, err);
  }
});

module.exports = router;
