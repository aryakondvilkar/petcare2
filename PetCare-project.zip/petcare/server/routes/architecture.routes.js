const router = require('express').Router();
const { pool } = require('../config/db');
const { sendDbError } = require('../utils/errors');

// Public, read-only. Powers /architecture.html.

// What each trigger enforces (names come from schema.sql)
const TRIGGER_RULES = {
  trg_appt_before_insert: 'B1 no booking in the past · B5 provider role must match the service · B6 pet must belong to the booking owner',
  trg_appt_before_update: 'B2 no reschedule into the past · B9 completed/cancelled appointments cannot be rescheduled',
  trg_review_before_insert: 'B8 only completed appointments can be reviewed, by that appointment\'s owner, for its provider'
};

// GET /api/architecture/schema   [done — Phase 5]
// Read live from INFORMATION_SCHEMA for the current database.
// Response: { database, tables: [{ name, type, rows, columns, foreignKeys, uniques, checks }], triggers }
router.get('/schema', async (req, res) => {
  try {
    const [tables] = await pool.query(
      `SELECT TABLE_NAME AS name, TABLE_TYPE AS type FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_TYPE, CREATE_TIME, TABLE_NAME`
    );
    const [columns] = await pool.query(
      `SELECT TABLE_NAME AS tbl, COLUMN_NAME AS name, COLUMN_TYPE AS type, IS_NULLABLE AS nullable,
              COLUMN_KEY AS col_key, COLUMN_DEFAULT AS col_default, EXTRA AS extra, GENERATION_EXPRESSION AS generation_expr
         FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE()
        ORDER BY TABLE_NAME, ORDINAL_POSITION`
    );
    const [fks] = await pool.query(
      `SELECT k.TABLE_NAME AS tbl, k.CONSTRAINT_NAME AS name, k.COLUMN_NAME AS col,
              k.REFERENCED_TABLE_NAME AS ref_table, k.REFERENCED_COLUMN_NAME AS ref_col,
              r.DELETE_RULE AS on_delete
         FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE k
         JOIN INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS r
           ON r.CONSTRAINT_SCHEMA = k.CONSTRAINT_SCHEMA AND r.CONSTRAINT_NAME = k.CONSTRAINT_NAME
        WHERE k.TABLE_SCHEMA = DATABASE() AND k.REFERENCED_TABLE_NAME IS NOT NULL
        ORDER BY k.TABLE_NAME, k.ORDINAL_POSITION`
    );
    const [uniques] = await pool.query(
      `SELECT t.TABLE_NAME AS tbl, t.CONSTRAINT_NAME AS name,
              GROUP_CONCAT(k.COLUMN_NAME ORDER BY k.ORDINAL_POSITION SEPARATOR ', ') AS cols
         FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS t
         JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE k
           ON k.CONSTRAINT_SCHEMA = t.CONSTRAINT_SCHEMA AND k.TABLE_NAME = t.TABLE_NAME AND k.CONSTRAINT_NAME = t.CONSTRAINT_NAME
        WHERE t.TABLE_SCHEMA = DATABASE() AND t.CONSTRAINT_TYPE = 'UNIQUE'
        GROUP BY t.TABLE_NAME, t.CONSTRAINT_NAME`
    );
    const [checks] = await pool.query(
      `SELECT t.TABLE_NAME AS tbl, c.CONSTRAINT_NAME AS name, c.CHECK_CLAUSE AS clause
         FROM INFORMATION_SCHEMA.CHECK_CONSTRAINTS c
         JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS t
           ON t.CONSTRAINT_SCHEMA = c.CONSTRAINT_SCHEMA AND t.CONSTRAINT_NAME = c.CONSTRAINT_NAME
        WHERE c.CONSTRAINT_SCHEMA = DATABASE()
        ORDER BY t.TABLE_NAME, c.CONSTRAINT_NAME`
    );
    const [triggers] = await pool.query(
      `SELECT TRIGGER_NAME AS name, ACTION_TIMING AS timing, EVENT_MANIPULATION AS event, EVENT_OBJECT_TABLE AS tbl
         FROM INFORMATION_SCHEMA.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE() ORDER BY TRIGGER_NAME`
    );
    const [[{ db }]] = await pool.query('SELECT DATABASE() AS db');

    const result = [];
    for (const t of tables) {
      // table names come from INFORMATION_SCHEMA, not from the request; still only allow plain identifiers
      if (!/^[A-Za-z0-9_]+$/.test(t.name)) continue;
      const [[{ n }]] = await pool.query(`SELECT COUNT(*) AS n FROM \`${t.name}\``);
      result.push({
        name: t.name,
        type: t.type === 'VIEW' ? 'VIEW' : 'TABLE',
        rows: n,
        columns: columns.filter((c) => c.tbl === t.name).map(({ tbl, ...c }) => c),
        foreignKeys: fks.filter((f) => f.tbl === t.name).map(({ tbl, ...f }) => f),
        uniques: uniques.filter((u) => u.tbl === t.name).map(({ tbl, ...u }) => u),
        checks: checks.filter((c) => c.tbl === t.name).map(({ tbl, ...c }) => c)
      });
    }
    res.json({
      database: db,
      tables: result,
      triggers: triggers.map((t) => ({ ...t, enforces: TRIGGER_RULES[t.name] || '' }))
    });
  } catch (err) {
    sendDbError(res, err);
  }
});

// GET /api/architecture/users   [done — Phase 5]
// { owners:[...], vets:[...], groomers:[...], walkers:[...] } with ALL details (SPEC R7.3)
// password_hash is never selected — every row gets password: '•••••• (bcrypt)' instead.
const MASK = '•••••• (bcrypt)';

router.get('/users', async (req, res) => {
  try {
    const [owners] = await pool.query(
      `SELECT u.user_id, u.full_name, u.username, u.email, u.phone, u.address, u.city, u.created_at,
              COUNT(p.pet_id) AS pet_count,
              GROUP_CONCAT(p.name ORDER BY p.name SEPARATOR ', ') AS pet_names,
              (SELECT COUNT(*) FROM appointments a WHERE a.owner_id = u.user_id) AS appointment_count
         FROM users u LEFT JOIN pets p ON p.owner_id = u.user_id
        WHERE u.role = 'owner'
        GROUP BY u.user_id, u.full_name, u.username, u.email, u.phone, u.address, u.city, u.created_at
        ORDER BY u.user_id`
    );
    const [providers] = await pool.query(
      `SELECT u.user_id, u.role, u.full_name, u.username, u.email, u.phone, u.address, u.city, u.created_at,
              pp.qualification, pp.license_no, pp.experience_years, pp.bio, pp.work_start, pp.work_end,
              d.avg_rating, d.review_count,
              (SELECT COUNT(*) FROM appointments a WHERE a.provider_id = u.user_id) AS appointment_count
         FROM users u
         JOIN provider_profiles pp ON pp.provider_id = u.user_id
         LEFT JOIN v_provider_directory d ON d.user_id = u.user_id
        WHERE u.role IN ('vet','groomer','walker')
        ORDER BY u.user_id`
    );
    const mask = (r) => ({ ...r, password: MASK });
    res.json({
      owners: owners.map(mask),
      vets: providers.filter((p) => p.role === 'vet').map(mask),
      groomers: providers.filter((p) => p.role === 'groomer').map(mask),
      walkers: providers.filter((p) => p.role === 'walker').map(mask)
    });
  } catch (err) {
    sendDbError(res, err);
  }
});

router.all('*', (req, res) => res.status(404).json({ error: 'API route not found' }));

module.exports = router;
