const router = require('express').Router();
const { pool } = require('../config/db');
const { requireLogin } = require('../middleware/auth');
const { sendDbError } = require('../utils/errors');
const { loadAppointmentFor, loadAppointment, petOwnerId, providerHasPet, canUseRecord, selectRecords } = require('../utils/access');

// Rule B11: a record can be read/edited by
//   - the owner of the pet (pets.owner_id), or
//   - the provider of the linked appointment (appointments.provider_id)
//   - for records with appointment_id NULL: owner, or any provider who has an appointment with that pet
//
// GET  /api/records?pet_id=..  or  ?appointment_id=..     [done — Phase 3]
// POST /api/records    body: { pet_id, appointment_id?, record_type, title, details }   [done]
// PUT  /api/records/:id body: { record_type?, title?, details? } -> sets last_edited_by = me   [done]
router.use(requireLogin);

const TYPES = ['Remark', 'Medical', 'Vaccination', 'Grooming', 'Behaviour'];

// Returns an error message, or null. `partial` = only check fields that were sent (PUT)
function validateRecord(b, partial) {
  if (!partial || b.record_type !== undefined) {
    if (!TYPES.includes(b.record_type)) return 'Type must be one of: ' + TYPES.join(', ');
  }
  if (!partial || b.title !== undefined) {
    const t = typeof b.title === 'string' ? b.title.trim() : '';
    if (!t || t.length > 100) return 'Title is required (max 100 characters)';
  }
  if (!partial || b.details !== undefined) {
    const d = typeof b.details === 'string' ? b.details.trim() : '';
    if (!d || d.length > 5000) return 'Details are required (max 5000 characters)';
  }
  return null;
}

// GET /api/records?pet_id=  |  ?appointment_id=
router.get('/', async (req, res) => {
  const user = req.session.user;
  try {
    if (req.query.appointment_id) {
      const appt = await loadAppointmentFor(user, req.query.appointment_id);
      if (!appt) return res.status(404).json({ error: 'Appointment not found' });
      return res.json(await selectRecords('r.appointment_id = ?', [appt.appointment_id]));
    }
    if (req.query.pet_id) {
      const petId = Number(req.query.pet_id);
      if (user.role === 'owner') {
        if ((await petOwnerId(petId)) !== user.user_id) return res.status(404).json({ error: 'Pet not found' });
        return res.json(await selectRecords('r.pet_id = ?', [petId]));
      }
      // provider: records from their own appointments with the pet, plus the pet's general records
      if (!(await providerHasPet(user.user_id, petId))) return res.status(404).json({ error: 'Pet not found' });
      return res.json(await selectRecords(
        'r.pet_id = ? AND (r.appointment_id IS NULL OR a.provider_id = ?)', [petId, user.user_id]));
    }
    res.status(400).json({ error: 'Pass pet_id or appointment_id' });
  } catch (err) {
    sendDbError(res, err);
  }
});

// POST /api/records
router.post('/', async (req, res) => {
  const user = req.session.user;
  const b = req.body || {};
  const error = validateRecord(b, false);
  if (error) return res.status(400).json({ error });
  const petId = Number(b.pet_id);
  if (!Number.isInteger(petId) || petId < 1) return res.status(400).json({ error: 'pet_id is required' });

  try {
    let appt = null;
    if (b.appointment_id) {
      appt = await loadAppointmentFor(user, b.appointment_id);
      if (!appt) return res.status(404).json({ error: 'Appointment not found' });
      if (appt.pet_id !== petId) return res.status(400).json({ error: 'This appointment is for a different pet' });
    }
    if (!(await canUseRecord(user, petId, appt))) {
      return res.status(403).json({ error: 'You can only add records for your own pets or your own appointments' });
    }
    const [result] = await pool.execute(
      `INSERT INTO pet_records (pet_id, appointment_id, record_type, title, details, created_by, last_edited_by)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [petId, appt ? appt.appointment_id : null, b.record_type, b.title.trim(), b.details.trim(), user.user_id, user.user_id]
    );
    res.status(201).json((await selectRecords('r.record_id = ?', [result.insertId]))[0]);
  } catch (err) {
    sendDbError(res, err);
  }
});

// PUT /api/records/:id
router.put('/:id', async (req, res) => {
  const user = req.session.user;
  const b = req.body || {};
  const error = validateRecord(b, true);
  if (error) return res.status(400).json({ error });

  try {
    const [rows] = await pool.execute('SELECT pet_id, appointment_id FROM pet_records WHERE record_id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Record not found' });
    const appt = rows[0].appointment_id ? await loadAppointment(rows[0].appointment_id) : null;
    if (!(await canUseRecord(user, rows[0].pet_id, appt))) {
      return res.status(403).json({ error: 'You can only edit records for your own pets or your own appointments' });
    }

    const sets = [];
    const params = [];
    for (const k of ['record_type', 'title', 'details']) {
      if (b[k] !== undefined) { sets.push(`${k} = ?`); params.push(typeof b[k] === 'string' ? b[k].trim() : b[k]); }
    }
    if (!sets.length) return res.status(400).json({ error: 'Nothing to update' });
    sets.push('last_edited_by = ?');
    params.push(user.user_id, req.params.id);
    await pool.execute(`UPDATE pet_records SET ${sets.join(', ')} WHERE record_id = ?`, params);
    res.json((await selectRecords('r.record_id = ?', [req.params.id]))[0]);
  } catch (err) {
    sendDbError(res, err);
  }
});

router.all('*', (req, res) => res.status(404).json({ error: 'API route not found' }));

module.exports = router;
