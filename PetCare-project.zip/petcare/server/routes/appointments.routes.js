const router = require('express').Router();
const { pool } = require('../config/db');
const { requireLogin, requireRole, PROVIDER_ROLES } = require('../middleware/auth');
const { sendDbError } = require('../utils/errors');
const { isValidDate, parseSlot, slotHasPassed, slotLabel } = require('../utils/dates');
const { getProvider, getSlots, REASON_PASSED, REASON_CURRENT } = require('../utils/availability');
const { loadAppointmentFor, selectRecords } = require('../utils/access');

// POST /api/appointments                                  [done — Phase 2]
//      owner only. body: { pet_id, service_id, provider_id, appt_date, start_time, owner_note }
// GET  /api/appointments/mine?scope=upcoming|past|all     [done — Phase 3]
//      owner -> their bookings, provider -> bookings with them (this is how owner bookings reach provider dashboards)
// GET  /api/appointments/:id                              [done — Phase 3]
//      only the owner or provider on it; includes records, reschedule history and review
// PUT  /api/appointments/:id/reschedule                   [done — Phase 3]
//      owner or provider on it. body: { appt_date, start_time, reason }
// PUT  /api/appointments/:id/status                       [done — Phase 3]
//      body: { status: 'Completed' | 'Cancelled' }
//      Completed: provider only, once the appointment time has started
//      Cancelled: owner or provider
//      both only from Booked / Rescheduled

const OPEN = ['Booked', 'Rescheduled'];
const toInt = (v) => (Number.isInteger(Number(v)) && Number(v) > 0 ? Number(v) : null);

// v_appointment_details plus the extra contact/pet/service details the dashboards show
const DETAIL_SELECT = `
  SELECT v.*, s.caption AS service_caption, s.duration_min,
         o.email AS owner_email, o.address AS owner_address,
         pr.phone AS provider_phone, pr.email AS provider_email,
         p.gender AS pet_gender, p.dob AS pet_dob, p.weight_kg AS pet_weight, p.notes AS pet_notes
    FROM v_appointment_details v
    JOIN services s ON s.service_id = v.service_id
    JOIN users o    ON o.user_id = v.owner_id
    JOIN users pr   ON pr.user_id = v.provider_id
    JOIN pets p     ON p.pet_id = v.pet_id`;

// what the current user may do next (the UI shows/hides actions with these; the routes re-check)
function withFlags(row, user) {
  const open = OPEN.includes(row.status);
  const started = slotHasPassed(row.appt_date, Number(row.start_time.slice(0, 2)));
  const isProvider = user.user_id === row.provider_id;
  const isOwner = user.user_id === row.owner_id;
  return {
    ...row,
    can_reschedule: open,
    can_cancel: open,
    can_complete: isProvider && open && started,
    can_review: isOwner && row.status === 'Completed' && row.rating === null
  };
}

async function loadDetail(id, user) {
  const [rows] = await pool.execute(`${DETAIL_SELECT} WHERE v.appointment_id = ?`, [id]);
  return rows[0] ? withFlags(rows[0], user) : null;
}

// POST /api/appointments
// Re-checks every rule before inserting; the trigger and unique indexes are the last line of defence.
router.post('/', requireRole('owner'), async (req, res) => {
  const b = req.body || {};
  const ownerId = req.session.user.user_id;
  const petId = toInt(b.pet_id);
  const serviceId = toInt(b.service_id);
  const providerId = toInt(b.provider_id);
  const date = b.appt_date;
  const hour = parseSlot(b.start_time);
  const note = typeof b.owner_note === 'string' ? b.owner_note.trim() : '';

  if (!petId || !serviceId || !providerId) {
    return res.status(400).json({ error: 'Please choose a pet, a service and a provider' });
  }
  if (!isValidDate(date)) return res.status(400).json({ error: 'Please choose a valid date' });
  if (hour === null) return res.status(400).json({ error: 'Please choose an hourly slot between 09:00 and 17:00' });
  if (note.length > 255) return res.status(400).json({ error: 'Note is too long (max 255 characters)' });
  // B1: no past date or time
  if (slotHasPassed(date, hour)) {
    return res.status(400).json({ error: 'Cannot book a date or time that has already passed' });
  }

  try {
    // B6: own pet only (404 so other owners' pet ids aren't revealed)
    const [pets] = await pool.execute('SELECT pet_id FROM pets WHERE pet_id = ? AND owner_id = ?', [petId, ownerId]);
    if (!pets.length) return res.status(404).json({ error: 'Pet not found' });

    const [services] = await pool.execute(
      'SELECT provider_role FROM services WHERE service_id = ? AND is_active = TRUE', [serviceId]);
    if (!services.length) return res.status(404).json({ error: 'Service not found' });

    // B5: provider must match the service
    const provider = await getProvider(providerId);
    if (!provider) return res.status(404).json({ error: 'Provider not found' });
    if (provider.role !== services[0].provider_role) {
      return res.status(400).json({ error: 'This provider does not offer the selected service' });
    }

    // B3 / B4 / working hours: same check the slot list uses
    const slot = (await getSlots(provider, date, { petId })).find((s) => s.time === slotLabel(hour));
    if (!slot.available) {
      const status = slot.reason === REASON_PASSED ? 400 : 409;
      return res.status(status).json({ error: slot.reason });
    }

    // a concurrent booking of the same slot is rejected here by uq_provider_slot -> 409
    const [result] = await pool.execute(
      `INSERT INTO appointments (owner_id, pet_id, provider_id, service_id, appt_date, start_time, owner_note)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [ownerId, petId, providerId, serviceId, date, slotLabel(hour) + ':00', note || null]
    );
    res.status(201).json(await loadDetail(result.insertId, req.session.user));
  } catch (err) {
    sendDbError(res, err);
  }
});

// GET /api/appointments/mine?scope=upcoming|past|all
// upcoming = still open (Booked/Rescheduled) and not yet over; past = everything else
router.get('/mine', requireLogin, async (req, res) => {
  const user = req.session.user;
  const scope = req.query.scope || 'all';
  if (!['upcoming', 'past', 'all'].includes(scope)) {
    return res.status(400).json({ error: 'scope must be upcoming, past or all' });
  }
  const who = user.role === 'owner' ? 'v.owner_id = ?' : 'v.provider_id = ?';
  const upcoming = `v.status IN ('Booked','Rescheduled')
                    AND TIMESTAMP(v.appt_date, v.start_time) > NOW() - INTERVAL 1 HOUR`;
  const filter = { upcoming: `AND ${upcoming}`, past: `AND NOT (${upcoming})`, all: '' }[scope];
  const order = scope === 'upcoming' ? 'ASC' : 'DESC';
  try {
    const [rows] = await pool.execute(
      `${DETAIL_SELECT} WHERE ${who} ${filter}
        ORDER BY v.appt_date ${order}, v.start_time ${order}`,
      [user.user_id]
    );
    res.json(rows.map((r) => withFlags(r, user)));
  } catch (err) {
    sendDbError(res, err);
  }
});

// GET /api/appointments/:id   -> { appointment, records, history, review }
router.get('/:id', requireLogin, async (req, res) => {
  const user = req.session.user;
  try {
    const appt = await loadAppointmentFor(user, req.params.id);
    if (!appt) return res.status(404).json({ error: 'Appointment not found' });

    const [history] = await pool.execute(
      `SELECT h.reschedule_id, h.old_date, h.old_time, h.new_date, h.new_time, h.reason, h.changed_at,
              u.full_name AS rescheduled_by_name, u.role AS rescheduled_by_role
         FROM reschedule_history h JOIN users u ON u.user_id = h.rescheduled_by
        WHERE h.appointment_id = ? ORDER BY h.changed_at DESC, h.reschedule_id DESC`,
      [appt.appointment_id]
    );
    const [reviews] = await pool.execute(
      'SELECT review_id, rating, comment, created_at FROM reviews WHERE appointment_id = ?', [appt.appointment_id]);

    res.json({
      appointment: await loadDetail(appt.appointment_id, user),
      records: await selectRecords('r.appointment_id = ?', [appt.appointment_id]),
      history,
      review: reviews[0] || null
    });
  } catch (err) {
    sendDbError(res, err);
  }
});

// PUT /api/appointments/:id/reschedule   body: { appt_date, start_time, reason? }
// Same provider, new date/slot. Transaction: update the appointment + write reschedule_history.
router.put('/:id/reschedule', requireLogin, async (req, res) => {
  const user = req.session.user;
  const b = req.body || {};
  const date = b.appt_date;
  const hour = parseSlot(b.start_time);
  const reason = typeof b.reason === 'string' ? b.reason.trim() : '';

  if (!isValidDate(date)) return res.status(400).json({ error: 'Please choose a valid date' });
  if (hour === null) return res.status(400).json({ error: 'Please choose an hourly slot between 09:00 and 17:00' });
  if (reason.length > 255) return res.status(400).json({ error: 'Reason is too long (max 255 characters)' });
  // B2: no moving into the past
  if (slotHasPassed(date, hour)) {
    return res.status(400).json({ error: 'Cannot reschedule to a date or time that has already passed' });
  }

  let conn;
  try {
    const appt = await loadAppointmentFor(user, req.params.id);
    if (!appt) return res.status(404).json({ error: 'Appointment not found' });
    // B9
    if (!OPEN.includes(appt.status)) {
      return res.status(400).json({ error: 'A completed or cancelled appointment cannot be rescheduled' });
    }

    const provider = await getProvider(appt.provider_id);
    const slot = (await getSlots(provider, date, { petId: appt.pet_id, appointmentId: appt.appointment_id }))
      .find((s) => s.time === slotLabel(hour));
    if (slot.reason === REASON_CURRENT) {
      return res.status(400).json({ error: 'That is already the current slot. Pick a different one.' });
    }
    if (!slot.available) {
      return res.status(slot.reason === REASON_PASSED ? 400 : 409).json({ error: slot.reason });
    }

    conn = await pool.getConnection();
    await conn.beginTransaction();
    // lock the row and re-read it, in case it changed since the checks above
    const [locked] = await conn.execute(
      'SELECT appt_date, start_time, status FROM appointments WHERE appointment_id = ? FOR UPDATE',
      [appt.appointment_id]
    );
    if (!OPEN.includes(locked[0].status)) {
      await conn.rollback();
      return res.status(409).json({ error: 'This appointment was just completed or cancelled' });
    }
    const newTime = slotLabel(hour) + ':00';
    // the trigger re-checks B2/B9; uq_provider_slot / uq_pet_slot reject a slot taken meanwhile (409)
    await conn.execute(
      `UPDATE appointments SET appt_date = ?, start_time = ?, status = 'Rescheduled' WHERE appointment_id = ?`,
      [date, newTime, appt.appointment_id]
    );
    await conn.execute(
      `INSERT INTO reschedule_history (appointment_id, old_date, old_time, new_date, new_time, rescheduled_by, reason)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [appt.appointment_id, locked[0].appt_date, locked[0].start_time, date, newTime, user.user_id, reason || null]
    );
    await conn.commit();
    res.json(await loadDetail(appt.appointment_id, user));
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    sendDbError(res, err);
  } finally {
    if (conn) conn.release();
  }
});

// PUT /api/appointments/:id/status   body: { status: 'Completed' | 'Cancelled' }
router.put('/:id/status', requireLogin, async (req, res) => {
  const user = req.session.user;
  const status = (req.body || {}).status;
  if (!['Completed', 'Cancelled'].includes(status)) {
    return res.status(400).json({ error: 'status must be Completed or Cancelled' });
  }
  try {
    const appt = await loadAppointmentFor(user, req.params.id);
    if (!appt) return res.status(404).json({ error: 'Appointment not found' });
    if (!OPEN.includes(appt.status)) {
      return res.status(400).json({ error: `This appointment is already ${appt.status.toLowerCase()}` });
    }
    if (status === 'Completed') {
      if (appt.provider_id !== user.user_id || !PROVIDER_ROLES.includes(user.role)) {
        return res.status(403).json({ error: 'Only the provider can mark an appointment as completed' });
      }
      if (!slotHasPassed(appt.appt_date, Number(appt.start_time.slice(0, 2)))) {
        return res.status(400).json({ error: 'You can mark it completed once the appointment time has started' });
      }
    }
    // the status condition makes this safe if two people act at once
    const [result] = await pool.execute(
      `UPDATE appointments SET status = ? WHERE appointment_id = ? AND status IN ('Booked','Rescheduled')`,
      [status, appt.appointment_id]
    );
    if (!result.affectedRows) {
      return res.status(409).json({ error: 'This appointment was just changed. Refresh and try again.' });
    }
    res.json(await loadDetail(appt.appointment_id, user));
  } catch (err) {
    sendDbError(res, err);
  }
});

// keep LAST: anything else under /api/appointments
router.all('*', requireLogin, (req, res) => res.status(404).json({ error: 'API route not found' }));

module.exports = router;
