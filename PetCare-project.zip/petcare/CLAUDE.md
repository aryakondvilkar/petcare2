# CLAUDE.md — PetCare

You are the developer on **PetCare**, a pet-services booking web app (DBMS project).
The project lead has already written the spec, the database and the server foundation.
Your job is to build the features phase by phase.

## Read these first, every session
1. `docs/SPEC.md`: what to build (requirements R1–R9, business rules B1–B11)
2. `docs/API.md`: the exact endpoints, request and response shapes, and which are **[done]** or **[todo]**
3. `docs/PHASES.md`: the build order. Work on **one phase at a time** and stop at the end of it for review.

## Stack (do not change)
- **Backend:** Node.js + Express 4, `mysql2/promise` pool (`server/config/db.js`), `express-session`, `bcryptjs`, `dotenv`
- **Database:** MySQL 8. The schema is in `database/schema.sql` and the sample data in `database/seed.sql`
- **Frontend:** plain HTML + CSS + vanilla JS in `public/`, served statically by Express. **No React, no bundler, no Tailwind build.**
- Port 3000. Run with `npm run dev` (nodemon).

## Rules
- **Don't add, drop or rename tables or columns** without asking. The 8 tables are final:
  users, provider_profiles, pets, services, appointments, reschedule_history, pet_records, reviews (+ 2 views).
  If a schema change is truly needed, edit `schema.sql` (and `seed.sql`), explain why, and tell the user to re-import.
- **Constraints live in the database AND the API.** Never rely on the frontend alone. Let the DB triggers and unique
  indexes be the last line of defence, and turn their errors into clean messages with `server/utils/errors.js`.
- Always use **parameterised queries** (`pool.execute(sql, [params])`). Never build SQL strings out of user input.
- Never send `password_hash` to the client, not even on the architecture page.
- Every route checks auth and role with `requireLogin` / `requireRole(...)` from `server/middleware/auth.js`, and checks
  **ownership** (an owner touches only their own pets and appointments; a provider touches only appointments assigned to them).
- Dates: send them as `YYYY-MM-DD` strings and times as `HH:00`. Compare "now" using the server's local time.
  `db.js` sets `dateStrings: true` so MySQL dates come back as strings, not JS Date objects.
- Keep the frontend in the existing files: `public/js/api.js` (fetch wrapper), one JS file per page,
  `public/css/style.css` for all styles (design tokens are in `:root`).
- The UI shows **"This slot is not available"** word for word for slots that are already booked.
- Indian sample data, ₹ prices.
- After each phase, update the **[todo] → [done]** markers in `docs/API.md` and tick the phase in `docs/PHASES.md`.

## Commands
```bash
npm install
mysql -u root -p < database/schema.sql
mysql -u root -p petcare < database/seed.sql
cp .env.example .env      # then put your MySQL password in .env
npm run dev               # http://localhost:3000
```
Re-run the two mysql commands any time you want a fresh database.

## Testing checklist (run it before saying a phase is done)
- `owner1` can't book yesterday, or today at an hour that has passed
- `owner1` booking `groomer1` at the same date and time as `owner3`'s booking gets "This slot is not available"
- A booking made by `owner1` shows up on `vet1`'s dashboard after a refresh
- Records edited by the owner are visible to the provider, and the other way round
- A review is possible only on a Completed appointment, and only once
