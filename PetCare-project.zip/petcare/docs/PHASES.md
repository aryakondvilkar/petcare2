# PetCare — Build Phases

Run them in order. At the end of each phase Claude Code stops, the lead reviews, and then the next phase starts.
Each phase has a **prompt to paste into Claude Code** in VS Code.

---

## [x] Phase 0: Foundation (done by the project lead)
- Spec, API contract, CLAUDE.md
- `database/schema.sql`: 8 tables, triggers, views, tested
- `database/seed.sql`: 9 users (3 owners, 2 vets, 2 groomers, 2 walkers), 12 services, 5 pets, 11 appointments, records, reviews
- Express server boots, DB pool, sessions, auth middleware, MySQL error mapping
- Working endpoints: login, logout, me, demo-logins, services, providers of a service
- Page shells for every screen

**You do:** install and run it (see README → Setup) and confirm `http://localhost:3000/api/services` returns 12 services.

---

## [x] Phase 1: Landing page + login/sign up
> Read CLAUDE.md and docs/SPEC.md. Build Phase 1 from docs/PHASES.md: the landing page (public/index.html, js/landing.js) with the header icons for Login/Sign up and System Architecture, the hero, the 12 service cards loaded from GET /api/services (picture, name, caption, price, provider type) and the Demo logins card from GET /api/auth/demo-logins (clicking a row goes to login with it prefilled). Then the login page (login.html, js/login.js) with Login and Sign up tabs and a role selector, and implement POST /api/auth/signup. Download 12 free-to-use photos into public/images/services/ using the filenames in that folder's README, or use the fallback described there. Make it responsive and polished. Stop when done and list what to test.

## [x] Phase 2: Owner: pets + booking
> Build Phase 2: the pets CRUD API (pets.routes.js) and the My Pets tab; GET /api/providers/:id/availability; POST /api/appointments; and the Book Appointment tab on owner.html (pet → service → provider → date → slot). Past dates are blocked (min = today), today's passed hours are disabled, and booked slots show "This slot is not available". Map DB errors with utils/errors.js. Stop when done and give me the test steps from the CLAUDE.md checklist.

## [x] Phase 3: Appointments: list, reschedule, cancel, records, reviews
> Build Phase 3: GET /api/appointments/mine and /:id, PUT reschedule (writes reschedule_history), PUT status, the records API (shared edit rights, rule B11) and the reviews API. On owner.html, build My Appointments with the detail panel (Reschedule + Cancel, Pet remarks/records, Review/rating with stars) and the Pet Records tab.

## [x] Phase 4: Provider dashboards
> Build Phase 4: vet.html, groomer.html and walker.html, all driven by js/provider.js and themed by role. Overview cards, an appointments list showing owner and pet details, Mark completed / Cancel / Reschedule, add/edit records, My Reviews with the average, and My Profile (GET/PUT /api/providers/me/profile). Confirm that a new booking by owner1 appears on vet1's dashboard.

## [x] Phase 5: System Architecture page
> Build Phase 5: architecture.html + js/architecture.js. (1) Database tables read live from GET /api/architecture/schema (INFORMATION_SCHEMA): columns, types, PK/FK/UNIQUE, row counts, and an ER diagram. (2) A workflow diagram of visitor → login → 4 dashboards → booking → provider → review. (3) Users in database: 4 tabs with all details per SPEC R7.3 from GET /api/architecture/users, with the password shown as "•••••• (bcrypt)".

## [x] Phase 6: Polish + test
> Phase 6: run the full CLAUDE.md testing checklist and fix bugs. Add loading and empty states, toasts for success and errors, a logout button on every dashboard, and redirect to /login.html when the session is missing. Check mobile layouts. Update README screenshots and features.
