# PetCare — API Contract

Base URL: `http://localhost:3000/api`. Requests and responses are JSON. Auth uses a session cookie (`express-session`).
Errors always come back as `{ "error": "message" }`.

Legend: **[done]** works now · **[todo]** stub, to build

## Auth: `server/routes/auth.routes.js`

| Method | Path | Body / query | Who | Returns |
|---|---|---|---|---|
| POST | `/auth/login` | `{ username, password, role }` | anyone | `{ user, redirect }` **[done]** |
| POST | `/auth/signup` | `{ full_name, username, email, phone, address, password, role, qualification?, license_no?, experience_years? }` | anyone | `{ user, redirect }` **[done]** |
| POST | `/auth/logout` | none | logged in | `{ ok: true }` **[done]** |
| GET | `/auth/me` | none | logged in | `{ user }` **[done]** |
| GET | `/auth/demo-logins` | none | anyone | list of built-in logins for the landing page **[done]** |

## Services: `services.routes.js`

| GET | `/services` | none | anyone | 12 active services **[done]** |
|---|---|---|---|---|
| GET | `/services/:id/providers` | none | anyone | providers whose role matches the service, plus their rating **[done]** |

## Providers: `providers.routes.js`

| Method | Path | Body / query | Who | Returns |
|---|---|---|---|---|
| GET | `/providers/:id/availability` | `?date=YYYY-MM-DD` | logged in | `[{ time:"09:00", available:true }, { time:"10:00", available:false, reason:"This slot is not available" }, { time:"11:00", available:false, reason:"Time has passed" } …]` **[done]** |
| GET | `/providers/me/profile` | none | provider | profile **[done]** |
| PUT | `/providers/me/profile` | profile fields | provider | updated profile **[done]** |
| GET | `/providers/me/reviews` | none | provider | reviews + average **[done]** |

## Pets: `pets.routes.js`

| GET | `/pets` | none | owner | the owner's pets **[done]** |
|---|---|---|---|---|
| POST | `/pets` | pet fields | owner | created pet **[done]** |
| PUT | `/pets/:id` | pet fields | owner of that pet | updated **[done]** |
| DELETE | `/pets/:id` | none | owner of that pet | `{ ok }` **[done]** |

## Appointments: `appointments.routes.js`

| Method | Path | Body | Who | Returns |
|---|---|---|---|---|
| GET | `/appointments/mine` | `?scope=upcoming\|past\|all` | owner → their bookings, provider → bookings with them | rows from `v_appointment_details` **[done]** |
| GET | `/appointments/:id` | none | the owner or provider on it | details + records + reschedule history + review **[done]** |
| POST | `/appointments` | `{ pet_id, service_id, provider_id, appt_date, start_time, owner_note? }` | owner | created; **409 "This slot is not available"** on a clash **[done]** |
| PUT | `/appointments/:id/reschedule` | `{ appt_date, start_time, reason? }` | owner or provider on it | updated; writes `reschedule_history` **[done]** |
| PUT | `/appointments/:id/status` | `{ status: "Completed" \| "Cancelled" }` | Completed: provider only · Cancelled: either | updated **[done]** |

## Records: `records.routes.js`

| GET | `/records?pet_id=` or `?appointment_id=` | none | pet's owner or a provider who had that pet | list **[done]** |
|---|---|---|---|---|
| POST | `/records` | `{ pet_id, appointment_id?, record_type, title, details }` | owner or provider (B11) | created **[done]** |
| PUT | `/records/:id` | `{ record_type?, title?, details? }` | owner or provider (B11) | updated; sets `last_edited_by` **[done]** |

## Reviews: `reviews.routes.js`

| POST | `/reviews` | `{ appointment_id, rating, comment? }` | owner of a completed appointment | created **[done]** |
|---|---|---|---|---|

## Architecture: `architecture.routes.js` (public, read-only)

| GET | `/architecture/schema` | none | anyone | tables → columns, keys, FKs, row counts from `INFORMATION_SCHEMA` **[done]** |
|---|---|---|---|---|
| GET | `/architecture/users` | none | anyone | `{ owners:[…], vets:[…], groomers:[…], walkers:[…] }`, all details, **no password_hash** **[done]** |

## MySQL error → HTTP mapping (`server/utils/errors.js`) **[done]**

| MySQL | Meaning | HTTP |
|---|---|---|
| 1062 on `uq_provider_slot` | provider is busy | 409 "This slot is not available" |
| 1062 on `uq_pet_slot` | pet already booked then | 409 "Your pet already has an appointment at this time" |
| 1062 on `username` / `email` | duplicate account | 409 "Username already taken" / "Email already registered" |
| 1644 (SIGNAL 45000) | trigger rule broken | 400 with the trigger's message |
| 3819 / 4025 | CHECK failed | 400 "Invalid value" |
