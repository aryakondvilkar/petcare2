# PetCare — Product Specification

The single source of truth for what the app must do. Every requirement below
comes from the project brief. If a feature isn't listed here, ask before building it.

---

## 1. Users and roles

Four login types. Each one lands on its own dashboard after login.

| Role key | Label | Dashboard | Built-in login |
|---|---|---|---|
| `owner` | Pet Owner | `/owner.html` | `owner1` / `owner123` (also owner2, owner3) |
| `vet` | Veterinarian | `/vet.html` | `vet1` / `vet123` (also vet2) |
| `groomer` | Groomer | `/groomer.html` | `groomer1` / `groomer123` (also groomer2) |
| `walker` | Day Walker | `/walker.html` | `walker1` / `walker123` (also walker2) |

- **R1.1** The built-in usernames and passwords must be **shown on the landing page** in a "Demo logins" card, one row per role. Clicking a row should prefill the login form.
- **R1.2** Sign up creates a new account. The user picks a role. Providers also fill in qualification, experience and (for vets) a license number, which go into `provider_profiles`.
- **R1.3** Passwords are stored as bcrypt hashes and never sent to the browser.

## 2. Landing page (`/` → `public/index.html`)

- **R2.1** A header with the logo, a **Login / Sign up** icon button (→ `/login.html`) and a **System Architecture** icon button (→ `/architecture.html`).
- **R2.2** A hero section with a short pitch and a "Book a service" call to action that goes to login.
- **R2.3** A grid of **12 services**, each card showing a **picture**, the **service name** and a **caption**, plus the price and provider type. The data comes from `GET /api/services`, not hardcoded HTML.
  1. Routine Health Checkup (vet)
  2. Vaccination (vet)
  3. Dental Cleaning (vet)
  4. Deworming (vet)
  5. Hair Trimming (groomer)
  6. Nail Trimming (groomer)
  7. Bath & Blow Dry (groomer)
  8. Ear Cleaning (groomer)
  9. Daycare (walker)
  10. Agility Training (walker)
  11. Dog Walking (walker)
  12. Pet Sitting (walker)
- **R2.4** The Demo logins card (R1.1).
- **R2.5** Responsive layout: 4 columns on desktop, 2 on tablet, 1 on phone.

## 3. Login / sign up page (`/login.html`)

- **R3.1** Two tabs, **Login** and **Sign up**.
- **R3.2** Login: username, password and a role selector (4 options). The server checks that the selected role matches the account's role. On success it redirects to that role's dashboard.
- **R3.3** Sign up: full name, username, email, phone, address, password, confirm password and role. Provider fields appear only for provider roles.
- **R3.4** Show inline validation errors and server errors (for example "Username already taken").

## 4. Owner dashboard (`/owner.html`)

Tabs:

- **R4.1 My Pets**: list, add, edit and delete pets.
- **R4.2 Book Appointment**
  - Step 1: pick a pet → a service → a provider (filtered to providers whose role matches the service's `provider_role`) → a date → a time slot.
  - The date picker's `min` is today. **Past dates cannot be chosen.**
  - Slots run hourly, 09:00–17:00 start times. **For today, slots whose time has already passed are disabled.**
  - Slots the provider already has booked with **any** owner show **"This slot is not available"** and can't be picked. The slot list comes from `GET /api/providers/:id/availability?date=YYYY-MM-DD`.
  - An optional note for the provider.
  - The server re-checks everything. If two people race for the same slot, the database's unique index rejects the second booking and the API returns 409 "This slot is not available".
- **R4.3 My Appointments**: upcoming and past lists. Each appointment opens a detail panel with three sections:
  - **Reschedule**: pick a new date/slot using the same past-date and availability rules. Each reschedule is written to `reschedule_history` and sets the status to `Rescheduled`. Only `Booked` or `Rescheduled` appointments can be rescheduled. A **Cancel** button sits here too.
  - **Pet remarks / records**: view, add and edit records for this appointment.
  - **Review / rating**: 1–5 stars plus a comment, only once the appointment is `Completed`, one review per appointment.
- **R4.4 Pet Records**: every record for each pet across all appointments, editable.

## 5. Provider dashboards (`/vet.html`, `/groomer.html`, `/walker.html`)

All three share `public/js/provider.js`. The page title, colours and icon change by role.

- **R5.1** Overview cards: today's appointments, upcoming count, completed count, average rating.
- **R5.2** **Appointments booked by owners show up here automatically.** The provider's list is `GET /api/appointments/mine` filtered by `provider_id`, so a new owner booking appears on the next load or refresh.
- **R5.3** Each appointment shows the owner, their contact details, the pet's details, the service, the date and time, and the owner's note.
- **R5.4** Actions: **Mark completed**, **Cancel**, **Reschedule** (same rules), and **add or edit records** for the pet.
- **R5.5** A **My Reviews** tab lists ratings received, with the average.
- **R5.6** A **My Profile** tab to view and edit qualification, bio and working hours.

## 6. Shared records (`pet_records`)

- **R6.1** Records can be **edited by both** the pet's owner and the provider on that appointment. The server checks this; any other user gets 403.
- **R6.2** Each record shows who created it and who last edited it.

## 7. System Architecture page (`/architecture.html`)

Reached from the landing-page icon. Three sections:

- **R7.1 Database tables**: every table in the `petcare` database with its columns, types, keys, constraints and row count. The data is read live from `INFORMATION_SCHEMA` via `GET /api/architecture/schema`. Include a simple ER/relationship diagram (inline SVG or CSS boxes and lines).
- **R7.2 Workflow**: a diagram of the whole flow:
  `Visitor → Landing → Login/Sign up → (Owner | Vet | Groomer | Walker) dashboard`,
  `Owner → add pet → book (pet, service, provider, date, slot) → availability check → appointment`,
  `Appointment → appears on provider dashboard → reschedule / records / complete → owner reviews`.
- **R7.3 Users in the database**: **all details of all user types**, in four tabs (Owners, Vets, Groomers, Walkers).
  - Owners: id, name, username, email, phone, address, city, joined date, number of pets (with pet names), number of appointments.
  - Providers: the same base fields plus qualification, license number, experience, working hours, average rating, review count, number of appointments.
  - **Never show `password_hash`.** Show the column as "•••••• (bcrypt)" so it's clear the password is stored securely.

## 8. Business rules (enforced in the database AND the API)

| # | Rule | Where it's enforced |
|---|---|---|
| B1 | A booking can't be made for a date or time that has already passed | UI (`min` date, disabled slots) + API + trigger `trg_appt_before_insert` |
| B2 | A reschedule can't move into the past | API + trigger `trg_appt_before_update` |
| B3 | A provider can't be double-booked in a slot → "This slot is not available" | Availability API + unique index `uq_provider_slot` |
| B4 | A pet can't have two appointments in the same slot | unique index `uq_pet_slot` |
| B5 | The provider's role must match the service's `provider_role` | API + trigger |
| B6 | An owner can only book for their own pets | API + trigger |
| B7 | Slots are whole hours, with start times from 09:00 to 17:00 | CHECK `chk_appt_slot` |
| B8 | Only `Completed` appointments can be reviewed, once each, rated 1–5 | trigger + UNIQUE + CHECK |
| B9 | Completed or cancelled appointments can't be rescheduled | API + trigger |
| B10 | Cancelling frees the slot for others | generated column `slot_lock` |
| B11 | Records can be edited only by the pet's owner or that appointment's provider | API |

## 9. Non-functional

- Plain HTML/CSS/JS frontend served by Express, with no build step.
- Indian sample data, prices in ₹, Mumbai addresses.
- Clean, modern, pet-friendly design. Must work on mobile.
- Every API error returns `{ "error": "message" }` with a sensible status code.
