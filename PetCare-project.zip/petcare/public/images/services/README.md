# Service photos

Put one photo per service here (JPG, ~800×600, free-to-use, e.g. Unsplash / Pexels).
The filenames must match `services.image_url` in `database/seed.sql`:

| # | Service | File |
|---|---|---|
| 1 | Routine Health Checkup | health-checkup.jpg |
| 2 | Vaccination | vaccination.jpg |
| 3 | Dental Cleaning | dental-cleaning.jpg |
| 4 | Deworming | deworming.jpg |
| 5 | Hair Trimming | hair-trimming.jpg |
| 6 | Nail Trimming | nail-trimming.jpg |
| 7 | Bath & Blow Dry | bath-blow-dry.jpg |
| 8 | Ear Cleaning | ear-cleaning.jpg |
| 9 | Daycare | daycare.jpg |
| 10 | Agility Training | agility-training.jpg |
| 11 | Dog Walking | dog-walking.jpg |
| 12 | Pet Sitting | pet-sitting.jpg |

Fallback: if a file is missing, the card's `<img onerror>` should swap in a coloured
placeholder with an emoji for the service, so the page never shows a broken image.
