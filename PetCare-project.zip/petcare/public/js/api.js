// Small fetch wrapper used by every page.
//   const services = await api.get('/services');
//   await api.post('/appointments', { ... });
// Throws Error(message) using the server's { error } text.
const api = {
  async request(method, path, body) {
    const res = await fetch('/api' + path, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : {},
      body: body ? JSON.stringify(body) : undefined,
      credentials: 'same-origin'
    });
    let data = null;
    try { data = await res.json(); } catch { /* empty body */ }
    // session expired while on a dashboard -> back to login (auth calls handle 401 themselves)
    if (res.status === 401 && document.body.dataset.dashboard !== undefined && !path.startsWith('/auth/')) {
      location.href = '/login.html';
    }
    if (!res.ok) {
      const err = new Error((data && data.error) || `Request failed (${res.status})`);
      err.status = res.status;
      throw err;
    }
    return data;
  },
  get(path)        { return this.request('GET', path); },
  post(path, body) { return this.request('POST', path, body || {}); },
  put(path, body)  { return this.request('PUT', path, body || {}); },
  del(path)        { return this.request('DELETE', path); }
};

// Dashboards call this first: returns the user or redirects to login.
async function requireUser(expectedRole) {
  try {
    const { user } = await api.get('/auth/me');
    if (expectedRole && ![].concat(expectedRole).includes(user.role)) {
      location.href = '/login.html';
      return null;
    }
    return user;
  } catch {
    location.href = '/login.html';
    return null;
  }
}

// Toast messages: toast('Saved') or toast(err.message, 'error')
function toast(message, type = 'success') {
  let box = document.getElementById('toasts');
  if (!box) {
    box = document.createElement('div');
    box.id = 'toasts';
    box.className = 'toasts';
    box.setAttribute('role', 'status');
    box.setAttribute('aria-live', 'polite');
    document.body.appendChild(box);
  }
  // inside an open modal dialog the toast must live in the dialog to be visible above the backdrop
  const openDialog = document.querySelector('dialog[open]');
  if (openDialog && box.parentElement !== openDialog) openDialog.appendChild(box);
  if (!openDialog && box.parentElement !== document.body) document.body.appendChild(box);

  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.textContent = `${type === 'error' ? '⚠️' : '✅'} ${message}`;
  box.appendChild(el);
  setTimeout(() => { el.classList.add('leaving'); setTimeout(() => el.remove(), 300); }, type === 'error' ? 5000 : 3000);
}

// Shared UI helpers
const ROLE_META = {
  owner:   { label: 'Pet Owner',    icon: '🐶', home: '/owner.html' },
  vet:     { label: 'Veterinarian', icon: '🩺', home: '/vet.html' },
  groomer: { label: 'Groomer',      icon: '✂️', home: '/groomer.html' },
  walker:  { label: 'Day Walker',   icon: '🦮', home: '/walker.html' }
};

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function formatINR(amount) {
  return '₹' + Number(amount).toLocaleString('en-IN', { maximumFractionDigits: 0 });
}

async function logout() {
  await api.post('/auth/logout');
  location.href = '/';
}

// ---------- dates (server sends 'YYYY-MM-DD' and 'HH:MM:SS' strings) ----------
const pad2 = (n) => String(n).padStart(2, '0');

function localToday() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function prettyDate(ymd, opts = { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }) {
  const [y, m, d] = String(ymd).slice(0, 10).split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('en-IN', opts);
}

// 'YYYY-MM-DD HH:MM:SS' -> '12 Oct 2026, 3:05 pm'
function prettyDateTime(ts) {
  const [date, time = '00:00'] = String(ts).split(' ');
  const [y, m, d] = date.split('-').map(Number);
  const [hh, mm] = time.split(':').map(Number);
  return new Date(y, m - 1, d, hh, mm).toLocaleString('en-IN',
    { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' });
}

// '10:00:00' -> '10:00 – 11:00'
function timeRange(start) {
  const h = Number(String(start).slice(0, 2));
  return `${pad2(h)}:00 – ${pad2(h + 1)}:00`;
}

// ---------- pets ----------
const SPECIES_EMOJI = { Dog: '🐕', Cat: '🐈', Rabbit: '🐇', Bird: '🦜', Other: '🐾' };

function petAge(dob) {
  if (!dob) return null;
  const [y, m, d] = dob.split('-').map(Number);
  const now = new Date();
  const months = (now.getFullYear() - y) * 12 + (now.getMonth() - (m - 1)) - (now.getDate() < d ? 1 : 0);
  if (months < 1) return 'under 1 month';
  if (months < 12) return `${months} month${months > 1 ? 's' : ''}`;
  const years = Math.floor(months / 12);
  return `${years} year${years > 1 ? 's' : ''}`;
}

// ---------- small shared widgets (owner.js and provider.js) ----------
function statusBadge(status) {
  return `<span class="status status-${escapeHtml(String(status).toLowerCase())}">${escapeHtml(status)}</span>`;
}

function starsHtml(rating) {
  const n = Math.round(Number(rating) || 0);
  return `<span class="stars" aria-label="${n} out of 5 stars">${'★'.repeat(n)}<span class="off">${'★'.repeat(5 - n)}</span></span>`;
}

// slot buttons from GET /providers/:id/availability
function slotButtonsHtml(slots, selected) {
  return slots.map((s) => {
    const cls = ['slot', s.available ? '' : 'unavailable', s.current ? 'current' : '', s.time === selected ? 'selected' : '']
      .filter(Boolean).join(' ');
    return `
      <button type="button" class="${cls}" data-time="${s.time}"
              ${s.available ? `aria-pressed="${s.time === selected}"` : `disabled title="${escapeHtml(s.reason)}"`}>
        <b>${s.time}</b><small>${s.available ? 'Available' : escapeHtml(s.reason)}</small>
      </button>`;
  }).join('');
}

// Reschedule picker: date (min today) -> slots for the same provider -> optional reason.
// The appointment's own slot is labelled "Current slot". onDone(updatedAppointment) after saving.
function mountReschedule(container, appt, onDone) {
  const today = localToday();
  const startDate = appt.appt_date >= today ? appt.appt_date : today;
  container.innerHTML = `
    <form class="reschedule-form" novalidate>
      <div class="form-grid">
        <div class="field">
          <label>New date</label>
          <input type="date" name="date" min="${today}" value="${startDate}">
        </div>
        <div class="field">
          <label>Reason <span class="hint">(optional)</span></label>
          <input name="reason" maxlength="255" placeholder="e.g. Office meeting clashed">
        </div>
        <div class="field full">
          <span class="field-label">New time</span>
          <div class="slot-grid" data-slots aria-live="polite"></div>
        </div>
      </div>
      <div class="alert alert-error" data-error hidden></div>
      <button type="submit" class="btn" disabled>Reschedule</button>
    </form>`;
  const form = container.querySelector('form');
  const slotsBox = form.querySelector('[data-slots]');
  const errorEl = form.querySelector('[data-error]');
  const submit = form.querySelector('[type=submit]');
  let selected = null;
  let reqNo = 0;

  async function loadSlots() {
    selected = null;
    submit.disabled = true;
    const date = form.elements.date.value;
    if (!date || date < localToday()) {
      slotsBox.innerHTML = '<p class="hint">Past dates cannot be chosen.</p>';
      return;
    }
    const mine = ++reqNo;
    slotsBox.innerHTML = '<p class="hint">Checking availability…</p>';
    try {
      const q = new URLSearchParams({ date, appointment_id: appt.appointment_id });
      const slots = await api.get(`/providers/${appt.provider_id}/availability?${q}`);
      if (mine !== reqNo) return;
      slotsBox.innerHTML = slotButtonsHtml(slots, null) +
        (slots.some((s) => s.available) ? '' : '<p class="hint full-row">No free slots on this day. Try another date.</p>');
    } catch (err) {
      if (mine === reqNo) slotsBox.innerHTML = `<p class="hint">${escapeHtml(err.message)}</p>`;
    }
  }

  form.elements.date.addEventListener('change', loadSlots);
  slotsBox.addEventListener('click', (e) => {
    const btn = e.target.closest('.slot');
    if (!btn || btn.disabled) return;
    selected = btn.dataset.time;
    slotsBox.querySelectorAll('.slot').forEach((s) => {
      s.classList.toggle('selected', s === btn);
      if (!s.disabled) s.setAttribute('aria-pressed', s === btn);
    });
    submit.disabled = false;
  });
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!selected) return;
    errorEl.hidden = true;
    submit.disabled = true;
    try {
      const updated = await api.put(`/appointments/${appt.appointment_id}/reschedule`, {
        appt_date: form.elements.date.value, start_time: selected, reason: form.elements.reason.value.trim()
      });
      toast(`Rescheduled to ${prettyDate(updated.appt_date, { day: 'numeric', month: 'short' })} at ${updated.start_time.slice(0, 5)}`);
      onDone(updated);
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.hidden = false;
      loadSlots();   // the slot may have just been taken
    }
  });
  loadSlots();
}

// Shared pet records list with add + inline edit (rule B11 is enforced by the server).
//   opts: { petId, appointmentId?, load: () => Promise<records>, showAppointment?, emptyText? }
const RECORD_TYPES = ['Remark', 'Medical', 'Vaccination', 'Grooming', 'Behaviour'];

function recordFormHtml(rec = {}) {
  return `
    <form class="record-form" novalidate>
      <div class="form-grid">
        <div class="field">
          <label>Type</label>
          <select name="record_type">${RECORD_TYPES.map((t) =>
            `<option ${t === (rec.record_type || 'Remark') ? 'selected' : ''}>${t}</option>`).join('')}</select>
        </div>
        <div class="field">
          <label>Title</label>
          <input name="title" maxlength="100" value="${escapeHtml(rec.title || '')}" placeholder="e.g. Vaccination given">
        </div>
        <div class="field full">
          <label>Details</label>
          <textarea name="details" rows="3" maxlength="5000">${escapeHtml(rec.details || '')}</textarea>
        </div>
      </div>
      <div class="alert alert-error" data-error hidden></div>
      <div class="form-actions">
        <button type="button" class="btn btn-sm btn-outline" data-cancel>Cancel</button>
        <button type="submit" class="btn btn-sm">${rec.record_id ? 'Save changes' : 'Add record'}</button>
      </div>
    </form>`;
}

function recordItemHtml(r, showAppointment) {
  const who = (name, role) => `${escapeHtml(name)} <span class="role-tag">${escapeHtml(ROLE_META[role]?.label || role)}</span>`;
  const edited = r.last_edited_by && (r.updated_at !== r.created_at || r.last_edited_by !== r.created_by)
    ? `<span>Last edited by ${who(r.last_edited_by_name, r.last_edited_by_role)} · ${prettyDateTime(r.updated_at)}</span>` : '';
  const from = showAppointment
    ? (r.service_name ? `<span class="rec-from">📅 ${escapeHtml(r.service_name)} · ${prettyDate(r.appt_date, { day: 'numeric', month: 'short', year: 'numeric' })}</span>`
                      : '<span class="rec-from">📝 General note</span>')
    : '';
  return `
    <li class="record" data-id="${r.record_id}">
      <div class="record-top">
        <span class="rec-type type-${escapeHtml(r.record_type.toLowerCase())}">${escapeHtml(r.record_type)}</span>
        <h4>${escapeHtml(r.title)}</h4>
        <button type="button" class="btn btn-sm btn-outline" data-edit>Edit</button>
      </div>
      ${from}
      <p class="rec-details">${escapeHtml(r.details)}</p>
      <p class="rec-meta">
        <span>Created by ${who(r.created_by_name, r.created_by_role)} · ${prettyDateTime(r.created_at)}</span>
        ${edited}
      </p>
    </li>`;
}

function mountRecords(container, opts) {
  let records = [];
  container.innerHTML = `
    <div class="records">
      <div class="records-head"><button type="button" class="btn btn-sm" data-add>＋ Add record</button></div>
      <div data-new></div>
      <ul class="record-list" aria-live="polite"><li class="hint">Loading records…</li></ul>
    </div>`;
  const list = container.querySelector('.record-list');
  const newBox = container.querySelector('[data-new]');

  function render() {
    list.innerHTML = records.length
      ? records.map((r) => recordItemHtml(r, opts.showAppointment)).join('')
      : `<li class="state-msg">${escapeHtml(opts.emptyText || 'No records yet.')}</li>`;
  }

  // wire a record form: save(body) -> Promise
  function wireForm(form, save, onCancel) {
    form.querySelector('[data-cancel]').addEventListener('click', onCancel);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const errEl = form.querySelector('[data-error]');
      const body = {
        record_type: form.elements.record_type.value,
        title: form.elements.title.value.trim(),
        details: form.elements.details.value.trim()
      };
      const fail = (msg) => { errEl.textContent = msg; errEl.hidden = false; };
      if (!body.title) return fail('Please add a title');
      if (!body.details) return fail('Please add some details');
      const btn = form.querySelector('[type=submit]');
      btn.disabled = true;
      try {
        await save(body);
        toast(form.closest('.record') ? 'Record updated' : 'Record added');
        await reload(true);
      } catch (err) {
        fail(err.message);
        btn.disabled = false;
      }
    });
  }

  container.querySelector('[data-add]').addEventListener('click', () => {
    newBox.innerHTML = recordFormHtml();
    const form = newBox.querySelector('form');
    wireForm(form,
      (body) => api.post('/records', { ...body, pet_id: opts.petId, appointment_id: opts.appointmentId || null }),
      () => { newBox.innerHTML = ''; });
    form.elements.title.focus();
  });

  list.addEventListener('click', (e) => {
    if (!e.target.closest('[data-edit]')) return;
    const li = e.target.closest('.record');
    const rec = records.find((r) => r.record_id === Number(li.dataset.id));
    li.innerHTML = recordFormHtml(rec);
    const form = li.querySelector('form');
    wireForm(form, (body) => api.put(`/records/${rec.record_id}`, body), render);
    form.elements.title.focus();
  });

  // afterSave: also close the add form (the first load must not wipe a form opened while loading)
  async function reload(afterSave = false) {
    try {
      records = await opts.load();
      if (afterSave) newBox.innerHTML = '';
      render();
    } catch (err) {
      list.innerHTML = `<li class="state-msg">Couldn't load records: ${escapeHtml(err.message)}</li>`;
    }
  }
  reload();
  return { reload };
}
