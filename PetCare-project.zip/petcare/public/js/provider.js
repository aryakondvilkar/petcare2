// Provider dashboard (vet / groomer / walker) — Phase 4 (docs/SPEC.md §5)
// window.PROVIDER_ROLE is set by the page. Shared helpers (dates, slots, records, reschedule) live in api.js.

const $ = (sel) => document.querySelector(sel);
const ROLE = window.PROVIDER_ROLE;

let lists = { upcoming: [], past: [], action: [] };
let scope = 'upcoming';

// ---------- tabs ----------
const TABS = ['appts', 'reviews', 'profile'];

function showTab(name) {
  if (!TABS.includes(name)) name = 'appts';
  document.querySelectorAll('.dash-tab').forEach((t) => t.setAttribute('aria-selected', t.dataset.tab === name));
  TABS.forEach((t) => { document.getElementById(`panel-${t}`).hidden = t !== name; });
  history.replaceState(null, '', '#' + name);
  if (name === 'reviews') loadReviews();
  if (name === 'profile') loadProfile();
}
document.querySelectorAll('.dash-tab').forEach((t) => t.addEventListener('click', () => showTab(t.dataset.tab)));

// =====================================================================
// APPOINTMENTS (owner bookings with this provider — SPEC R5.2/R5.3)
// =====================================================================
function provCard(a) {
  const [, , d] = a.appt_date.split('-');
  const petFacts = [a.breed || a.species, a.pet_gender, petAge(a.pet_dob), a.pet_weight ? `${Number(a.pet_weight)} kg` : null]
    .filter(Boolean).map(escapeHtml).join(' · ');
  const actions = [
    a.can_complete ? `<button type="button" class="btn btn-sm" data-complete="${a.appointment_id}">✓ Mark completed</button>` : '',
    `<button type="button" class="btn btn-sm btn-outline" data-open="${a.appointment_id}">
       ${a.can_reschedule ? 'Reschedule / cancel · Records' : 'Records &amp; details'}</button>`
  ].join('');
  return `
    <article class="prov-card ${a.can_complete ? 'needs-action' : ''}">
      <header class="prov-card-head">
        <span class="date-tile"><b>${Number(d)}</b><small>${escapeHtml(prettyDate(a.appt_date, { month: 'short' }))}</small></span>
        <div class="appt-main">
          <b>${escapeHtml(a.service_name)}</b>
          <small>${prettyDate(a.appt_date, { weekday: 'long' })} · ${timeRange(a.start_time)}</small>
        </div>
        <div class="appt-side">${statusBadge(a.status)}${a.rating !== null ? starsHtml(a.rating) : ''}</div>
      </header>
      <div class="prov-card-body">
        <div class="who-box">
          <h4>Owner</h4>
          <p><b>${escapeHtml(a.owner_name)}</b></p>
          <p>📞 <a href="tel:${escapeHtml(a.owner_phone)}">${escapeHtml(a.owner_phone)}</a></p>
          <p>✉️ <a href="mailto:${escapeHtml(a.owner_email)}">${escapeHtml(a.owner_email)}</a></p>
          ${a.owner_address ? `<p>📍 ${escapeHtml(a.owner_address)}</p>` : ''}
        </div>
        <div class="who-box">
          <h4>Pet</h4>
          <p><b>${SPECIES_EMOJI[a.species] || '🐾'} ${escapeHtml(a.pet_name)}</b></p>
          <p>${petFacts}</p>
          ${a.pet_notes ? `<p class="pet-notes">📝 ${escapeHtml(a.pet_notes)}</p>` : ''}
        </div>
      </div>
      ${a.owner_note ? `<p class="owner-note"><b>Owner's note:</b> ${escapeHtml(a.owner_note)}</p>` : ''}
      <div class="prov-actions">${actions}</div>
    </article>`;
}

function renderList() {
  document.querySelectorAll('#appt-scope .chip').forEach((c) => {
    c.classList.toggle('active', c.dataset.scope === scope);
    c.querySelector('.count').textContent = lists[c.dataset.scope].length;
  });
  const empty = {
    upcoming: 'No upcoming appointments yet. New bookings from owners will show up here.',
    action: 'Nothing to mark completed. 🎉',
    past: 'No past appointments yet.'
  };
  const list = lists[scope];
  $('#appt-list').innerHTML = list.length ? list.map(provCard).join('') : `<div class="state-msg">${empty[scope]}</div>`;
}

function renderStats(reviewData) {
  const all = [...lists.upcoming, ...lists.past];
  const today = localToday();
  const set = (k, v) => { document.querySelector(`[data-stat="${k}"]`).textContent = v; };
  set('today', all.filter((a) => a.appt_date === today && a.status !== 'Cancelled').length);
  set('upcoming', lists.upcoming.length);
  set('completed', all.filter((a) => a.status === 'Completed').length);
  if (reviewData) {
    set('rating', reviewData.average !== null ? `★ ${reviewData.average.toFixed(1)}` : '—');
    set('rating-label', `Average rating · ${reviewData.count} review${reviewData.count === 1 ? '' : 's'}`);
  }
}

async function loadAppointments() {
  if (!lists.upcoming.length && !lists.past.length) $('#appt-list').innerHTML = '<div class="skeleton row"></div>'.repeat(3);
  try {
    const [upcoming, past, reviewData] = await Promise.all([
      api.get('/appointments/mine?scope=upcoming'),
      api.get('/appointments/mine?scope=past'),
      api.get('/providers/me/reviews')
    ]);
    const action = [...past, ...upcoming].filter((a) => a.can_complete)
      .sort((x, y) => (x.appt_date + x.start_time).localeCompare(y.appt_date + y.start_time));
    lists = { upcoming, past, action };
    renderList();
    renderStats(reviewData);
    $('#last-refresh').textContent = `Updated ${new Date().toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' })}`;
  } catch (err) {
    $('#appt-list').innerHTML = `<div class="state-msg">Couldn't load appointments: ${escapeHtml(err.message)}</div>`;
  }
}

$('#appt-scope').addEventListener('click', (e) => {
  const chip = e.target.closest('.chip');
  if (!chip) return;
  scope = chip.dataset.scope;
  renderList();
});
$('#refresh-btn').addEventListener('click', loadAppointments);
// coming back to the tab: pick up bookings made meanwhile
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && !$('#panel-appts').hidden) loadAppointments();
});

async function markCompleted(id) {
  if (!confirm('Mark this appointment as completed? The owner will then be able to review it.')) return false;
  try {
    await api.put(`/appointments/${id}/status`, { status: 'Completed' });
    toast('Marked as completed');
    return true;
  } catch (err) {
    toast(err.message, 'error');
    return false;
  }
}

$('#appt-list').addEventListener('click', async (e) => {
  const done = e.target.closest('[data-complete]');
  if (done) {
    if (await markCompleted(done.dataset.complete)) loadAppointments();
    return;
  }
  const open = e.target.closest('[data-open]');
  if (open) openAppointment(Number(open.dataset.open));
});

// ---------- detail panel: complete, reschedule / cancel, records, review received ----------
const apptDialog = $('#appt-dialog');
$('#appt-close').addEventListener('click', () => apptDialog.close());
apptDialog.addEventListener('close', loadAppointments);

async function openAppointment(id) {
  const box = $('#appt-detail');
  box.innerHTML = '<p class="hint">Loading…</p>';
  if (!apptDialog.open) apptDialog.showModal();
  try {
    renderDetail(await api.get(`/appointments/${id}`));
  } catch (err) {
    box.innerHTML = `<div class="alert alert-error">${escapeHtml(err.message)}</div>`;
  }
}

function renderDetail({ appointment: a, history, review }) {
  const box = $('#appt-detail');
  const statusHint = a.can_complete
    ? '<button type="button" class="btn" id="complete-btn">✓ Mark completed</button>'
    : a.status === 'Completed' || a.status === 'Cancelled'
      ? `<p class="hint">This appointment is ${a.status.toLowerCase()}.</p>`
      : '<p class="hint">You can mark it completed once the appointment time has started.</p>';
  box.innerHTML = `
    <header class="detail-head">
      <div>
        <p class="eyebrow">${SPECIES_EMOJI[a.species] || '🐾'} ${escapeHtml(a.pet_name)} · ${escapeHtml(a.owner_name)}</p>
        <h2 id="appt-dialog-title">${escapeHtml(a.service_name)}</h2>
        <p class="detail-when">${prettyDate(a.appt_date)} · ${timeRange(a.start_time)}</p>
      </div>
      ${statusBadge(a.status)}
    </header>
    <dl class="detail-facts">
      <div><dt>Owner</dt><dd>${escapeHtml(a.owner_name)}<br><small>📞 ${escapeHtml(a.owner_phone)}</small></dd></div>
      <div><dt>Pet</dt><dd>${escapeHtml(a.pet_name)}<br><small>${escapeHtml(a.breed || a.species)}${a.pet_dob ? ' · ' + escapeHtml(petAge(a.pet_dob)) : ''}</small></dd></div>
      <div><dt>Price</dt><dd>${formatINR(a.price)}</dd></div>
      ${a.owner_note ? `<div class="full"><dt>Owner's note</dt><dd>${escapeHtml(a.owner_note)}</dd></div>` : ''}
      ${a.pet_notes ? `<div class="full"><dt>About the pet</dt><dd>${escapeHtml(a.pet_notes)}</dd></div>` : ''}
    </dl>

    <section class="detail-sec">
      <h3>✅ Status</h3>
      ${statusHint}
    </section>

    <section class="detail-sec">
      <h3>📅 Reschedule or cancel</h3>
      ${a.can_reschedule ? `
        <div id="resched-box"></div>
        <div class="cancel-row">
          <span class="hint">Can't do this appointment?</span>
          <button type="button" class="btn btn-sm btn-ghost-danger" id="cancel-appt">Cancel appointment</button>
        </div>`
      : `<p class="hint">A ${escapeHtml(a.status.toLowerCase())} appointment can't be rescheduled or cancelled.</p>`}
      ${history.length ? `
        <div class="history"><h4>Reschedule history</h4><ul>${history.map((h) => `
          <li><span>${prettyDate(h.old_date, { day: 'numeric', month: 'short' })} ${h.old_time.slice(0, 5)}
            → <b>${prettyDate(h.new_date, { day: 'numeric', month: 'short' })} ${h.new_time.slice(0, 5)}</b></span>
            <small>by ${escapeHtml(h.rescheduled_by_name)} (${escapeHtml(ROLE_META[h.rescheduled_by_role].label)})
              · ${prettyDateTime(h.changed_at)}${h.reason ? ` · “${escapeHtml(h.reason)}”` : ''}</small></li>`).join('')}
        </ul></div>` : ''}
    </section>

    <section class="detail-sec">
      <h3>📋 Pet records</h3>
      <p class="hint">Shared with ${escapeHtml(a.owner_name)}. Either of you can add or edit them.</p>
      <div id="detail-records"></div>
    </section>

    <section class="detail-sec">
      <h3>⭐ Owner's review</h3>
      ${review
        ? `<div class="review-done">${starsHtml(review.rating)}${review.comment ? `<p>${escapeHtml(review.comment)}</p>` : ''}
             <small class="hint">${prettyDateTime(review.created_at)}</small></div>`
        : `<p class="hint">${a.status === 'Completed' ? 'The owner hasn\'t reviewed this visit yet.' : 'Owners can review once the appointment is completed.'}</p>`}
    </section>`;

  const completeBtn = $('#complete-btn');
  if (completeBtn) {
    completeBtn.addEventListener('click', async () => {
      if (await markCompleted(a.appointment_id)) openAppointment(a.appointment_id);
    });
  }
  if (a.can_reschedule) {
    mountReschedule($('#resched-box'), a, () => openAppointment(a.appointment_id));
    $('#cancel-appt').addEventListener('click', async () => {
      if (!confirm(`Cancel ${a.service_name} for ${a.pet_name} on ${prettyDate(a.appt_date)}? The owner will see it as cancelled.`)) return;
      try {
        await api.put(`/appointments/${a.appointment_id}/status`, { status: 'Cancelled' });
        toast('Appointment cancelled');
        openAppointment(a.appointment_id);
      } catch (err) {
        toast(err.message, 'error');
      }
    });
  }
  mountRecords($('#detail-records'), {
    petId: a.pet_id,
    appointmentId: a.appointment_id,
    load: () => api.get(`/records?appointment_id=${a.appointment_id}`),
    emptyText: 'No records for this visit yet. Add notes, treatment or advice for the owner.'
  });
}

// =====================================================================
// MY REVIEWS (SPEC R5.5)
// =====================================================================
async function loadReviews() {
  const box = $('#reviews-box');
  box.innerHTML = '<div class="skeleton row"></div>'.repeat(2);
  try {
    const { average, count, reviews } = await api.get('/providers/me/reviews');
    const dist = [5, 4, 3, 2, 1].map((n) => ({ n, c: reviews.filter((r) => r.rating === n).length }));
    box.innerHTML = `
      <div class="reviews-layout">
        <aside class="rating-summary">
          <strong>${average !== null ? average.toFixed(1) : '—'}</strong>
          ${starsHtml(average || 0)}
          <p class="hint">${count} review${count === 1 ? '' : 's'}</p>
          <ul class="rating-bars">${dist.map(({ n, c }) => `
            <li><span>${n}★</span><span class="bar"><span style="width:${count ? (c / count) * 100 : 0}%"></span></span><span>${c}</span></li>`).join('')}
          </ul>
        </aside>
        <div class="review-list">
          ${reviews.length ? reviews.map((r) => `
            <article class="review-card">
              <div class="review-top">${starsHtml(r.rating)}<small class="hint">${prettyDateTime(r.created_at)}</small></div>
              ${r.comment ? `<p>${escapeHtml(r.comment)}</p>` : '<p class="hint">No comment.</p>'}
              <small class="hint">${escapeHtml(r.owner_name)} · ${SPECIES_EMOJI[r.species] || '🐾'} ${escapeHtml(r.pet_name)} · ${escapeHtml(r.service_name)} on ${prettyDate(r.appt_date, { day: 'numeric', month: 'short', year: 'numeric' })}</small>
            </article>`).join('')
          : '<div class="state-msg">No reviews yet. Owners can rate you after a completed appointment.</div>'}
        </div>
      </div>`;
  } catch (err) {
    box.innerHTML = `<div class="state-msg">Couldn't load reviews: ${escapeHtml(err.message)}</div>`;
  }
}

// =====================================================================
// MY PROFILE (SPEC R5.6)
// =====================================================================
const profileForm = $('#profile-form');
const hourOptions = (from, to) => Array.from({ length: to - from + 1 }, (_, i) => {
  const h = `${pad2(from + i)}:00`;
  return `<option value="${h}">${h}</option>`;
}).join('');
$('#pf-start').innerHTML = hourOptions(6, 21);
$('#pf-end').innerHTML = hourOptions(7, 22);
$('#pf-license-field').hidden = ROLE !== 'vet';

function fillProfile(p) {
  $('#profile-name').textContent = p.full_name;
  $('#profile-meta').textContent = `@${p.username} · ${p.email} · ${p.city || 'Mumbai'} · joined ${prettyDate(p.created_at, { month: 'short', year: 'numeric' })}`;
  const f = profileForm.elements;
  f.qualification.value = p.qualification || '';
  f.license_no.value = p.license_no || '';
  f.experience_years.value = p.experience_years;
  f.work_start.value = p.work_start.slice(0, 5);
  f.work_end.value = p.work_end.slice(0, 5);
  f.phone.value = p.phone;
  f.address.value = p.address || '';
  f.bio.value = p.bio || '';
}

async function loadProfile() {
  showMsg('');
  try {
    fillProfile(await api.get('/providers/me/profile'));
  } catch (err) {
    showMsg(err.message, true);
  }
}

function showMsg(msg, isError) {
  $('#profile-error').hidden = !(msg && isError);
  $('#profile-ok').hidden = !(msg && !isError);
  (isError ? $('#profile-error') : $('#profile-ok')).textContent = msg;
}

profileForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = profileForm.elements;
  const body = {
    qualification: f.qualification.value.trim(), license_no: f.license_no.value.trim(),
    experience_years: Number(f.experience_years.value), work_start: f.work_start.value, work_end: f.work_end.value,
    phone: f.phone.value.trim(), address: f.address.value.trim(), bio: f.bio.value.trim()
  };
  if (!body.qualification) return showMsg('Please enter your qualification', true);
  if (ROLE === 'vet' && !body.license_no) return showMsg('Vets must enter a license number', true);
  if (body.work_end <= body.work_start) return showMsg('Work end must be after work start', true);
  const btn = profileForm.querySelector('[type=submit]');
  btn.disabled = true;
  try {
    fillProfile(await api.put('/providers/me/profile', body));
    showMsg('Profile saved.');
    toast('Profile saved');
  } catch (err) {
    showMsg(err.message, true);
  } finally {
    btn.disabled = false;
  }
});

// ---------- start ----------
(async () => {
  const user = await requireUser(ROLE);
  if (!user) return;
  const meta = ROLE_META[ROLE];
  $('#whoami').textContent = `${meta.icon} ${user.full_name}`;
  const parts = user.full_name.split(' ');
  $('#greeting').textContent = `Hi, ${parts[0] === 'Dr.' ? parts.slice(0, 2).join(' ') : parts[0]} 👋`;
  await loadAppointments();
  showTab(location.hash.slice(1));
})();
