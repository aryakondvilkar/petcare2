// Login / Sign up — Phase 1 (docs/SPEC.md §3)
// POST /api/auth/login and POST /api/auth/signup; on success go to data.redirect.

const loginForm = document.getElementById('login-form');
const signupForm = document.getElementById('signup-form');
const PROVIDER_ROLES = ['vet', 'groomer', 'walker'];

// ---------- role pickers ----------
function buildRolePicker(container, name, checked) {
  container.innerHTML = Object.entries(ROLE_META).map(([key, m]) => `
    <label class="role-option role-${key}">
      <input type="radio" name="${name}" value="${key}" ${key === checked ? 'checked' : ''}>
      <span><span class="ico">${m.icon}</span>${escapeHtml(m.label)}</span>
    </label>`).join('');
}
buildRolePicker(document.querySelector('[data-role-picker="login-role"]'), 'role', 'owner');
buildRolePicker(document.querySelector('[data-role-picker="signup-role"]'), 'role', 'owner');

// ---------- tabs ----------
function showTab(which) {
  ['login', 'signup'].forEach((t) => {
    const on = t === which;
    document.getElementById(`tab-${t}`).setAttribute('aria-selected', on);
    document.getElementById(`panel-${t}`).hidden = !on;
  });
  history.replaceState(null, '', which === 'signup' ? '#signup' : location.pathname + location.search);
}
document.getElementById('tab-login').addEventListener('click', () => showTab('login'));
document.getElementById('tab-signup').addEventListener('click', () => showTab('signup'));
document.querySelectorAll('[data-goto]').forEach((b) => b.addEventListener('click', () => showTab(b.dataset.goto)));
if (location.hash === '#signup') showTab('signup');

// ---------- error display ----------
function clearErrors(form) {
  form.querySelectorAll('[data-error-for]').forEach((el) => { el.textContent = ''; });
  form.querySelectorAll('.field.invalid').forEach((el) => el.classList.remove('invalid'));
  const top = form.querySelector('[data-form-error]');
  top.hidden = true;
  top.textContent = '';
}

function showErrors(form, errors) {
  let first = null;
  for (const [field, msg] of Object.entries(errors)) {
    const slot = form.querySelector(`[data-error-for="${field}"]`);
    if (!slot) continue;
    slot.textContent = msg;
    slot.closest('.field')?.classList.add('invalid');
    first = first || form.elements[field];
  }
  if (first && first.focus) first.focus();
}

function showFormError(form, msg) {
  const top = form.querySelector('[data-form-error]');
  top.textContent = msg;
  top.hidden = false;
}

async function submitWith(form, button, work) {
  button.disabled = true;
  const label = button.textContent;
  button.textContent = 'Please wait…';
  try {
    await work();
  } finally {
    button.disabled = false;
    button.textContent = label;
  }
}

// ---------- login ----------
loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  clearErrors(loginForm);
  const data = {
    role: loginForm.elements.role.value,
    username: loginForm.elements.username.value.trim(),
    password: loginForm.elements.password.value
  };
  const errors = {};
  if (!data.role) errors.role = 'Choose your role';
  if (!data.username) errors.username = 'Enter your username';
  if (!data.password) errors.password = 'Enter your password';
  if (Object.keys(errors).length) return showErrors(loginForm, errors);

  submitWith(loginForm, loginForm.querySelector('[type="submit"]'), async () => {
    try {
      const res = await api.post('/auth/login', data);
      location.href = res.redirect;
    } catch (err) {
      showFormError(loginForm, err.message);
    }
  });
});

// ---------- sign up ----------
const providerFields = document.getElementById('provider-fields');
const licenseField = document.getElementById('license-field');

function syncProviderFields() {
  const role = signupForm.elements.role.value;
  providerFields.hidden = !PROVIDER_ROLES.includes(role);
  licenseField.hidden = role !== 'vet';
}
signupForm.addEventListener('change', (e) => { if (e.target.name === 'role') syncProviderFields(); });
syncProviderFields();

// same rules as the server (auth.routes.js) so most mistakes are caught before submitting
function validateSignup(d) {
  const errors = {};
  if (d.full_name.length < 2) errors.full_name = 'Enter your full name';
  if (!/^[A-Za-z0-9_.]{3,50}$/.test(d.username)) errors.username = '3–50 letters, numbers, dots or underscores';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) errors.email = 'Enter a valid email address';
  if (!/^\+?\d{10,14}$/.test(d.phone.replace(/[\s-]/g, ''))) errors.phone = 'Enter a 10–14 digit phone number';
  if (d.password.length < 6) errors.password = 'At least 6 characters';
  if (d.confirm !== d.password) errors.confirm = 'Passwords do not match';
  if (PROVIDER_ROLES.includes(d.role)) {
    if (!d.qualification) errors.qualification = 'Enter your qualification';
    const exp = Number(d.experience_years);
    if (d.experience_years === '' || !Number.isInteger(exp) || exp < 0 || exp > 60) {
      errors.experience_years = 'Whole years, 0 to 60';
    }
    if (d.role === 'vet' && !d.license_no) errors.license_no = 'Vets must enter a license number';
  }
  return errors;
}

// map server messages back onto the field they're about
function fieldForServerError(msg) {
  const m = msg.toLowerCase();
  if (m.includes('username')) return 'username';
  if (m.includes('email')) return 'email';
  if (m.includes('phone')) return 'phone';
  if (m.includes('license')) return 'license_no';
  if (m.includes('qualification')) return 'qualification';
  if (m.includes('experience')) return 'experience_years';
  if (m.includes('password')) return 'password';
  if (m.includes('full name')) return 'full_name';
  return null;
}

signupForm.addEventListener('submit', (e) => {
  e.preventDefault();
  clearErrors(signupForm);
  const f = signupForm.elements;
  const d = {
    role: f.role.value,
    full_name: f.full_name.value.trim(),
    username: f.username.value.trim(),
    email: f.email.value.trim(),
    phone: f.phone.value.trim(),
    address: f.address.value.trim(),
    password: f.password.value,
    confirm: f.confirm.value,
    qualification: f.qualification.value.trim(),
    experience_years: f.experience_years.value.trim(),
    license_no: f.license_no.value.trim()
  };
  const errors = validateSignup(d);
  if (Object.keys(errors).length) return showErrors(signupForm, errors);

  const body = {
    role: d.role, full_name: d.full_name, username: d.username, email: d.email,
    phone: d.phone, address: d.address, password: d.password
  };
  if (PROVIDER_ROLES.includes(d.role)) {
    body.qualification = d.qualification;
    body.experience_years = Number(d.experience_years);
    if (d.role === 'vet') body.license_no = d.license_no;
  }

  submitWith(signupForm, signupForm.querySelector('[type="submit"]'), async () => {
    try {
      const res = await api.post('/auth/signup', body);
      location.href = res.redirect;
    } catch (err) {
      const field = fieldForServerError(err.message);
      if (field) showErrors(signupForm, { [field]: err.message });
      else showFormError(signupForm, err.message);
    }
  });
});

// ---------- prefill from the landing page's demo-logins card (?role=&username=) ----------
async function prefillFromQuery() {
  const q = new URLSearchParams(location.search);
  const role = q.get('role');
  const username = q.get('username');
  if (role && ROLE_META[role]) {
    const radio = loginForm.querySelector(`input[name="role"][value="${role}"]`);
    if (radio) radio.checked = true;
  }
  if (!username) return;
  loginForm.elements.username.value = username;
  showTab('login');
  // demo passwords are public — fill it in too so the demo is one click
  try {
    const demos = await api.get('/auth/demo-logins');
    const match = demos.find((d) => d.username === username && (!role || d.role === role));
    if (match) loginForm.elements.password.value = match.password;
  } catch { /* leave password empty */ }
  loginForm.elements.password.focus();
}

// ---------- already logged in? ----------
async function checkSession() {
  try {
    const { user } = await api.get('/auth/me');
    const note = document.getElementById('session-note');
    const meta = ROLE_META[user.role];
    note.innerHTML = `You're logged in as <b>${escapeHtml(user.username)}</b> (${escapeHtml(meta.label)}).
      <a href="${meta.home}">Go to your dashboard</a> or <button type="button" class="link-btn" id="logout-btn">log out</button>.`;
    note.hidden = false;
    document.getElementById('logout-btn').addEventListener('click', async () => {
      await api.post('/auth/logout');
      note.hidden = true;
    });
  } catch { /* not logged in — normal */ }
}

prefillFromQuery();
checkSession();
