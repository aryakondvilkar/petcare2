// Owner dashboard — Phases 2–3 (docs/SPEC.md §4)
// Phase 2: My Pets (CRUD) and Book Appointment (pet -> service -> provider -> date -> slot).
// Phase 3: My Appointments (detail panel: Reschedule + Cancel, records, review) and Pet Records.
// Shared helpers (dates, slots, records, reschedule) live in api.js.

let pets = [];
let services = [];

// ---------- small helpers ----------
const $ = (sel) => document.querySelector(sel);

function showAlert(el, msg) { el.textContent = msg; el.hidden = !msg; }

// ---------- tabs ----------
const TABS = ['pets', 'book', 'appts', 'records'];

function showTab(name) {
  if (!TABS.includes(name)) name = 'pets';
  document.querySelectorAll('.dash-tab').forEach((t) => t.setAttribute('aria-selected', t.dataset.tab === name));
  TABS.forEach((t) => { document.getElementById(`panel-${t}`).hidden = t !== name; });
  history.replaceState(null, '', '#' + name);
  if (name === 'book') refreshSlots();   // the hour may have moved on since the list was loaded
  if (name === 'appts') loadAppointments();
  if (name === 'records') renderRecordsTab();
}

document.querySelectorAll('.dash-tab').forEach((t) => t.addEventListener('click', () => showTab(t.dataset.tab)));
document.addEventListener('click', (e) => {
  const go = e.target.closest('[data-goto-tab]');
  if (go) showTab(go.dataset.gotoTab);
});

// =====================================================================
// MY PETS
// =====================================================================
function petCard(p) {
  const facts = [p.breed, p.gender, petAge(p.dob), p.weight_kg ? `${Number(p.weight_kg)} kg` : null].filter(Boolean);
  return `
    <article class="pet-card">
      <div class="pet-top">
        <span class="pet-avatar">${SPECIES_EMOJI[p.species] || '🐾'}</span>
        <div>
          <h3>${escapeHtml(p.name)}</h3>
          <p class="pet-species">${escapeHtml(p.species)}</p>
        </div>
      </div>
      <p class="pet-facts">${facts.map(escapeHtml).join(' · ')}</p>
      ${p.notes ? `<p class="pet-notes">📝 ${escapeHtml(p.notes)}</p>` : ''}
      <div class="pet-actions">
        <button class="btn btn-sm" data-book="${p.pet_id}">Book</button>
        <button class="btn btn-sm btn-outline" data-edit="${p.pet_id}">Edit</button>
        <button class="btn btn-sm btn-ghost-danger" data-delete="${p.pet_id}">Delete</button>
      </div>
    </article>`;
}

function renderPets() {
  const list = $('#pet-list');
  list.innerHTML = pets.length
    ? pets.map(petCard).join('')
    : `<div class="state-msg">No pets yet. Add your first pet to start booking. 🐶🐱</div>`;
  renderBookPets();
}

async function loadPets() {
  $('#pet-list').innerHTML = '<div class="skeleton pet"></div>'.repeat(3);
  try {
    pets = await api.get('/pets');
    renderPets();
  } catch (err) {
    $('#pet-list').innerHTML = `<div class="state-msg">Couldn't load your pets: ${escapeHtml(err.message)}</div>`;
  }
}

// add / edit dialog
const dialog = $('#pet-dialog');
const petForm = $('#pet-form');
let editingId = null;

function openPetDialog(pet) {
  editingId = pet ? pet.pet_id : null;
  petForm.reset();
  showAlert($('#pet-form-error'), '');
  $('#pet-dialog-title').textContent = pet ? `Edit ${pet.name}` : 'Add a pet';
  $('#pet-dob').max = localToday();
  if (pet) {
    for (const k of ['name', 'species', 'gender', 'breed', 'dob', 'notes']) petForm.elements[k].value = pet[k] || '';
    petForm.elements.weight_kg.value = pet.weight_kg ? Number(pet.weight_kg) : '';
  }
  dialog.showModal();
  petForm.elements.name.focus();
}

$('#add-pet-btn').addEventListener('click', () => openPetDialog(null));
$('#pet-cancel').addEventListener('click', () => dialog.close());

petForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = petForm.elements;
  const body = {
    name: f.name.value.trim(), species: f.species.value, gender: f.gender.value,
    breed: f.breed.value.trim(), dob: f.dob.value, weight_kg: f.weight_kg.value, notes: f.notes.value.trim()
  };
  const errEl = $('#pet-form-error');
  if (!body.name) { showAlert(errEl, 'Please enter your pet\'s name'); return f.name.focus(); }
  if (body.dob && body.dob > localToday()) { showAlert(errEl, 'Date of birth cannot be in the future'); return f.dob.focus(); }
  if (body.weight_kg !== '' && !(Number(body.weight_kg) > 0)) { showAlert(errEl, 'Weight must be more than 0 kg'); return f.weight_kg.focus(); }

  const save = $('#pet-save');
  save.disabled = true;
  try {
    if (editingId) await api.put(`/pets/${editingId}`, body);
    else await api.post('/pets', body);
    dialog.close();
    toast(editingId ? `${body.name} updated` : `${body.name} added`);
    await loadPets();
  } catch (err) {
    showAlert(errEl, err.message);
  } finally {
    save.disabled = false;
  }
});

$('#pet-list').addEventListener('click', async (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  if (btn.dataset.edit) return openPetDialog(pets.find((p) => p.pet_id == btn.dataset.edit));
  if (btn.dataset.book) {
    selectPet(Number(btn.dataset.book));
    return showTab('book');
  }
  if (btn.dataset.delete) {
    const pet = pets.find((p) => p.pet_id == btn.dataset.delete);
    if (!confirm(`Delete ${pet.name}? Their appointments and records will be deleted too.`)) return;
    try {
      await api.del(`/pets/${pet.pet_id}`);
      toast(`${pet.name} deleted`);
      if (booking.petId === pet.pet_id) booking.petId = null;
      await loadPets();
    } catch (err) {
      toast(err.message, 'error');
    }
  }
});

// =====================================================================
// BOOK APPOINTMENT
// =====================================================================
const booking = { petId: null, serviceId: null, providerId: null, date: '', time: null };
let providers = [];
let slotRequest = 0;   // ignore slot responses that arrive after a newer request

function renderBookPets() {
  $('#book-no-pets').hidden = pets.length > 0;
  $('#book-form').hidden = pets.length === 0;
  if (!pets.some((p) => p.pet_id === booking.petId)) booking.petId = pets.length === 1 ? pets[0].pet_id : null;
  $('#book-pets').innerHTML = pets.map((p) => `
    <label class="choice">
      <input type="radio" name="pet_id" value="${p.pet_id}" ${p.pet_id === booking.petId ? 'checked' : ''}>
      <span><span class="choice-ico">${SPECIES_EMOJI[p.species] || '🐾'}</span>
        <span><b>${escapeHtml(p.name)}</b><small>${escapeHtml(p.breed || p.species)}</small></span></span>
    </label>`).join('');
  updateSummary();
}

function selectPet(id) {
  booking.petId = id;
  const radio = document.querySelector(`#book-pets input[value="${id}"]`);
  if (radio) radio.checked = true;
  updateSummary();
  refreshSlots();
}

$('#book-pets').addEventListener('change', (e) => selectPet(Number(e.target.value)));

async function loadServices() {
  try {
    services = await api.get('/services');
    const groups = { vet: 'Veterinary', groomer: 'Grooming', walker: 'Walking & care' };
    $('#book-service').innerHTML = '<option value="">Choose a service…</option>' +
      Object.entries(groups).map(([role, label]) => `
        <optgroup label="${label}">
          ${services.filter((s) => s.provider_role === role).map((s) =>
            `<option value="${s.service_id}">${escapeHtml(s.name)} · ${formatINR(s.price)}</option>`).join('')}
        </optgroup>`).join('');
  } catch (err) {
    showAlert($('#book-error'), `Couldn't load services: ${err.message}`);
  }
}

$('#book-service').addEventListener('change', async (e) => {
  booking.serviceId = Number(e.target.value) || null;
  booking.providerId = null;
  const svc = services.find((s) => s.service_id === booking.serviceId);
  const info = $('#service-info');
  info.hidden = !svc;
  if (svc) info.textContent = `${svc.caption}. ${svc.duration_min} min with a ${ROLE_META[svc.provider_role].label.toLowerCase()}.`;
  updateSummary();
  await loadProviders();
  refreshSlots();
});

async function loadProviders() {
  const box = $('#book-providers');
  providers = [];
  if (!booking.serviceId) {
    box.innerHTML = '<p class="hint">Choose a service to see who offers it.</p>';
    return;
  }
  box.innerHTML = '<p class="hint">Loading providers…</p>';
  try {
    providers = await api.get(`/services/${booking.serviceId}/providers`);
    if (!providers.length) {
      box.innerHTML = '<p class="hint">No providers offer this service yet.</p>';
      return;
    }
    box.innerHTML = providers.map((p) => {
      const rating = p.avg_rating ? `★ ${Number(p.avg_rating).toFixed(1)} (${p.review_count})` : 'New';
      return `
        <label class="choice">
          <input type="radio" name="provider_id" value="${p.user_id}">
          <span><span class="choice-ico role-${escapeHtml(p.role)}">${ROLE_META[p.role].icon}</span>
            <span><b>${escapeHtml(p.full_name)}</b>
              <small>${escapeHtml(p.qualification || ROLE_META[p.role].label)}</small>
              <small class="meta">${rating} · ${Number(p.experience_years)} yrs exp</small></span></span>
        </label>`;
    }).join('');
  } catch (err) {
    box.innerHTML = `<p class="hint">Couldn't load providers: ${escapeHtml(err.message)}</p>`;
  }
}

$('#book-providers').addEventListener('change', (e) => {
  booking.providerId = Number(e.target.value);
  updateSummary();
  refreshSlots();
});

const dateInput = $('#book-date');
dateInput.min = localToday();
dateInput.addEventListener('change', () => {
  booking.date = dateInput.value;
  const err = $('#date-error');
  err.textContent = '';
  if (booking.date && booking.date < localToday()) {
    err.textContent = 'Past dates cannot be chosen';
    booking.date = '';
  }
  updateSummary();
  refreshSlots();
});

// Re-fetch the slot list whenever the pet, provider or date changes
async function refreshSlots() {
  const box = $('#book-slots');
  dateInput.min = localToday();
  if (!booking.providerId || !booking.date) {
    booking.time = null;
    box.innerHTML = '<p class="hint">Choose a provider and a date to see free slots.</p>';
    updateSummary();
    return;
  }
  const req = ++slotRequest;
  box.innerHTML = '<p class="hint">Checking availability…</p>';
  try {
    const q = new URLSearchParams({ date: booking.date });
    if (booking.petId) q.set('pet_id', booking.petId);
    const slots = await api.get(`/providers/${booking.providerId}/availability?${q}`);
    if (req !== slotRequest) return;   // a newer request has started
    if (!slots.some((s) => s.available && s.time === booking.time)) booking.time = null;
    box.innerHTML = slotButtonsHtml(slots, booking.time);
    if (!slots.some((s) => s.available)) {
      box.insertAdjacentHTML('beforeend', '<p class="hint full-row">No free slots on this day. Try another date.</p>');
    }
  } catch (err) {
    if (req !== slotRequest) return;
    booking.time = null;
    box.innerHTML = `<p class="hint">${escapeHtml(err.message)}</p>`;
  }
  updateSummary();
}

$('#book-slots').addEventListener('click', (e) => {
  const btn = e.target.closest('.slot');
  if (!btn || btn.disabled) return;
  booking.time = btn.dataset.time;
  document.querySelectorAll('#book-slots .slot').forEach((s) => {
    const on = s === btn;
    s.classList.toggle('selected', on);
    if (!s.disabled) s.setAttribute('aria-pressed', on);
  });
  updateSummary();
});

function updateSummary() {
  const pet = pets.find((p) => p.pet_id === booking.petId);
  const svc = services.find((s) => s.service_id === booking.serviceId);
  const prov = providers.find((p) => p.user_id === booking.providerId);
  const set = (k, v) => { document.querySelector(`[data-sum="${k}"]`).textContent = v || '—'; };
  set('pet', pet && pet.name);
  set('service', svc && svc.name);
  set('provider', prov && prov.full_name);
  set('date', booking.date && prettyDate(booking.date));
  set('time', booking.time && timeRange(booking.time));
  set('price', svc && formatINR(svc.price));
  $('#book-submit').disabled = !(pet && svc && prov && booking.date && booking.time);
}

$('#book-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = $('#book-error');
  const okEl = $('#book-success');
  showAlert(errEl, '');
  showAlert(okEl, '');
  const submit = $('#book-submit');
  submit.disabled = true;
  submit.textContent = 'Booking…';
  try {
    const appt = await api.post('/appointments', {
      pet_id: booking.petId, service_id: booking.serviceId, provider_id: booking.providerId,
      appt_date: booking.date, start_time: booking.time, owner_note: $('#book-note').value.trim()
    });
    showAlert(okEl, `Booked! ${appt.pet_name} · ${appt.service_name} with ${appt.provider_name} on ` +
      `${prettyDate(appt.appt_date)} at ${appt.start_time.slice(0, 5)}.`);
    $('#book-note').value = '';
    booking.time = null;
  } catch (err) {
    showAlert(errEl, err.message);   // e.g. 409 "This slot is not available" if someone else got there first
  } finally {
    submit.textContent = 'Confirm booking';
    await refreshSlots();
  }
});

// =====================================================================
// MY APPOINTMENTS
// =====================================================================
let apptScope = 'upcoming';
let apptLists = { upcoming: [], past: [] };

function apptCard(a) {
  const [, m, d] = a.appt_date.split('-');
  const month = prettyDate(a.appt_date, { month: 'short' });
  const extra = a.rating !== null ? starsHtml(a.rating)
    : a.can_review ? '<span class="tag tag-accent">Rate this visit</span>' : '';
  return `
    <button type="button" class="appt-card" data-id="${a.appointment_id}">
      <span class="date-tile"><b>${Number(d)}</b><small>${escapeHtml(month)}</small></span>
      <span class="appt-main">
        <b>${escapeHtml(a.service_name)}</b>
        <span>${SPECIES_EMOJI[a.species] || '🐾'} ${escapeHtml(a.pet_name)} · ${ROLE_META[a.provider_role].icon} ${escapeHtml(a.provider_name)}</span>
        <small>${prettyDate(a.appt_date, { weekday: 'short' })} · ${timeRange(a.start_time)}</small>
      </span>
      <span class="appt-side">${statusBadge(a.status)}${extra}</span>
    </button>`;
}

function renderAppointments() {
  document.querySelectorAll('#appt-scope .chip').forEach((c) => {
    c.classList.toggle('active', c.dataset.scope === apptScope);
    c.querySelector('.count').textContent = apptLists[c.dataset.scope].length;
  });
  const list = apptLists[apptScope];
  $('#appt-list').innerHTML = list.length
    ? list.map(apptCard).join('')
    : `<div class="state-msg">${apptScope === 'upcoming'
        ? 'No upcoming appointments. <button type="button" class="link-btn" data-goto-tab="book">Book one now</button>.'
        : 'No past appointments yet.'}</div>`;
}

async function loadAppointments() {
  $('#appt-list').innerHTML = '<div class="skeleton row"></div>'.repeat(3);
  try {
    const [upcoming, past] = await Promise.all([
      api.get('/appointments/mine?scope=upcoming'), api.get('/appointments/mine?scope=past')]);
    apptLists = { upcoming, past };
    renderAppointments();
  } catch (err) {
    $('#appt-list').innerHTML = `<div class="state-msg">Couldn't load appointments: ${escapeHtml(err.message)}</div>`;
  }
}

$('#appt-scope').addEventListener('click', (e) => {
  const chip = e.target.closest('.chip');
  if (!chip) return;
  apptScope = chip.dataset.scope;
  renderAppointments();
});
$('#appt-list').addEventListener('click', (e) => {
  const card = e.target.closest('.appt-card');
  if (card) openAppointment(Number(card.dataset.id));
});

// ---------- detail panel ----------
const apptDialog = $('#appt-dialog');
$('#appt-close').addEventListener('click', () => apptDialog.close());
apptDialog.addEventListener('close', () => { if (!$('#panel-appts').hidden) loadAppointments(); });

async function openAppointment(id) {
  const box = $('#appt-detail');
  box.innerHTML = '<p class="hint">Loading…</p>';
  if (!apptDialog.open) apptDialog.showModal();
  try {
    renderDetail(await api.get(`/appointments/${id}`));
  } catch (err) {
    box.innerHTML = `<div class="alert alert-error">${escapeHtml(err.message)}</div>`;
  }
}

function historyHtml(history) {
  if (!history.length) return '';
  return `
    <div class="history">
      <h4>Reschedule history</h4>
      <ul>${history.map((h) => `
        <li>
          <span>${prettyDate(h.old_date, { day: 'numeric', month: 'short' })} ${h.old_time.slice(0, 5)}
            → <b>${prettyDate(h.new_date, { day: 'numeric', month: 'short' })} ${h.new_time.slice(0, 5)}</b></span>
          <small>by ${escapeHtml(h.rescheduled_by_name)} (${escapeHtml(ROLE_META[h.rescheduled_by_role].label)})
            · ${prettyDateTime(h.changed_at)}${h.reason ? ` · “${escapeHtml(h.reason)}”` : ''}</small>
        </li>`).join('')}
      </ul>
    </div>`;
}

function renderDetail({ appointment: a, history, review }) {
  const box = $('#appt-detail');
  box.innerHTML = `
    <header class="detail-head">
      <div>
        <p class="eyebrow">${ROLE_META[a.provider_role].icon} ${escapeHtml(ROLE_META[a.provider_role].label)}</p>
        <h2 id="appt-dialog-title">${escapeHtml(a.service_name)}</h2>
        <p class="detail-when">${prettyDate(a.appt_date)} · ${timeRange(a.start_time)}</p>
      </div>
      ${statusBadge(a.status)}
    </header>
    <dl class="detail-facts">
      <div><dt>Pet</dt><dd>${SPECIES_EMOJI[a.species] || '🐾'} ${escapeHtml(a.pet_name)}</dd></div>
      <div><dt>Provider</dt><dd>${escapeHtml(a.provider_name)}<br><small>📞 ${escapeHtml(a.provider_phone)}</small></dd></div>
      <div><dt>Price</dt><dd>${formatINR(a.price)}</dd></div>
      ${a.owner_note ? `<div class="full"><dt>Your note</dt><dd>${escapeHtml(a.owner_note)}</dd></div>` : ''}
    </dl>

    <section class="detail-sec">
      <h3>📅 Reschedule or cancel</h3>
      ${a.can_reschedule ? `
        <div id="resched-box"></div>
        <div class="cancel-row">
          <span class="hint">Can't make it at all?</span>
          <button type="button" class="btn btn-sm btn-ghost-danger" id="cancel-appt">Cancel appointment</button>
        </div>`
      : `<p class="hint">This appointment is ${escapeHtml(a.status.toLowerCase())}, so it can no longer be rescheduled or cancelled.</p>`}
      ${historyHtml(history)}
    </section>

    <section class="detail-sec">
      <h3>📋 Pet remarks &amp; records</h3>
      <p class="hint">Shared with ${escapeHtml(a.provider_name)}. Either of you can add or edit them.</p>
      <div id="detail-records"></div>
    </section>

    <section class="detail-sec">
      <h3>⭐ Review</h3>
      <div id="review-box"></div>
    </section>`;

  if (a.can_reschedule) {
    mountReschedule($('#resched-box'), a, () => openAppointment(a.appointment_id));
    $('#cancel-appt').addEventListener('click', async () => {
      if (!confirm(`Cancel ${a.service_name} for ${a.pet_name} on ${prettyDate(a.appt_date)}? The slot will be freed for others.`)) return;
      try {
        await api.put(`/appointments/${a.appointment_id}/status`, { status: 'Cancelled' });
        toast('Appointment cancelled');
        openAppointment(a.appointment_id);
      } catch (err) {
        toast(err.message, 'error');
      }
    });
  }

  mountRecords($('#detail-records'), {
    petId: a.pet_id,
    appointmentId: a.appointment_id,
    load: () => api.get(`/records?appointment_id=${a.appointment_id}`),
    emptyText: 'No records for this visit yet.'
  });

  renderReview(a, review);
}

function renderReview(a, review) {
  const box = $('#review-box');
  if (review) {
    box.innerHTML = `
      <div class="review-done">
        ${starsHtml(review.rating)}
        ${review.comment ? `<p>${escapeHtml(review.comment)}</p>` : ''}
        <small class="hint">Reviewed on ${prettyDateTime(review.created_at)}</small>
      </div>`;
    return;
  }
  if (!a.can_review) {
    box.innerHTML = `<p class="hint">${a.status === 'Cancelled'
      ? 'Cancelled appointments can\'t be reviewed.'
      : 'You can rate this visit once the provider marks it completed.'}</p>`;
    return;
  }
  box.innerHTML = `
    <form id="review-form" novalidate>
      <fieldset class="star-input">
        <legend class="field-label">How was ${escapeHtml(a.provider_name)}?</legend>
        ${[5, 4, 3, 2, 1].map((n) => `
          <input type="radio" id="star-${n}" name="rating" value="${n}">
          <label for="star-${n}" title="${n} star${n > 1 ? 's' : ''}">★<span class="sr-only">${n} star${n > 1 ? 's' : ''}</span></label>`).join('')}
      </fieldset>
      <div class="field">
        <label for="review-comment">Comment <span class="hint">(optional)</span></label>
        <textarea id="review-comment" name="comment" rows="3" maxlength="500" placeholder="What went well?"></textarea>
      </div>
      <div class="alert alert-error" data-error hidden></div>
      <button type="submit" class="btn btn-sm">Submit review</button>
    </form>`;
  const form = $('#review-form');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const errEl = form.querySelector('[data-error]');
    const rating = Number(form.elements.rating.value);
    if (!rating) { errEl.textContent = 'Please pick 1 to 5 stars'; errEl.hidden = false; return; }
    form.querySelector('[type=submit]').disabled = true;
    try {
      await api.post('/reviews', { appointment_id: a.appointment_id, rating, comment: form.elements.comment.value.trim() });
      toast('Thanks for your review!');
      openAppointment(a.appointment_id);
    } catch (err) {
      errEl.textContent = err.message;
      errEl.hidden = false;
      form.querySelector('[type=submit]').disabled = false;
    }
  });
}

// =====================================================================
// PET RECORDS (every record for each pet, across all appointments)
// =====================================================================
let recordsPetId = null;

function renderRecordsTab() {
  const chips = $('#records-pets');
  const box = $('#records-box');
  if (!pets.length) {
    chips.innerHTML = '';
    box.innerHTML = '<div class="state-msg">Add a pet first to keep records. <button type="button" class="link-btn" data-goto-tab="pets">Go to My Pets</button>.</div>';
    return;
  }
  if (!pets.some((p) => p.pet_id === recordsPetId)) recordsPetId = pets[0].pet_id;
  chips.innerHTML = pets.map((p) => `
    <button type="button" class="chip ${p.pet_id === recordsPetId ? 'active' : ''}" data-pet="${p.pet_id}">
      ${SPECIES_EMOJI[p.species] || '🐾'} ${escapeHtml(p.name)}
    </button>`).join('');
  const pet = pets.find((p) => p.pet_id === recordsPetId);
  mountRecords(box, {
    petId: pet.pet_id,
    load: () => api.get(`/records?pet_id=${pet.pet_id}`),
    showAppointment: true,
    emptyText: `No records for ${pet.name} yet. Add allergies, diet or anything a provider should know.`
  });
}

$('#records-pets').addEventListener('click', (e) => {
  const chip = e.target.closest('.chip');
  if (!chip) return;
  recordsPetId = Number(chip.dataset.pet);
  renderRecordsTab();
});

// ---------- start ----------
(async () => {
  const user = await requireUser('owner');
  if (!user) return;
  document.getElementById('whoami').textContent = '🐶 ' + user.full_name;
  $('#greeting').textContent = `Hi, ${user.full_name.split(' ')[0]} 👋`;
  await Promise.all([loadPets(), loadServices()]);
  showTab(location.hash.slice(1));
})();
