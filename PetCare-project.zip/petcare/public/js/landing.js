// Landing page — Phase 1 (docs/SPEC.md §2)
// Service cards from GET /api/services, demo logins from GET /api/auth/demo-logins.

// Emoji shown on a coloured placeholder when a service photo is missing
const SERVICE_EMOJI = {
  'Routine Health Checkup': '🩺', 'Vaccination': '💉', 'Dental Cleaning': '🦷', 'Deworming': '💊',
  'Hair Trimming': '✂️', 'Nail Trimming': '💅', 'Bath & Blow Dry': '🛁', 'Ear Cleaning': '👂',
  'Daycare': '🏡', 'Agility Training': '🏃', 'Dog Walking': '🦮', 'Pet Sitting': '🛋️'
};

const grid = document.getElementById('services-grid');
let services = [];

function serviceCard(s) {
  const role = ROLE_META[s.provider_role];
  const emoji = SERVICE_EMOJI[s.name] || '🐾';
  return `
    <article class="service-card role-${escapeHtml(s.provider_role)}">
      <div class="service-media">
        <img src="${escapeHtml(s.image_url)}" alt="${escapeHtml(s.name)}" loading="lazy" width="800" height="600"
             data-emoji="${emoji}" onerror="showPlaceholder(this)">
        <span class="role-badge">${role.icon} ${escapeHtml(role.label)}</span>
      </div>
      <div class="service-body">
        <h3>${escapeHtml(s.name)}</h3>
        <p>${escapeHtml(s.caption)}</p>
        <div class="service-foot">
          <span class="price">${formatINR(s.price)}</span>
          <span class="duration">⏱ ${Number(s.duration_min)} min</span>
        </div>
      </div>
    </article>`;
}

// <img onerror> fallback: swap the broken image for an emoji tile
function showPlaceholder(img) {
  const div = document.createElement('div');
  div.className = 'placeholder';
  div.setAttribute('role', 'img');
  div.setAttribute('aria-label', img.alt);
  div.textContent = img.dataset.emoji;
  img.replaceWith(div);
}

function renderServices(role) {
  const list = role === 'all' ? services : services.filter((s) => s.provider_role === role);
  grid.innerHTML = list.length
    ? list.map(serviceCard).join('')
    : '<p class="state-msg">No services in this category yet.</p>';
}

async function loadServices() {
  grid.innerHTML = '<div class="skeleton card"></div>'.repeat(8);
  try {
    services = await api.get('/services');
    renderServices('all');
  } catch (err) {
    grid.innerHTML = `<p class="state-msg">Couldn't load services: ${escapeHtml(err.message)}</p>`;
  }
}

document.getElementById('service-filters').addEventListener('click', (e) => {
  const chip = e.target.closest('.chip');
  if (!chip) return;
  document.querySelectorAll('#service-filters .chip').forEach((c) => c.classList.toggle('active', c === chip));
  renderServices(chip.dataset.role);
});

async function loadDemoLogins() {
  const box = document.getElementById('demo-list');
  try {
    const logins = await api.get('/auth/demo-logins');
    box.innerHTML = logins.map((d) => {
      const meta = ROLE_META[d.role] || {};
      return `
        <button type="button" class="demo-row role-${escapeHtml(d.role)}"
                data-role="${escapeHtml(d.role)}" data-username="${escapeHtml(d.username)}">
          <span class="who"><span class="ico">${meta.icon || '👤'}</span>${escapeHtml(d.label)}</span>
          <span class="creds">
            <span>Username <code>${escapeHtml(d.username)}</code></span>
            <span>Password <code>${escapeHtml(d.password)}</code></span>
          </span>
          <span class="go">Log in as ${escapeHtml(d.username)} →</span>
        </button>`;
    }).join('');
  } catch (err) {
    box.innerHTML = `<p class="state-msg">Couldn't load demo logins: ${escapeHtml(err.message)}</p>`;
  }
}

document.getElementById('demo-list').addEventListener('click', (e) => {
  const row = e.target.closest('.demo-row');
  if (!row) return;
  const q = new URLSearchParams({ role: row.dataset.role, username: row.dataset.username });
  location.href = `/login.html?${q}`;
});

loadServices();
loadDemoLogins();
