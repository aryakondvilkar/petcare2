// System Architecture page — Phase 5 (docs/SPEC.md §7)
// (1) tables + ER diagram from GET /api/architecture/schema, (2) static workflow in the HTML,
// (3) users from GET /api/architecture/users (password shown as '•••••• (bcrypt)').

const $ = (sel) => document.querySelector(sel);

// display order for the 8 tables (unknown tables go last)
const TABLE_ORDER = ['users', 'provider_profiles', 'pets', 'services', 'appointments',
  'reschedule_history', 'pet_records', 'reviews'];
const TABLE_ICON = {
  users: '👤', provider_profiles: '🎓', pets: '🐾', services: '🧴', appointments: '📅',
  reschedule_history: '🔁', pet_records: '📋', reviews: '⭐'
};

// =====================================================================
// 1. DATABASE
// =====================================================================
function sortTables(tables) {
  const rank = (t) => (t.type === 'VIEW' ? 100 : 0) + (TABLE_ORDER.includes(t.name) ? TABLE_ORDER.indexOf(t.name) : 50);
  return [...tables].sort((a, b) => rank(a) - rank(b) || a.name.localeCompare(b.name));
}

function renderStats(schema) {
  const base = schema.tables.filter((t) => t.type === 'TABLE');
  const views = schema.tables.filter((t) => t.type === 'VIEW');
  const rows = base.reduce((n, t) => n + Number(t.rows), 0);
  const fks = base.reduce((n, t) => n + t.foreignKeys.length, 0);
  const stat = (ico, n, label) => `<div class="stat"><span class="stat-ico">${ico}</span><div><strong>${n}</strong><span>${label}</span></div></div>`;
  $('#db-stats').innerHTML = stat('🗃️', base.length, 'tables') + stat('👁️', views.length, 'views')
    + stat('🔗', fks, 'foreign keys') + stat('🧮', rows, `rows · ${schema.triggers.length} triggers`);
}

// ---------- ER diagram (inline SVG) ----------
// users is a wide bar across the top (6 tables reference it); its edges run up the gutters
// between columns so they never cross a table. Other edges are short straight lines.
const COL_X = [16, 262, 508, 754];
const ROW_Y = [130, 330, 560];
const BOX_W = 232;
const ER_POS = {
  provider_profiles: [COL_X[0], ROW_Y[0]], pets: [COL_X[1], ROW_Y[0]], services: [COL_X[3], ROW_Y[0]],
  appointments: [COL_X[2], ROW_Y[1]], reviews: [COL_X[3], ROW_Y[1]],
  pet_records: [COL_X[1], ROW_Y[2]], reschedule_history: [COL_X[2], ROW_Y[2]]
};
const HUB = 'users';
const ROW_H = 19;

function boxHeight(t) {
  const keyCols = t.columns.filter((c) => c.col_key === 'PRI' || t.foreignKeys.some((f) => f.col === c.name));
  return 46 + keyCols.length * ROW_H + 8;
}

// point where the line from (cx,cy) toward the box centre enters the box
function edgePoint(box, fromX, fromY) {
  const cx = box.x + box.w / 2, cy = box.y + box.h / 2;
  const dx = fromX - cx, dy = fromY - cy;
  const sx = dx === 0 ? Infinity : (box.w / 2) / Math.abs(dx);
  const sy = dy === 0 ? Infinity : (box.h / 2) / Math.abs(dy);
  const s = Math.min(sx, sy);
  return [cx + dx * s, cy + dy * s];
}

function renderER(schema) {
  const tables = schema.tables.filter((t) => t.type === 'TABLE');
  const boxes = {};
  let extra = 0;
  for (const t of tables) {
    if (t.name === HUB) {
      boxes[t.name] = { x: 20, y: 20, w: 960, h: boxHeight(t), t };
      continue;
    }
    let pos = ER_POS[t.name];
    if (!pos) { pos = [COL_X[extra % 4], 790 + Math.floor(extra / 4) * 200]; extra++; }
    boxes[t.name] = { x: pos[0], y: pos[1], w: BOX_W, h: boxHeight(t), t };
  }
  const height = Math.max(...Object.values(boxes).map((b) => b.y + b.h)) + 20;
  const hub = boxes[HUB];

  // one edge per (table -> referenced table) pair, labelled with the FK columns
  const edges = new Map();
  for (const t of tables) {
    for (const f of t.foreignKeys) {
      if (!boxes[f.ref_table] || f.ref_table === t.name) continue;
      const key = `${t.name}>${f.ref_table}`;
      if (!edges.has(key)) edges.set(key, { from: t.name, to: f.ref_table, cols: [] });
      edges.get(key).cols.push(f.col);
    }
  }

  const lines = [...edges.values()].map((e) => {
    const a = boxes[e.from], b = boxes[e.to];
    if (hub && e.to === HUB) {
      // left side of the table -> gutter just left of it -> up to the users bar
      const gx = a.x - 7, sy = a.y + 17;
      return `
        <g class="er-edge er-hub-edge">
          <title>${escapeHtml(e.from)}.${escapeHtml(e.cols.join(', '))} → ${HUB}</title>
          <path d="M${a.x} ${sy} H${gx} V${hub.y + hub.h}" marker-end="url(#er-arrow)"/>
        </g>`;
    }
    const [x1, y1] = edgePoint(a, b.x + b.w / 2, b.y + b.h / 2);
    const [x2, y2] = edgePoint(b, a.x + a.w / 2, a.y + a.h / 2);
    const mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
    const label = e.cols.join(', ');
    // skip the label when the gap is too short for it (the FK is listed in the box anyway)
    const showLabel = Math.hypot(x2 - x1, y2 - y1) > label.length * 6.2 + 40;
    return `
      <g class="er-edge">
        <line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" marker-end="url(#er-arrow)"/>
        ${showLabel ? `<rect x="${mx - label.length * 3.1 - 6}" y="${my - 9}" width="${label.length * 6.2 + 12}" height="18" rx="9"/>
        <text x="${mx}" y="${my + 4}" text-anchor="middle">${escapeHtml(label)}</text>` : `<title>${escapeHtml(label)}</title>`}
      </g>`;
  }).join('');

  const nodes = Object.values(boxes).map(({ x, y, w, h, t }) => {
    const keyCols = t.columns.filter((c) => c.col_key === 'PRI' || t.foreignKeys.some((f) => f.col === c.name));
    const rows = keyCols.map((c, i) => {
      const pk = c.col_key === 'PRI';
      const fk = t.foreignKeys.find((f) => f.col === c.name);
      return `<text x="${x + 12}" y="${y + 60 + i * ROW_H}" class="er-col">
        <tspan class="${pk ? 'er-pk' : 'er-fk'}">${pk ? 'PK' : 'FK'}</tspan> ${escapeHtml(c.name)}${fk ? ` → ${escapeHtml(fk.ref_table)}` : ''}</text>`;
    }).join('');
    return `
      <g class="er-node">
        <rect x="${x}" y="${y}" width="${w}" height="${h}" rx="10" class="er-box"/>
        <path d="M${x} ${y + 10} a10 10 0 0 1 10 -10 h${w - 20} a10 10 0 0 1 10 10 v24 h-${w} z" class="er-head"/>
        <text x="${x + 12}" y="${y + 22}" class="er-title">${TABLE_ICON[t.name] || '🗃️'} ${escapeHtml(t.name)}</text>
        <text x="${x + w - 12}" y="${y + 22}" text-anchor="end" class="er-count">${t.rows} row${Number(t.rows) === 1 ? '' : 's'}</text>
        ${rows}
      </g>`;
  }).join('');

  $('#er-diagram').innerHTML = `
    <svg viewBox="0 0 1000 ${height}" role="img" aria-labelledby="er-title er-desc">
      <title id="er-title">PetCare entity–relationship diagram</title>
      <desc id="er-desc">${tables.length} tables. ${[...edges.values()].map((e) => `${e.from} references ${e.to}`).join('. ')}.</desc>
      <defs>
        <marker id="er-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
          <path d="M0 0 L10 5 L0 10 z"/>
        </marker>
      </defs>
      ${lines}
      ${nodes}
      ${hub ? `<text x="${hub.x + hub.w - 12}" y="${hub.y + 60}" text-anchor="end" class="er-note">↑ referenced by ${[...edges.values()].filter((e) => e.to === HUB).length} tables (owner_id, provider_id, created_by …)</text>` : ''}
    </svg>`;
}

function renderTriggers(triggers) {
  $('#trigger-list').innerHTML = triggers.length ? `
    <ul class="trigger-list">${triggers.map((t) => `
      <li>
        <code>${escapeHtml(t.name)}</code>
        <span class="tag">${escapeHtml(t.timing)} ${escapeHtml(t.event)} ON ${escapeHtml(t.tbl)}</span>
        <p>${escapeHtml(t.enforces)}</p>
      </li>`).join('')}
    </ul>` : '<p class="state-msg">No triggers found. Re-import database/schema.sql with the mysql client.</p>';
}

function keyBadges(t, c) {
  const badges = [];
  if (c.col_key === 'PRI') badges.push('<span class="key key-pk" title="Primary key">PK</span>');
  if (t.foreignKeys.some((f) => f.col === c.name)) badges.push('<span class="key key-fk" title="Foreign key">FK</span>');
  if (c.col_key === 'UNI' || t.uniques.some((u) => u.cols.split(', ').includes(c.name) && u.cols.includes(','))) {
    badges.push('<span class="key key-uq" title="Unique (alone or in a composite unique key)">UQ</span>');
  }
  if (c.extra.includes('GENERATED')) badges.push('<span class="key key-gen" title="Generated column">GEN</span>');
  return badges.join('');
}

function tableCard(t) {
  const extra = (c) => {
    const parts = [];
    if (c.col_default !== null) parts.push(`default ${escapeHtml(c.col_default)}`);
    if (c.extra) parts.push(escapeHtml(c.extra.toLowerCase().replace('default_generated', '').trim()));
    if (c.generation_expr) parts.push(`= ${escapeHtml(c.generation_expr.replace(/_utf8mb4\\'/g, "'").replace(/\\'/g, "'"))}`);
    return parts.filter(Boolean).join(' · ');
  };
  return `
    <article class="table-card ${t.type === 'VIEW' ? 'is-view' : ''}" id="tbl-${escapeHtml(t.name)}">
      <header>
        <h3>${TABLE_ICON[t.name] || (t.type === 'VIEW' ? '👁️' : '🗃️')} ${escapeHtml(t.name)}</h3>
        <span class="tag ${t.type === 'VIEW' ? 'tag-view' : ''}">${t.type}</span>
        <span class="row-count">${t.rows} row${t.rows === 1 ? '' : 's'}</span>
      </header>
      <div class="table-scroll">
        <table class="col-table">
          <thead><tr><th>Column</th><th>Type</th><th>Key</th><th>Null</th><th>Default / extra</th></tr></thead>
          <tbody>${t.columns.map((c) => `
            <tr>
              <td><code>${escapeHtml(c.name)}</code></td>
              <td class="type">${escapeHtml(c.type)}</td>
              <td>${keyBadges(t, c)}</td>
              <td>${c.nullable === 'YES' ? 'yes' : '<b>no</b>'}</td>
              <td class="extra">${extra(c)}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      ${t.foreignKeys.length ? `<div class="constraints"><h4>Foreign keys</h4><ul>${t.foreignKeys.map((f) => `
        <li><code>${escapeHtml(f.col)}</code> → <a href="#tbl-${escapeHtml(f.ref_table)}"><code>${escapeHtml(f.ref_table)}.${escapeHtml(f.ref_col)}</code></a>
          <span class="hint">on delete ${escapeHtml(f.on_delete.toLowerCase())}</span></li>`).join('')}</ul></div>` : ''}
      ${t.uniques.length ? `<div class="constraints"><h4>Unique</h4><ul>${t.uniques.map((u) => `
        <li><code>${escapeHtml(u.name)}</code> (${escapeHtml(u.cols)})</li>`).join('')}</ul></div>` : ''}
      ${t.checks.length ? `<div class="constraints"><h4>Checks</h4><ul>${t.checks.map((c) => `
        <li><code>${escapeHtml(c.name)}</code> <span class="clause">${escapeHtml(c.clause.replace(/`/g, ''))}</span></li>`).join('')}</ul></div>` : ''}
    </article>`;
}

async function loadSchema() {
  try {
    const schema = await api.get('/architecture/schema');
    schema.tables = sortTables(schema.tables);
    $('#db-name').textContent = schema.database;
    renderStats(schema);
    renderER(schema);
    renderTriggers(schema.triggers);
    $('#table-cards').innerHTML = schema.tables.map(tableCard).join('');
  } catch (err) {
    $('#er-diagram').innerHTML = `<p class="state-msg">Couldn't load the schema: ${escapeHtml(err.message)}</p>`;
  }
}

// =====================================================================
// 3. USERS
// =====================================================================
let users = null;
let userType = 'owners';

const BASE_COLS = [
  ['ID', (u) => u.user_id],
  ['Name', (u) => `<b>${escapeHtml(u.full_name)}</b>`],
  ['Username', (u) => `<code>${escapeHtml(u.username)}</code>`],
  ['Password', (u) => `<span class="masked" title="Stored as a bcrypt hash; never sent to the browser">${escapeHtml(u.password)}</span>`],
  ['Email', (u) => escapeHtml(u.email)],
  ['Phone', (u) => escapeHtml(u.phone)],
  ['Address', (u) => escapeHtml(u.address || '—')],
  ['City', (u) => escapeHtml(u.city || '—')],
  ['Joined', (u) => prettyDate(u.created_at, { day: 'numeric', month: 'short', year: 'numeric' })]
];
const OWNER_COLS = [
  ['Pets', (u) => `${u.pet_count}${u.pet_names ? ` <span class="hint">(${escapeHtml(u.pet_names)})</span>` : ''}`],
  ['Appointments', (u) => u.appointment_count]
];
const providerCols = (type) => [
  ['Qualification', (u) => escapeHtml(u.qualification || '—')],
  ...(type === 'vets' ? [['License no.', (u) => `<code>${escapeHtml(u.license_no || '—')}</code>`]] : []),
  ['Experience', (u) => `${u.experience_years} yrs`],
  ['Working hours', (u) => `${u.work_start.slice(0, 5)} – ${u.work_end.slice(0, 5)}`],
  ['Rating', (u) => (u.avg_rating !== null ? `★ ${Number(u.avg_rating).toFixed(1)}` : '—')],
  ['Reviews', (u) => u.review_count],
  ['Appointments', (u) => u.appointment_count],
  ['Bio', (u) => `<span class="bio">${escapeHtml(u.bio || '—')}</span>`]
];

function renderUsers() {
  document.querySelectorAll('#user-tabs .dash-tab').forEach((t) => {
    t.setAttribute('aria-selected', t.dataset.type === userType);
    if (users) t.querySelector('.count').textContent = users[t.dataset.type].length;
  });
  if (!users) return;
  const cols = [...BASE_COLS, ...(userType === 'owners' ? OWNER_COLS : providerCols(userType))];
  const rows = users[userType];
  $('#user-table').innerHTML = rows.length ? `
    <table class="user-table">
      <thead><tr>${cols.map(([h]) => `<th>${h}</th>`).join('')}</tr></thead>
      <tbody>${rows.map((u) => `<tr>${cols.map(([, f]) => `<td>${f(u)}</td>`).join('')}</tr>`).join('')}</tbody>
    </table>` : '<p class="state-msg">No users of this type yet.</p>';
}

document.querySelectorAll('#user-tabs .dash-tab').forEach((t) => t.addEventListener('click', () => {
  userType = t.dataset.type;
  renderUsers();
}));

async function loadUsers() {
  try {
    users = await api.get('/architecture/users');
    renderUsers();
  } catch (err) {
    $('#user-table').innerHTML = `<p class="state-msg">Couldn't load users: ${escapeHtml(err.message)}</p>`;
  }
}

loadSchema();
loadUsers();
