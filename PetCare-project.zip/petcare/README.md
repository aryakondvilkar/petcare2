# 🐾 PetCare — Pet Services Booking System

PetCare is a full-stack web application where **pet owners** book appointments with **veterinarians**, **groomers** and **day walkers**.
Each booking appears on the provider's dashboard. Owners and providers share pet records, appointments can be rescheduled or cancelled, and owners rate completed visits.

Built as a **DBMS project** with **Node.js, Express and MySQL**. The database itself enforces every business rule through constraints, triggers and unique indexes, not only the user interface.

![Landing page](docs/screenshots/landing.png)

---

## Contents
1. [Features](#1-features)
2. [Tech stack](#2-tech-stack)
3. [System architecture](#3-system-architecture)
4. [Database design](#4-database-design)
5. [Business rules and how they're enforced](#5-business-rules-and-how-theyre-enforced)
6. [API reference](#6-api-reference)
7. [Security](#7-security)
8. [Setup: run it on your own laptop](#8-setup-run-it-on-your-own-laptop)
9. [Demo logins](#9-demo-logins)
10. [Project structure](#10-project-structure)
11. [Screenshots](#11-screenshots)
12. [Team](#12-team)

---

## 1. Features

### Landing page
- **12 services**, each with a photo, caption, ₹ price, duration and provider type, loaded from the database. You can filter by Vet / Groomer / Walker.
- **Demo logins** card with the built-in username and password for all 4 roles. One click fills in the login form.
- **Login / Sign up** and **System Architecture** buttons in the header.

### Login and sign up
- 4 roles, each with its own dashboard: **Pet Owner, Veterinarian, Groomer, Day Walker**.
- Sign up for any role. Providers also enter qualification and experience, and vets enter a license number.
- Errors are checked on the page and again on the server.

### Pet Owner dashboard
| Tab | What it does |
|---|---|
| **My Pets** | Add, edit and delete pets (species, breed, gender, date of birth, weight, notes) |
| **Book Appointment** | Pet → service → provider → date → hourly slot → optional note. **Past dates can't be picked**, **today's passed hours are disabled**, and **slots another owner has booked show "This slot is not available"** |
| **My Appointments** | Upcoming and past lists. Each appointment opens a panel with **Reschedule / Cancel**, **pet remarks / records** and a **1–5 star review** (once completed) |
| **Pet Records** | Every record for each pet, written by the owner or a provider |

### Provider dashboards (Vet · Groomer · Day Walker)
- Overview cards: today, upcoming, completed, average rating.
- **Bookings made by owners appear here automatically**, with the owner's contact details and the pet's details.
- Mark completed, reschedule, cancel, and add or edit pet records.
- **My Reviews**: every rating received, plus the average.
- **My Profile**: qualification, bio and **working hours**, which control which slots owners can book.

### System Architecture page
- **Database tables**, read live from MySQL's `INFORMATION_SCHEMA`: columns, data types, keys, constraints and row counts.
- **ER diagram** and the 3 **triggers**.
- **Workflow diagram** of the whole app.
- **Every user in the database**, in 4 tabs (Owners, Vets, Groomers, Walkers) with all details. Passwords show only as `•••••• (bcrypt)`.

---

## 2. Tech stack

| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3, vanilla JavaScript (no framework, no build step) |
| Backend | Node.js 18+, Express 4 |
| Database | MySQL 8 (driver: `mysql2/promise`, connection pool) |
| Auth | `express-session` (cookie sessions) + `bcryptjs` (password hashing) |
| Config | `dotenv` (`.env` file) |
| Dev tool | `nodemon` (auto-restart) |

---

## 3. System architecture

```
┌──────────────────────────┐      HTTP / JSON       ┌──────────────────────────┐      SQL       ┌──────────────┐
│  Browser (public/)       │  ───────────────────▶  │  Express server          │  ───────────▶  │  MySQL 8     │
│  HTML + CSS + JS         │  ◀───────────────────  │  (server/)               │  ◀───────────  │  petcare DB  │
│  index, login,           │    session cookie      │  routes → utils → pool   │                │  8 tables    │
│  owner, vet, groomer,    │                        │  auth middleware         │                │  3 triggers  │
│  walker, architecture    │                        │  error mapping           │                │  2 views     │
└──────────────────────────┘                        └──────────────────────────┘                └──────────────┘
```

**Three-tier design:**
1. **Presentation:** static pages in `public/`. Each page's script calls the API with `fetch` through `public/js/api.js`.
2. **Application:** the Express routes in `server/routes/` check login, role and ownership, validate input, and run parameterised SQL.
3. **Data:** MySQL holds the data and has the final say on every rule.

### Workflow
```
Visitor → Landing page → Login / Sign up ─┬─▶ Owner dashboard
                                          ├─▶ Vet dashboard
                                          ├─▶ Groomer dashboard
                                          └─▶ Walker dashboard

Owner: add pet → choose service → choose provider → choose date → see slot availability
       → book → APPOINTMENT (Booked)

APPOINTMENT → shows on provider's dashboard
            → owner or provider can reschedule (→ Rescheduled, logged in reschedule_history)
            → owner or provider can cancel   (→ Cancelled, slot becomes free again)
            → both can add / edit pet records
            → provider marks it done         (→ Completed)
            → owner leaves a 1–5 review      (one per appointment)
```

### Example: what happens when an owner books
1. The page asks `GET /api/providers/:id/availability?date=…&pet_id=…` for the 9 hourly slots.
2. The server marks each slot as free, **Time has passed**, **This slot is not available** (the provider is booked), **Outside working hours**, or *your pet already has an appointment*.
3. The owner picks a free slot, and the page sends `POST /api/appointments`.
4. The server re-checks every rule with the same function that built the slot list, then runs `INSERT`.
5. MySQL's trigger and unique indexes check one last time. If two owners click the same slot at the same moment, only one booking succeeds and the other gets *"This slot is not available"*.

---

## 4. Database design

Database `petcare`: **8 tables, 3 triggers, 2 views.** Schema file: `database/schema.sql`. Sample data: `database/seed.sql`.

### 4.1 Entity–relationship summary
```
users (role = owner) ──1:N── pets ──1:N── appointments ──N:1── users (role = vet / groomer / walker)
                                              │  └──────N:1── services
                                              ├──1:1── reviews
                                              ├──1:N── reschedule_history
                                              └──1:N── pet_records
users (provider) ──1:1── provider_profiles
```

| Relationship | Type | How it's made |
|---|---|---|
| Owner → Pets | 1 : N | `pets.owner_id` → `users.user_id` |
| Provider → Profile | 1 : 1 | `provider_profiles.provider_id` is both the PK and an FK to `users` |
| Owner ↔ Provider | **M : N** | resolved through `appointments` |
| Pet ↔ Service | **M : N** | resolved through `appointments` |
| Appointment → Review | 1 : 1 | `reviews.appointment_id` is `UNIQUE` |
| Appointment → Reschedules | 1 : N | `reschedule_history.appointment_id` |
| Pet / Appointment → Records | 1 : N | `pet_records.pet_id`, `pet_records.appointment_id` (nullable) |

### 4.2 Tables

#### `users`: every account (owners and the 3 provider types)
| Column | Type | Notes |
|---|---|---|
| `user_id` | INT | **PK**, auto increment |
| `full_name` | VARCHAR(100) | NOT NULL |
| `username` | VARCHAR(50) | NOT NULL, **UNIQUE** |
| `password_hash` | VARCHAR(100) | bcrypt hash, never sent to the browser |
| `role` | ENUM('owner','vet','groomer','walker') | NOT NULL |
| `email` | VARCHAR(120) | NOT NULL, **UNIQUE** |
| `phone` | VARCHAR(15) | CHECK length ≥ 10 |
| `address`, `city` | VARCHAR | city defaults to Mumbai |
| `created_at` | TIMESTAMP | default now |

#### `provider_profiles`: extra details for vets, groomers and walkers
| Column | Type | Notes |
|---|---|---|
| `provider_id` | INT | **PK + FK** → `users.user_id` (ON DELETE CASCADE) |
| `qualification` | VARCHAR(120) | |
| `license_no` | VARCHAR(40) | vets only |
| `experience_years` | INT | CHECK 0–60 |
| `bio` | VARCHAR(500) | |
| `work_start`, `work_end` | TIME | default 09:00 / 18:00, CHECK end > start |

#### `pets`
| Column | Type | Notes |
|---|---|---|
| `pet_id` | INT | **PK** |
| `owner_id` | INT | **FK** → `users` (CASCADE) |
| `name` | VARCHAR(50) | NOT NULL |
| `species` | ENUM('Dog','Cat','Rabbit','Bird','Other') | |
| `breed` | VARCHAR(60) | |
| `gender` | ENUM('Male','Female') | |
| `dob` | DATE | |
| `weight_kg` | DECIMAL(5,2) | CHECK > 0 |
| `notes` | VARCHAR(255) | allergies, temperament |

#### `services`: the 12 services on the landing page
| Column | Type | Notes |
|---|---|---|
| `service_id` | INT | **PK** |
| `name` | VARCHAR(60) | **UNIQUE** |
| `caption`, `description` | VARCHAR | |
| `image_url` | VARCHAR(255) | `/images/services/<name>.jpg` |
| `provider_role` | ENUM('vet','groomer','walker') | which kind of provider performs it |
| `duration_min` | INT | CHECK > 0 |
| `price` | DECIMAL(8,2) | ₹, CHECK ≥ 0 |
| `is_active` | BOOLEAN | |

#### `appointments`: the core table
| Column | Type | Notes |
|---|---|---|
| `appointment_id` | INT | **PK** |
| `owner_id` | INT | **FK** → `users` |
| `pet_id` | INT | **FK** → `pets` |
| `provider_id` | INT | **FK** → `users` |
| `service_id` | INT | **FK** → `services` (RESTRICT) |
| `appt_date` | DATE | |
| `start_time` | TIME | CHECK whole hour from 09:00 to 17:00 |
| `status` | ENUM('Booked','Rescheduled','Completed','Cancelled') | default Booked |
| `owner_note` | VARCHAR(255) | |
| `created_at`, `updated_at` | TIMESTAMP | |
| `slot_lock` | TINYINT, **generated** | `1` while active, `NULL` once cancelled |

Unique indexes:
- `uq_provider_slot (provider_id, appt_date, start_time, slot_lock)`: a provider can't be double-booked.
- `uq_pet_slot (pet_id, appt_date, start_time, slot_lock)`: a pet can't be in two places at once.

#### `reschedule_history`
| Column | Type | Notes |
|---|---|---|
| `reschedule_id` | INT | **PK** |
| `appointment_id` | INT | **FK** → `appointments` (CASCADE) |
| `old_date`, `old_time`, `new_date`, `new_time` | DATE / TIME | before and after |
| `rescheduled_by` | INT | **FK** → `users` |
| `reason` | VARCHAR(255) | |
| `changed_at` | TIMESTAMP | |

#### `pet_records`: remarks and medical, grooming and behaviour notes
| Column | Type | Notes |
|---|---|---|
| `record_id` | INT | **PK** |
| `pet_id` | INT | **FK** → `pets` |
| `appointment_id` | INT | **FK** → `appointments`, NULL for a general owner note |
| `record_type` | ENUM('Remark','Medical','Vaccination','Grooming','Behaviour') | |
| `title`, `details` | VARCHAR / TEXT | |
| `created_by`, `last_edited_by` | INT | **FK** → `users` |
| `created_at`, `updated_at` | TIMESTAMP | |

#### `reviews`
| Column | Type | Notes |
|---|---|---|
| `review_id` | INT | **PK** |
| `appointment_id` | INT | **FK**, **UNIQUE** (one review per appointment) |
| `owner_id`, `provider_id` | INT | **FK** → `users` |
| `rating` | TINYINT | CHECK 1–5 |
| `comment` | VARCHAR(500) | |

### 4.3 Triggers
| Trigger | When | What it blocks |
|---|---|---|
| `trg_appt_before_insert` | BEFORE INSERT on `appointments` | booking a date or time that has passed; a provider whose role doesn't match the service; booking a pet that isn't the owner's |
| `trg_appt_before_update` | BEFORE UPDATE on `appointments` | rescheduling into the past; rescheduling a completed or cancelled appointment |
| `trg_review_before_insert` | BEFORE INSERT on `reviews` | reviewing an appointment that isn't completed; a review whose owner or provider doesn't match the appointment |

Triggers are used because a `CHECK` constraint **can't call `NOW()`** or **read other tables**.

### 4.4 Views
| View | Purpose |
|---|---|
| `v_provider_directory` | providers joined with their profile, **average rating** and review count |
| `v_appointment_details` | each appointment with owner, pet, provider and service names, plus its review |

### 4.5 Normalisation
- Every table has a single-column surrogate primary key, and every non-key column depends only on that key: **3NF**.
- Provider-only fields live in `provider_profiles`, not in `users`, so owners have no empty provider columns.
- Average ratings aren't stored. The view calculates them, so they can never go out of date.

---

## 5. Business rules and how they're enforced

| # | Rule | UI | API | Database |
|---|---|---|---|---|
| B1 | A date or time that has passed can't be booked | date `min` = today, passed hours disabled | ✔ | trigger |
| B2 | A reschedule can't move into the past | ✔ | ✔ | trigger |
| B3 | A provider can't be double-booked → **"This slot is not available"** | slot shown as unavailable | ✔ | `uq_provider_slot` |
| B4 | A pet can't have two appointments in the same slot | ✔ | ✔ | `uq_pet_slot` |
| B5 | The provider type must match the service | provider list filtered | ✔ | trigger |
| B6 | Owners book only for their own pets | ✔ | ✔ | trigger |
| B7 | Slots are whole hours from 09:00 to 17:00 | ✔ | ✔ | CHECK |
| B8 | Only completed appointments can be reviewed, once each, rated 1–5 | ✔ | ✔ | trigger + UNIQUE + CHECK |
| B9 | Completed or cancelled appointments can't be rescheduled | ✔ | ✔ | trigger |
| B10 | Cancelling frees the slot | ✔ | ✔ | generated `slot_lock` becomes NULL |
| B11 | A record can be edited only by the pet's owner or that appointment's provider | ✔ | ✔ | — |

**How `slot_lock` works:** a UNIQUE index treats `NULL`s as distinct. So while an appointment is active (`slot_lock = 1`), nobody else can take that provider's slot. Once it's cancelled (`slot_lock = NULL`), the slot is free again, and the cancelled row stays in the table as history.

---

## 6. API reference

Base URL `http://localhost:3000/api`. Requests and responses are JSON, and errors come back as `{ "error": "message" }`. Full contract: [`docs/API.md`](docs/API.md).

| Method | Endpoint | Who |
|---|---|---|
| POST | `/auth/login` · `/auth/signup` · `/auth/logout` | anyone |
| GET | `/auth/me` · `/auth/demo-logins` | logged in · anyone |
| GET | `/services` · `/services/:id/providers` | anyone |
| GET | `/providers/:id/availability?date=` | logged in |
| GET / PUT | `/providers/me/profile` · GET `/providers/me/reviews` | provider |
| GET / POST / PUT / DELETE | `/pets` · `/pets/:id` | owner (own pets) |
| GET | `/appointments/mine?scope=upcoming\|past\|all` · `/appointments/:id` | owner or provider on it |
| POST | `/appointments` | owner |
| PUT | `/appointments/:id/reschedule` · `/appointments/:id/status` | owner or provider on it |
| GET / POST / PUT | `/records` · `/records/:id` | rule B11 |
| POST | `/reviews` | owner of a completed appointment |
| GET | `/architecture/schema` · `/architecture/users` | anyone (read-only) |

How MySQL errors become user messages (`server/utils/errors.js`):

| MySQL error | Message shown | HTTP |
|---|---|---|
| Duplicate on `uq_provider_slot` | This slot is not available | 409 |
| Duplicate on `uq_pet_slot` | Your pet already has an appointment at this time | 409 |
| Duplicate username / email | Username already taken / Email already registered | 409 |
| Trigger SIGNAL `45000` | the trigger's own message | 400 |
| CHECK failed | Invalid value | 400 |

---

## 7. Security
- **Passwords** are stored as **bcrypt** hashes, never in plain text, and the hash is never sent to the browser.
- **Sessions:** cookie-based (`httpOnly`, `sameSite=lax`). A fresh session ID is issued on login and sign-up, which prevents session fixation.
- **SQL injection:** every query uses **parameterised statements** (`pool.execute(sql, [params])`).
- **Access control:** every route checks login, role and **ownership**. Requests for other people's records return "not found", so their IDs aren't revealed.
- **XSS:** everything shown on a page is escaped before it's inserted.
- **Race conditions:**
  - Bookings are protected by unique indexes.
  - A reschedule updates the appointment and writes its history together in one transaction, after locking the appointment row (`SELECT … FOR UPDATE`).
  - Cancel and complete only take effect if the appointment is still open.
- **Secrets** live in `.env`, which is excluded by `.gitignore` and **not included when sharing the project**.

---

## 8. Setup: run it on your own laptop

### You need
- **Node.js 18 or newer:** https://nodejs.org (check with `node -v`)
- **MySQL 8:** https://dev.mysql.com/downloads/installer/ (remember the root password you set)

### Steps
1. **Unzip** the project and open the `petcare` folder in VS Code (or any terminal).
2. **Install packages:**
   ```bash
   npm install
   ```
3. **Create the database and load the sample data.**

   **Command Prompt / macOS / Linux:**
   ```bash
   mysql -u root -p < database/schema.sql
   mysql -u root -p petcare < database/seed.sql
   ```
   **Windows PowerShell** (doesn't support `<`):
   ```powershell
   cmd /c "mysql -u root -p < database\schema.sql"
   cmd /c "mysql -u root -p petcare < database\seed.sql"
   ```
   If `mysql` isn't recognised, either use the full path (`"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"`) or open both `.sql` files in **MySQL Workbench** and click ⚡ Execute, running `schema.sql` first.
4. **Create your `.env` file:**
   ```bash
   copy .env.example .env      # Windows
   cp .env.example .env        # macOS / Linux
   ```
   Open `.env` and set `DB_PASSWORD=` to **your** MySQL root password.
5. **Start the server:**
   ```bash
   npm run dev
   ```
   You should see `MySQL connected — 12 services in database`.
6. Open **http://localhost:3000**.

To **reset to the original sample data** at any time, run step 3 again.

### Troubleshooting
| Problem | Fix |
|---|---|
| `MySQL connection FAILED: Access denied` | wrong `DB_PASSWORD` in `.env` |
| `Unknown database 'petcare'` | run `schema.sql` (step 3) |
| `0 services` or empty landing page | run `seed.sql` |
| `EADDRINUSE :3000` | another app is using port 3000. Close it, or set `PORT=3001` in `.env` |
| A booking says the time has passed | the demo data uses dates relative to the day you imported it. Re-run step 3 to refresh them |

---

## 9. Demo logins

| Role | Username | Password |
|---|---|---|
| Pet Owner | `owner1` · `owner2` · `owner3` | `owner123` |
| Veterinarian | `vet1` · `vet2` | `vet123` |
| Groomer | `groomer1` · `groomer2` | `groomer123` |
| Day Walker | `walker1` · `walker2` | `walker123` |

Sample data: 9 users, 12 services, 5 pets, 11 appointments (upcoming, completed, rescheduled and cancelled), pet records and reviews.

---

## 10. Project structure
```
petcare/
├── README.md               ← this file
├── TESTING.md              ← manual test checklist
├── CLAUDE.md               ← build rules used during development
├── package.json            ← dependencies and scripts (npm run dev)
├── .env.example            ← copy to .env and add your MySQL password
├── database/
│   ├── schema.sql          ← tables, constraints, triggers, views
│   └── seed.sql            ← sample data
├── docs/
│   ├── SPEC.md             ← requirements (R1–R9, rules B1–B11)
│   ├── API.md              ← full endpoint contract
│   ├── PHASES.md           ← build plan
│   └── screenshots/
├── server/
│   ├── server.js           ← Express app entry point
│   ├── config/db.js        ← MySQL connection pool
│   ├── middleware/auth.js  ← requireLogin / requireRole
│   ├── utils/
│   │   ├── errors.js       ← MySQL error → clean message
│   │   ├── dates.js        ← slot hours, "has this slot passed?"
│   │   ├── availability.js ← slot list (shared by availability, booking, reschedule)
│   │   └── access.js       ← ownership checks + record queries
│   └── routes/             ← auth, services, providers, pets, appointments, records, reviews, architecture
└── public/
    ├── index.html  login.html  architecture.html
    ├── owner.html  vet.html  groomer.html  walker.html
    ├── css/style.css
    ├── js/                 ← api.js (shared helpers) + one script per page
    └── images/             ← hero + 12 service photos (Unsplash)
```

---

## 11. Screenshots

| Booking | Appointment detail |
|---|---|
| ![Booking](docs/screenshots/booking.png) | ![Appointment detail](docs/screenshots/appointment.png) |

| Vet dashboard | System Architecture (ER diagram) |
|---|---|
| ![Vet dashboard](docs/screenshots/vet.png) | ![Architecture](docs/screenshots/architecture.png) |

---

## 12. Team
- **Girish Awade**: [@girishawade123-sudo](https://github.com/girishawade123-sudo)

Computer Engineering, Vidyalankar Institute of Technology, Mumbai
