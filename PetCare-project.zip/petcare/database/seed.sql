-- ============================================================
-- PetCare — sample data
-- Run AFTER schema.sql:   mysql -u root -p petcare < database/seed.sql
--
-- Dates are relative to CURDATE(), so the demo always has
-- upcoming bookings and past (completed) history.
--
-- BUILT-IN LOGINS (also shown on the landing page)
--   Pet owner     owner1 / owner123     (owner2, owner3 same password)
--   Veterinarian  vet1   / vet123       (vet2)
--   Groomer       groomer1 / groomer123 (groomer2)
--   Day walker    walker1 / walker123   (walker2)
-- ============================================================
USE petcare;

SET @seed_mode = 1;   -- lets the trigger accept past (history) appointments

-- ---------- USERS (ids 1–9) ----------
INSERT INTO users (user_id, full_name, username, password_hash, role, email, phone, address, city) VALUES
(1, 'Aarav Mehta',      'owner1',   '$2a$10$n6ZHz6S6qhS2ZJoCrdxd4.w4eH9fnQJ8gEowQFKhxQaTm7wNfIH82', 'owner',   'aarav.mehta@petcare.in',   '9820011223', 'Flat 402, Sai Krupa, Dadar West',      'Mumbai'),
(2, 'Priya Nair',       'owner2',   '$2a$10$n6ZHz6S6qhS2ZJoCrdxd4.w4eH9fnQJ8gEowQFKhxQaTm7wNfIH82', 'owner',   'priya.nair@petcare.in',    '9867023344', 'B-12, Hiranandani Gardens, Powai',     'Mumbai'),
(3, 'Rohan Kulkarni',   'owner3',   '$2a$10$n6ZHz6S6qhS2ZJoCrdxd4.w4eH9fnQJ8gEowQFKhxQaTm7wNfIH82', 'owner',   'rohan.kulkarni@petcare.in','9930045566', '7, Shivaji Park Road, Mahim',          'Mumbai'),
(4, 'Dr. Sneha Patil',  'vet1',     '$2a$10$JkKGRLOTKIzem7tKfzACwe8veEfldd6ZJ8mQBzKafKog/xT9Ex/yK', 'vet',     'sneha.patil@petcare.in',   '9821167788', 'PetCare Clinic, Wadala East',          'Mumbai'),
(5, 'Dr. Arjun Rao',    'vet2',     '$2a$10$JkKGRLOTKIzem7tKfzACwe8veEfldd6ZJ8mQBzKafKog/xT9Ex/yK', 'vet',     'arjun.rao@petcare.in',     '9819078899', 'PetCare Clinic, Andheri West',         'Mumbai'),
(6, 'Kavya Iyer',       'groomer1', '$2a$10$RFCqjxalc09Xkw17qVbL/O5YZpawSTTepBUxnojxORwboaatjSHv6', 'groomer', 'kavya.iyer@petcare.in',    '9833012345', 'PetCare Spa, Bandra West',             'Mumbai'),
(7, 'Imran Shaikh',     'groomer2', '$2a$10$RFCqjxalc09Xkw17qVbL/O5YZpawSTTepBUxnojxORwboaatjSHv6', 'groomer', 'imran.shaikh@petcare.in',  '9892234567', 'PetCare Spa, Chembur',                 'Mumbai'),
(8, 'Rahul Deshmukh',   'walker1',  '$2a$10$a1nVGtXtSOWUM2XUt11IHO/XBrAytDza4YZ8oY1ARl9uGsCI73qg6', 'walker',  'rahul.deshmukh@petcare.in','9773345678', 'Sion Koliwada',                        'Mumbai'),
(9, 'Ananya Joshi',     'walker2',  '$2a$10$a1nVGtXtSOWUM2XUt11IHO/XBrAytDza4YZ8oY1ARl9uGsCI73qg6', 'walker',  'ananya.joshi@petcare.in',  '9004456789', 'Matunga East',                         'Mumbai');

-- ---------- PROVIDER PROFILES ----------
INSERT INTO provider_profiles (provider_id, qualification, license_no, experience_years, bio, work_start, work_end) VALUES
(4, 'BVSc & AH, MVSc (Medicine)', 'MSVC-2014-0871', 11, 'Small-animal physician. Preventive care, vaccinations and senior-pet checkups.', '09:00:00', '18:00:00'),
(5, 'BVSc & AH',                  'MSVC-2019-1452',  6, 'General practice vet with a soft spot for rabbits and cats.',                    '09:00:00', '18:00:00'),
(6, 'Certified Pet Groomer (IPG)', NULL,             7, 'Breed-specific cuts, de-shedding and nervous-pet handling.',                    '09:00:00', '18:00:00'),
(7, 'Diploma in Pet Grooming',     NULL,             4, 'Bath, blow-dry and hygiene grooming. Calm with cats.',                          '09:00:00', '18:00:00'),
(8, 'Canine Behaviour Course',     NULL,             5, 'Daily walks, daycare and agility drills for high-energy dogs.',                 '09:00:00', '18:00:00'),
(9, 'Pet First-Aid Certified',     NULL,             3, 'Pet sitting, daycare and leash training.',                                     '09:00:00', '18:00:00');

-- ---------- SERVICES (the 12 landing-page cards) ----------
INSERT INTO services (service_id, name, caption, description, image_url, provider_role, duration_min, price) VALUES
( 1, 'Routine Health Checkup', 'Head-to-tail exam by a qualified vet',        'Weight, heart, eyes, ears, teeth and skin check with a written report.', '/images/services/health-checkup.jpg',  'vet',      60,  700.00),
( 2, 'Vaccination',            'Core and booster shots on schedule',          'Rabies, DHPP, FVRCP and boosters, logged to your pet''s record.',        '/images/services/vaccination.jpg',     'vet',      60,  900.00),
( 3, 'Dental Cleaning',        'Healthy teeth, fresher breath',               'Scaling and polishing with an oral-health check.',                      '/images/services/dental-cleaning.jpg', 'vet',      60, 1500.00),
( 4, 'Deworming',              'Protection against internal parasites',       'Weight-based deworming dose with a follow-up reminder.',                '/images/services/deworming.jpg',       'vet',      60,  400.00),
( 5, 'Hair Trimming',          'Breed-style cuts and tidy-ups',               'Full haircut or face, paw and sanitary trim.',                          '/images/services/hair-trimming.jpg',   'groomer',  60,  800.00),
( 6, 'Nail Trimming',          'Quick, gentle and stress-free',               'Clip and file, including dew claws.',                                  '/images/services/nail-trimming.jpg',   'groomer',  60,  300.00),
( 7, 'Bath & Blow Dry',        'Shampoo, condition and fluff',                'Coat-specific shampoo, conditioner and a full blow-dry.',               '/images/services/bath-blow-dry.jpg',   'groomer',  60,  650.00),
( 8, 'Ear Cleaning',           'Clean ears, happy pet',                       'Gentle ear flush and wipe to prevent infections.',                      '/images/services/ear-cleaning.jpg',    'groomer',  60,  350.00),
( 9, 'Daycare',                'Supervised play while you work',              'Play, rest and meals in a supervised group.',                           '/images/services/daycare.jpg',         'walker',   60, 1200.00),
(10, 'Agility Training',       'Jumps, tunnels and weave poles',              'Obstacle work that builds fitness and focus.',                          '/images/services/agility-training.jpg','walker',   60, 1000.00),
(11, 'Dog Walking',            'A brisk walk around your neighbourhood',      'One-hour walk with photo updates.',                                     '/images/services/dog-walking.jpg',     'walker',   60,  300.00),
(12, 'Pet Sitting',            'Home visits while you are away',              'Feeding, litter or walk, and company at your home.',                    '/images/services/pet-sitting.jpg',     'walker',   60,  900.00);

-- ---------- PETS (ids 1–5) ----------
INSERT INTO pets (pet_id, owner_id, name, species, breed, gender, dob, weight_kg, notes) VALUES
(1, 1, 'Bruno',  'Dog',    'Labrador Retriever',  'Male',   '2021-03-14', 28.50, 'Loves fetch. Allergic to chicken.'),
(2, 1, 'Mithi',  'Cat',    'Indian Shorthair',    'Female', '2022-07-02',  3.80, 'Nervous around loud dryers.'),
(3, 2, 'Coco',   'Dog',    'Shih Tzu',            'Female', '2020-11-20',  6.20, 'Needs eye cleaning weekly.'),
(4, 3, 'Simba',  'Dog',    'Golden Retriever',    'Male',   '2019-05-09', 31.00, 'Senior — gentle with joints.'),
(5, 3, 'Pepper', 'Rabbit', 'Holland Lop',         'Female', '2023-01-15',  1.70, 'Hay-only diet.');

-- ---------- APPOINTMENTS ----------
-- upcoming
INSERT INTO appointments (appointment_id, owner_id, pet_id, provider_id, service_id, appt_date, start_time, status, owner_note) VALUES
( 1, 1, 1, 4,  1, CURDATE() + INTERVAL 1 DAY, '10:00:00', 'Booked',      'Annual checkup, also check his left ear.'),
( 2, 2, 3, 4,  2, CURDATE() + INTERVAL 1 DAY, '11:00:00', 'Booked',      'Rabies booster due.'),
( 3, 3, 4, 6,  5, CURDATE() + INTERVAL 2 DAY, '10:00:00', 'Booked',      'Summer cut please.'),
( 4, 1, 2, 7,  6, CURDATE() + INTERVAL 3 DAY, '15:00:00', 'Rescheduled', 'Please use a quiet room.'),
( 5, 2, 3, 8, 11, CURDATE() + INTERVAL 1 DAY, '09:00:00', 'Booked',      NULL),
( 6, 3, 5, 5,  4, CURDATE() + INTERVAL 4 DAY, '12:00:00', 'Booked',      'First deworming for Pepper.');
-- history
INSERT INTO appointments (appointment_id, owner_id, pet_id, provider_id, service_id, appt_date, start_time, status, owner_note) VALUES
( 7, 1, 1, 9, 10, CURDATE() - INTERVAL 5 DAY,  '16:00:00', 'Completed', NULL),
( 8, 2, 3, 6,  7, CURDATE() - INTERVAL 3 DAY,  '14:00:00', 'Completed', NULL),
( 9, 3, 4, 4,  2, CURDATE() - INTERVAL 10 DAY, '10:00:00', 'Completed', 'DHPP booster.'),
(10, 1, 1, 5,  1, CURDATE() - INTERVAL 2 DAY,  '11:00:00', 'Cancelled', NULL),
(11, 3, 4, 8,  9, CURDATE() - INTERVAL 1 DAY,  '09:00:00', 'Completed', NULL);

-- ---------- RESCHEDULE HISTORY ----------
INSERT INTO reschedule_history (appointment_id, old_date, old_time, new_date, new_time, rescheduled_by, reason) VALUES
(4, CURDATE() + INTERVAL 2 DAY, '12:00:00', CURDATE() + INTERVAL 3 DAY, '15:00:00', 1, 'Office meeting clashed.');

-- ---------- PET RECORDS ----------
INSERT INTO pet_records (pet_id, appointment_id, record_type, title, details, created_by, last_edited_by) VALUES
(4, 9,    'Vaccination', 'DHPP booster given',     'DHPP booster administered. Next due in 12 months. Mild lethargy expected for 24h.', 4, 4),
(4, 9,    'Medical',     'Joint stiffness noted',  'Slight stiffness in hind legs. Recommend glucosamine and shorter walks.',          4, 3),
(3, 8,    'Grooming',    'Bath & blow dry done',   'Used tear-stain shampoo. Slight matting behind ears removed.',                     6, 6),
(1, 7,    'Behaviour',   'Agility session 1',      'Cleared 6/8 jumps. Hesitant at tunnel; reward-based approach works.',              9, 9),
(1, NULL, 'Remark',      'Food allergy',           'Allergic to chicken — please do not give chicken-based treats.',                  1, 1);

-- ---------- REVIEWS ----------
INSERT INTO reviews (appointment_id, owner_id, provider_id, rating, comment) VALUES
(7, 1, 9, 5, 'Ananya was patient with Bruno and sent videos. Great session!'),
(8, 2, 6, 4, 'Coco looks lovely. Took a little longer than expected.'),
(9, 3, 4, 5, 'Dr. Sneha explained everything clearly. Very caring.');

SET @seed_mode = 0;
