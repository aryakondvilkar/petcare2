-- ============================================================
-- PetCare — Pet Services Booking System
-- MySQL 8.x schema  (also runs on MariaDB 10.6+)
--
-- Run:   mysql -u root -p < database/schema.sql
--        mysql -u root -p petcare < database/seed.sql
-- ============================================================

DROP DATABASE IF EXISTS petcare;
CREATE DATABASE petcare CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE petcare;

-- ------------------------------------------------------------
-- 1. USERS — every account: pet owners and the 3 provider types
-- ------------------------------------------------------------
CREATE TABLE users (
  user_id        INT AUTO_INCREMENT PRIMARY KEY,
  full_name      VARCHAR(100) NOT NULL,
  username       VARCHAR(50)  NOT NULL UNIQUE,
  password_hash  VARCHAR(100) NOT NULL,                 -- bcrypt
  role           ENUM('owner','vet','groomer','walker') NOT NULL,
  email          VARCHAR(120) NOT NULL UNIQUE,
  phone          VARCHAR(15)  NOT NULL,
  address        VARCHAR(255),
  city           VARCHAR(60)  DEFAULT 'Mumbai',
  created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_users_phone CHECK (CHAR_LENGTH(phone) >= 10)
);

-- ------------------------------------------------------------
-- 2. PROVIDER_PROFILES — extra details for vet / groomer / walker
--    1:1 with users (only for provider roles)
-- ------------------------------------------------------------
CREATE TABLE provider_profiles (
  provider_id       INT PRIMARY KEY,
  qualification     VARCHAR(120),
  license_no        VARCHAR(40),                         -- vets only
  experience_years  INT  NOT NULL DEFAULT 0,
  bio               VARCHAR(500),
  work_start        TIME NOT NULL DEFAULT '09:00:00',
  work_end          TIME NOT NULL DEFAULT '18:00:00',
  CONSTRAINT fk_profile_user FOREIGN KEY (provider_id)
    REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT chk_profile_exp   CHECK (experience_years BETWEEN 0 AND 60),
  CONSTRAINT chk_profile_hours CHECK (work_end > work_start)
);

-- ------------------------------------------------------------
-- 3. PETS — belong to an owner (1 owner : N pets)
-- ------------------------------------------------------------
CREATE TABLE pets (
  pet_id      INT AUTO_INCREMENT PRIMARY KEY,
  owner_id    INT NOT NULL,
  name        VARCHAR(50) NOT NULL,
  species     ENUM('Dog','Cat','Rabbit','Bird','Other') NOT NULL,
  breed       VARCHAR(60),
  gender      ENUM('Male','Female') NOT NULL,
  dob         DATE,
  weight_kg   DECIMAL(5,2),
  notes       VARCHAR(255),                              -- allergies, temperament
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pet_owner FOREIGN KEY (owner_id)
    REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT chk_pet_weight CHECK (weight_kg IS NULL OR weight_kg > 0)
);

-- ------------------------------------------------------------
-- 4. SERVICES — the 12 services on the landing page.
--    provider_role says which kind of provider performs it.
-- ------------------------------------------------------------
CREATE TABLE services (
  service_id     INT AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(60)  NOT NULL UNIQUE,
  caption        VARCHAR(120) NOT NULL,                  -- short line under the picture
  description    VARCHAR(500),
  image_url      VARCHAR(255) NOT NULL,                  -- /images/services/<slug>.jpg
  provider_role  ENUM('vet','groomer','walker') NOT NULL,
  duration_min   INT NOT NULL DEFAULT 60,
  price          DECIMAL(8,2) NOT NULL,                  -- INR
  is_active      BOOLEAN NOT NULL DEFAULT TRUE,
  CONSTRAINT chk_service_price CHECK (price >= 0),
  CONSTRAINT chk_service_dur   CHECK (duration_min > 0)
);

-- ------------------------------------------------------------
-- 5. APPOINTMENTS — owner books a service for a pet with a provider.
--    Fixed 1-hour slots, 09:00 – 17:00 start times.
-- ------------------------------------------------------------
CREATE TABLE appointments (
  appointment_id  INT AUTO_INCREMENT PRIMARY KEY,
  owner_id        INT  NOT NULL,
  pet_id          INT  NOT NULL,
  provider_id     INT  NOT NULL,
  service_id      INT  NOT NULL,
  appt_date       DATE NOT NULL,
  start_time      TIME NOT NULL,
  status          ENUM('Booked','Rescheduled','Completed','Cancelled')
                  NOT NULL DEFAULT 'Booked',
  owner_note      VARCHAR(255),                          -- note added while booking
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  -- 1 while the appointment holds its slot, NULL once cancelled.
  -- NULLs never clash in a UNIQUE index, so cancelled slots free up.
  slot_lock       TINYINT GENERATED ALWAYS AS
                  (CASE WHEN status = 'Cancelled' THEN NULL ELSE 1 END) STORED,

  CONSTRAINT fk_appt_owner    FOREIGN KEY (owner_id)    REFERENCES users(user_id)       ON DELETE CASCADE,
  CONSTRAINT fk_appt_pet      FOREIGN KEY (pet_id)      REFERENCES pets(pet_id)         ON DELETE CASCADE,
  CONSTRAINT fk_appt_provider FOREIGN KEY (provider_id) REFERENCES users(user_id)       ON DELETE CASCADE,
  CONSTRAINT fk_appt_service  FOREIGN KEY (service_id)  REFERENCES services(service_id) ON DELETE RESTRICT,

  -- whole-hour slots inside working hours
  CONSTRAINT chk_appt_slot CHECK (MINUTE(start_time) = 0 AND SECOND(start_time) = 0
                                  AND start_time BETWEEN '09:00:00' AND '17:00:00'),

  -- "This slot is not available": a provider can hold one live booking per slot
  CONSTRAINT uq_provider_slot UNIQUE (provider_id, appt_date, start_time, slot_lock),
  -- a pet cannot be in two places at once
  CONSTRAINT uq_pet_slot      UNIQUE (pet_id, appt_date, start_time, slot_lock)
);

CREATE INDEX idx_appt_owner    ON appointments(owner_id, appt_date);
CREATE INDEX idx_appt_provider ON appointments(provider_id, appt_date);

-- ------------------------------------------------------------
-- 6. RESCHEDULE_HISTORY — every reschedule of an appointment
-- ------------------------------------------------------------
CREATE TABLE reschedule_history (
  reschedule_id   INT AUTO_INCREMENT PRIMARY KEY,
  appointment_id  INT  NOT NULL,
  old_date        DATE NOT NULL,
  old_time        TIME NOT NULL,
  new_date        DATE NOT NULL,
  new_time        TIME NOT NULL,
  rescheduled_by  INT  NOT NULL,
  reason          VARCHAR(255),
  changed_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_resched_appt FOREIGN KEY (appointment_id)
    REFERENCES appointments(appointment_id) ON DELETE CASCADE,
  CONSTRAINT fk_resched_user FOREIGN KEY (rescheduled_by)
    REFERENCES users(user_id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- 7. PET_RECORDS — remarks / medical & grooming records.
--    Editable by the pet's owner AND the appointment's provider.
-- ------------------------------------------------------------
CREATE TABLE pet_records (
  record_id       INT AUTO_INCREMENT PRIMARY KEY,
  pet_id          INT NOT NULL,
  appointment_id  INT,                                   -- NULL = general owner note
  record_type     ENUM('Remark','Medical','Vaccination','Grooming','Behaviour') NOT NULL DEFAULT 'Remark',
  title           VARCHAR(100) NOT NULL,
  details         TEXT NOT NULL,
  created_by      INT NOT NULL,
  last_edited_by  INT,
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_record_pet    FOREIGN KEY (pet_id)         REFERENCES pets(pet_id)                 ON DELETE CASCADE,
  CONSTRAINT fk_record_appt   FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id) ON DELETE SET NULL,
  CONSTRAINT fk_record_author FOREIGN KEY (created_by)     REFERENCES users(user_id)               ON DELETE CASCADE,
  CONSTRAINT fk_record_editor FOREIGN KEY (last_edited_by) REFERENCES users(user_id)               ON DELETE SET NULL
);

-- ------------------------------------------------------------
-- 8. REVIEWS — one rating per completed appointment
-- ------------------------------------------------------------
CREATE TABLE reviews (
  review_id       INT AUTO_INCREMENT PRIMARY KEY,
  appointment_id  INT NOT NULL UNIQUE,
  owner_id        INT NOT NULL,
  provider_id     INT NOT NULL,
  rating          TINYINT NOT NULL,
  comment         VARCHAR(500),
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_review_appt     FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id) ON DELETE CASCADE,
  CONSTRAINT fk_review_owner    FOREIGN KEY (owner_id)       REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_review_provider FOREIGN KEY (provider_id)    REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT chk_review_rating  CHECK (rating BETWEEN 1 AND 5)
);

-- ============================================================
-- TRIGGERS — rules a CHECK constraint can't express
-- (CHECK can't call NOW() or read other tables)
-- ============================================================
DELIMITER $$

CREATE TRIGGER trg_appt_before_insert
BEFORE INSERT ON appointments
FOR EACH ROW
BEGIN
  DECLARE v_service_role VARCHAR(10);
  DECLARE v_provider_role VARCHAR(10);
  DECLARE v_pet_owner INT;

  -- no booking for a date/time that has already passed
  -- (@seed_mode = 1 is set only by seed.sql so it can insert past history)
  IF COALESCE(@seed_mode, 0) = 0 AND TIMESTAMP(NEW.appt_date, NEW.start_time) <= NOW() THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot book a date or time that has already passed';
  END IF;

  -- the provider must be the right kind for the service
  SELECT provider_role INTO v_service_role FROM services WHERE service_id = NEW.service_id;
  SELECT role INTO v_provider_role FROM users WHERE user_id = NEW.provider_id;
  IF v_service_role IS NULL OR v_provider_role IS NULL OR v_service_role <> v_provider_role THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This provider does not offer the selected service';
  END IF;

  -- the pet must belong to the owner making the booking
  SELECT owner_id INTO v_pet_owner FROM pets WHERE pet_id = NEW.pet_id;
  IF v_pet_owner IS NULL OR v_pet_owner <> NEW.owner_id THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This pet does not belong to the booking owner';
  END IF;
END$$

CREATE TRIGGER trg_appt_before_update
BEFORE UPDATE ON appointments
FOR EACH ROW
BEGIN
  -- a reschedule may not move the appointment into the past
  IF (NEW.appt_date <> OLD.appt_date OR NEW.start_time <> OLD.start_time)
     AND TIMESTAMP(NEW.appt_date, NEW.start_time) <= NOW() THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot reschedule to a date or time that has already passed';
  END IF;

  -- completed / cancelled appointments are closed
  IF OLD.status IN ('Completed','Cancelled')
     AND (NEW.appt_date <> OLD.appt_date OR NEW.start_time <> OLD.start_time) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A completed or cancelled appointment cannot be rescheduled';
  END IF;
END$$

CREATE TRIGGER trg_review_before_insert
BEFORE INSERT ON reviews
FOR EACH ROW
BEGIN
  DECLARE v_status VARCHAR(12);
  DECLARE v_owner INT;
  DECLARE v_provider INT;
  SELECT status, owner_id, provider_id INTO v_status, v_owner, v_provider
    FROM appointments WHERE appointment_id = NEW.appointment_id;
  IF v_status IS NULL OR v_status <> 'Completed' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only completed appointments can be reviewed';
  END IF;
  IF v_owner <> NEW.owner_id OR v_provider <> NEW.provider_id THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Review owner/provider must match the appointment';
  END IF;
END$$

DELIMITER ;

-- ============================================================
-- VIEWS — used by dashboards and the System Architecture page
-- ============================================================

-- provider directory with average rating
CREATE VIEW v_provider_directory AS
SELECT u.user_id, u.full_name, u.role, u.email, u.phone, u.city,
       p.qualification, p.license_no, p.experience_years, p.bio,
       p.work_start, p.work_end,
       ROUND(AVG(r.rating), 1) AS avg_rating,
       COUNT(r.review_id)      AS review_count
  FROM users u
  JOIN provider_profiles p ON p.provider_id = u.user_id
  LEFT JOIN reviews r      ON r.provider_id = u.user_id
 GROUP BY u.user_id, u.full_name, u.role, u.email, u.phone, u.city,
          p.qualification, p.license_no, p.experience_years, p.bio,
          p.work_start, p.work_end;

-- one row per appointment with every name filled in
CREATE VIEW v_appointment_details AS
SELECT a.appointment_id, a.appt_date, a.start_time, a.status, a.owner_note,
       a.owner_id,    o.full_name  AS owner_name,   o.phone AS owner_phone,
       a.pet_id,      pt.name      AS pet_name,     pt.species, pt.breed,
       a.provider_id, pr.full_name AS provider_name, pr.role AS provider_role,
       a.service_id,  s.name       AS service_name, s.price,
       rv.rating, rv.comment AS review_comment
  FROM appointments a
  JOIN users o     ON o.user_id     = a.owner_id
  JOIN pets pt     ON pt.pet_id     = a.pet_id
  JOIN users pr    ON pr.user_id    = a.provider_id
  JOIN services s  ON s.service_id  = a.service_id
  LEFT JOIN reviews rv ON rv.appointment_id = a.appointment_id;
